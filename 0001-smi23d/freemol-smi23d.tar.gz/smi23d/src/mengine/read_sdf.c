#define EXTERN extern

#include "pcwin.h"
#include "pcmod.h"
#include "substr.h"
#include "atom_k.h"
#include "energies.h"

EXTERN struct t_files {
        int nfiles, append, batch, icurrent, ibatno;
        }       files;
EXTERN struct ElementType { char symbol[3];
                             int atomnum;
                             float weight, covradius, vdwradius;
                              int s,p,d,f,type ;
                            } Elements[];
EXTERN struct t_dipolemom {
        double total, xdipole, ydipole, zdipole;
       }  dipolemom;
EXTERN struct t_logp {
        float logp;
        } logp_calc;
EXTERN struct t_vibdata {
        char ptgrp[4];
        float mom_ix,mom_iy,mom_iz;
        float etot,htot,stot,gtot,cptot;
       } vibdata;

int make_atom(int, float, float, float,char *);
void make_bond(int, int, int);
int read_sdf(int,int);
int rd_sdf(FILE *);
void write_sdf(int);
void message_alert(char *, char *);
void hdel(int);
FILE * fopen_path ( char * , char * , char * ) ;
void read_schakal(int,int);
void write_schakal(void);
void mopaco(int,int);
int FetchRecord(FILE *, char *);
void avgleg(void);

/*
 * flags - indicates whether dipole, xlogp or vibrational calculations were done
 * and if so write them to the output file. Look at the definitions in pcmod.h
 *
 */
void write_sdf(int flags)
{
    int i,j,lptest,nbond,junk;
    FILE *wfile;
    
    lptest = 0;
    for( i = 1; i <= natom; i++ )
    {
        if( atom[i].mmx_type == 20 )
        {
            lptest = 1;
            hdel( lptest );
            break;
        }
    }
    nbond = 0;
    /*     **  calculate the number of bonds in the molecule ** */
    for( j = 1; j <= natom; j++ )
    {
      for( i = 0; i < MAXIAT; i++ )
      {
         if( atom[j].iat[i] != 0 )
         {
            if( atom[j].iat[i] < j )
               nbond = nbond + 1;
         }
       }
     }
    /*     now write the concord file */
    if (files.append)
        wfile = fopen_path(Savebox.path,Savebox.fname,"a");
    else
        wfile = fopen_path(Savebox.path,Savebox.fname,"w");

    j = strlen(Struct_Title);
    for (i=0; i < j; i++)
    {
        if (Struct_Title[i] == '\n')
        {
            Struct_Title[i] = '\0';
            break;
        }
    }
    fprintf(wfile,"%s\n",Struct_Title);
    fprintf(wfile," PCMODEL  v9.1   1.00000     0.00000\n");       
    fprintf(wfile,"\n");       

    fprintf(wfile,"%3d%3d  0  0  0  0              1 V2000\n",natom,nbond);

    for (i=1; i <= natom; i++)
    {
        junk = 0;
        if (atom[i].mmx_type == 41) junk = 3;
        else if (atom[i].mmx_type == 42) junk = 5;
        else if (atom[i].mmx_type == 66)
        {
            if (atom[i].bo[0] == 1)
               junk = 5;
        }
        fprintf(wfile,"%10.4f%10.4f%10.4f %-3s 0  %d  0  0  0  0 \n",atom[i].x, atom[i].y,
          atom[i].z,Elements[atom[i].atomnum-1].symbol,junk);
    }
    for (i=1; i <= natom; i++)
    {
        for (j=0; j < MAXIAT; j++)
        {
            if (atom[i].iat[j] != 0 && i < atom[i].iat[j])
               fprintf(wfile,"%3d%3d%3d  0\n",i, atom[i].iat[j], atom[i].bo[j]);
        }
    }
    fprintf(wfile,"M  END\n");
    fprintf(wfile,"> <title>\n");
    fprintf(wfile,"%s\n",Struct_Title);
    
    fprintf(wfile,"> <MMFF94 energy>\n");
    fprintf(wfile,"%f\n",energies.total);

    if (flags & DO_DIPOLE) {
      fprintf(wfile,"> <dipole moment>\n");
      fprintf(wfile,"%f\n",dipolemom.total);
    }

    if (flags & DO_XLOGP) {
      fprintf(wfile,"> <xLogP>\n");
      fprintf(wfile,"%f\n",logp_calc.logp);
    }

    if (flags & DO_VIBRATION) {
      fprintf(wfile,"> <Point Group>\n");
      fprintf(wfile,"%s\n",vibdata.ptgrp);
    
      fprintf(wfile,"> <Moments of Inertia>\n");
      fprintf(wfile,"%f8.3  %f8.3  %f8.3 \n",vibdata.mom_ix,vibdata.mom_iy,vibdata.mom_iz);

      fprintf(wfile,"> <thermodynamics dE, dH, S, dG, CP>\n");
      fprintf(wfile,"%f8.3  %f8.3  %f8.3  %f8.3  %f8.3  \n",vibdata.etot, vibdata.htot,
	      vibdata.stot,vibdata.gtot,vibdata.cptot);
    }

    fprintf(wfile,"\n");
    fprintf(wfile,"$$$$\n");
    fclose(wfile);
}
/* ===================================  */
// fast read - assume file is open and positioned
// read structure and down to end $$$$
// and return
int rd_sdf(FILE *rfile)
{
    int i, j, niatom, nibond, ia1, ia2, ibond, itype, newatom;
    int ncount,junk,junk1,got_title,istereo,iz;
    int jji, jj1, jj2, jj3, jj4;
    int has_Aromatic, xPlus,yPlus,zPlus, planar;
    int icount,itemp[4];
    int Ret_Val;
    float xtmp, ytmp, ztmp, dz;
    char  c1[4],c2[4];
    char  atomchar[3];
    char  inputline[150];

     Ret_Val = TRUE;
     got_title = FALSE;
     xPlus = yPlus = zPlus = FALSE;
     FetchRecord(rfile,inputline);
     sscanf(inputline,"SDF %s",Struct_Title);
     got_title = TRUE;
     /*     if (strlen(inputline) > 4)
     {
         iz = strlen(inputline);
         if (iz > 60) iz = 59;
         for (i=4; i < iz; i++)
           Struct_Title[i-4] = inputline[i];
         Struct_Title[i] = '\0';
        got_title = TRUE;
	} */
     FetchRecord(rfile,inputline); // blank line
     FetchRecord(rfile,inputline); // blank line
     
     FetchRecord(rfile,inputline); // natom and nbond
     for (i=0; i <4; i++)
     {
        c1[i] = inputline[i];
        c2[i] = inputline[i+3];
     }
     c1[3] = '\0';c2[3] = '\0';
     niatom = atoi(c1);
     nibond = atoi(c2); 
     if (niatom == 0)
       return FALSE;

     for (i=0; i < niatom; i++)
     {
        FetchRecord(rfile,inputline);
        sscanf(inputline,"%f %f %f %s %d %d",&xtmp, &ytmp, &ztmp, atomchar,&junk,&junk1);

        itype = 0;
        if (xtmp != 0.0) xPlus= TRUE;
        if (ytmp != 0.0) yPlus= TRUE;
        if (ztmp != 0.0) zPlus= TRUE;

        iz = strlen(atomchar);
        if (itype == 0 && (atomchar[0] == 'N' || atomchar[0] == 'O') && iz == 1)  // nitro fix
        {
            if (atomchar[0] == 'N') itype = 8;
            if (atomchar[0] == 'O') itype = 6;
            
            if (junk1 != 0)
            {
                if (junk1 == 3 && itype == 8)
                  itype = 41;  // N+
                if (junk1 == 5 && itype == 6)
                  itype = 42;  // O-
            }
        }

        newatom = make_atom(itype,xtmp,ytmp,ztmp,atomchar);
        if (itype != 0)
	  atom[newatom].mmx_type = itype;
        if (newatom == -1)
        {
            printf("Atom %d %s not recognized structure skipped\n",i,atomchar);
            Ret_Val = FALSE;
        }
     }
     has_Aromatic = FALSE;
     
     planar = TRUE;
     if (xPlus && yPlus && zPlus) planar = FALSE;
     
     for (i=0; i < nibond; i++)
     {
        FetchRecord(rfile,inputline);
        for (j=0; j <4; j++)
        {
           c1[j] = inputline[j];
           c2[j] = inputline[j+3];
         }  
        c1[3] = '\0';c2[3] = '\0';
        ia1 = atoi(c1);
        ia2 = atoi(c2);
        istereo = 0;
        sscanf(inputline,"%3d%3d%3d%3d",&junk, &junk1, &ibond,&istereo);
        if (ibond >= 4)
        {
            ibond = 1;
            has_Aromatic = TRUE;
        }
        make_bond(ia1, ia2, ibond);
        if (istereo == 1 && planar)
        {
            atom[ia2].z += 0.7;
            if (atom[ia2].atomnum == 1)
              atom[ia2].type = 60;
        }
        if (istereo == 6 && planar)
        {
            atom[ia2].z -= 0.7;
            if (atom[ia2].atomnum == 1)
             atom[ia2].type = 60;
        }
     }
// read to end of structure
     while (FetchRecord(rfile,inputline))
     {
         if (strncasecmp(inputline,"$$$$",4) == 0)
         {
            return Ret_Val;
         }
     }
     return Ret_Val;
}
/* ===================================  */
int read_sdf(int istruct, int isubred)
{
    int i, j, niatom, nibond, ia1, ia2, ibond, itype, newatom;
    int ncount, ibotptr,junk,junk1,got_title,istereo,iz;
    int jji, jj1, jj2, jj3, jj4;
    int has_Aromatic, xPlus,yPlus,zPlus, planar;
    int icount,itemp[4];
    float xtmp, ytmp, ztmp, dz;
    char  c1[4],c2[4];
    char  atomchar[3];
    char  inputline[150];
    FILE   *infile;
    
    infile = fopen_path(Openbox.path,Openbox.fname,"r");

    if (infile == NULL)
    {
        message_alert("Error opening Concord file","Concord Setup");
        return FALSE;
    }

    if (isubred == 0)
       ibotptr = 0;
    else
    {
       ibotptr = natom;
       substr.istract[substr.icurstr] = TRUE;
    }

    if (istruct > 1)
    {
        ncount = 0;
        while (FetchRecord(infile,inputline))
        {
            if (strncasecmp(inputline,"$$$$",4) == 0)
            {
                ncount++;
                if (ncount+1 == istruct)
                    goto L_1;
            }
        }
    } 
// start file read here
L_1:
     got_title = FALSE;
     xPlus = yPlus = zPlus = FALSE;
     FetchRecord(infile,inputline);
     sscanf(inputline,"SDF %s",Struct_Title);
     got_title = TRUE;
     /*     if (strlen(inputline) > 4)
     {
         iz = strlen(inputline);
         if (iz > 60) iz = 59;
         for (i=4; i < iz; i++)
           Struct_Title[i-4] = inputline[i];
         Struct_Title[i] = '\0';
        got_title = TRUE;
	} */
     FetchRecord(infile,inputline); // blank line
     FetchRecord(infile,inputline); // blank line
     
     FetchRecord(infile,inputline); // natom and nbond
     for (i=0; i <4; i++)
     {
        c1[i] = inputline[i];
        c2[i] = inputline[i+3];
     }
     c1[3] = '\0';c2[3] = '\0';
     niatom = atoi(c1);
     nibond = atoi(c2); 
     if (niatom == 0)
       return FALSE;

     for (i=0; i < niatom; i++)
     {
        FetchRecord(infile,inputline);
        sscanf(inputline,"%f %f %f %s %d %d",&xtmp, &ytmp, &ztmp, atomchar,&junk,&junk1);

        itype = 0;
        if (xtmp != 0.0) xPlus= TRUE;
        if (ytmp != 0.0) yPlus= TRUE;
        if (ztmp != 0.0) zPlus= TRUE;

        iz = strlen(atomchar);
        if (itype == 0 && (atomchar[0] == 'N' || atomchar[0] == 'O') && iz == 1)  // nitro fix
        {
            if (atomchar[0] == 'N') itype = 8;
            if (atomchar[0] == 'O') itype = 6;
            
            if (junk1 != 0)
            {
                if (junk1 == 3 && itype == 8)
                  itype = 41;  // N+
                if (junk1 == 5 && itype == 6)
                  itype = 42;  // O-
            }
        }

        newatom = make_atom(itype,xtmp,ytmp,ztmp,atomchar);
        if (newatom == -1)
        {
            printf("Atom %d %s not recognized structure skipped\n",i,atomchar);
            return FALSE;
        }
        if (isubred == 1)
        {
            atom[newatom].substr[0] = 0;
            atom[newatom].substr[0] |= (1L << substr.icurstr);
        }
     }
     has_Aromatic = FALSE;
     
     planar = TRUE;
     if (xPlus && yPlus && zPlus) planar = FALSE;
     
     for (i=0; i < nibond; i++)
     {
        FetchRecord(infile,inputline);
        for (j=0; j <4; j++)
        {
           c1[j] = inputline[j];
           c2[j] = inputline[j+3];
         }  
        c1[3] = '\0';c2[3] = '\0';
        ia1 = atoi(c1);
        ia2 = atoi(c2);
        istereo = 0;
        sscanf(inputline,"%3d%3d%3d%3d",&junk, &junk1, &ibond,&istereo);
        if (ibond >= 4)
        {
            ibond = 1;
            has_Aromatic = TRUE;
        }
        make_bond(ia1+ibotptr, ia2+ibotptr, ibond);
        if (istereo == 1 && planar)
        {
            atom[ia2+ibotptr].z += 0.7;
            if (atom[ia2+ibotptr].atomnum == 1)
              atom[ia2+ibotptr].type = 60;
        }
        if (istereo == 6 && planar)
        {
            atom[ia2+ibotptr].z -= 0.7;
            if (atom[ia2+ibotptr].atomnum == 1)
             atom[ia2+ibotptr].type = 60;
        }
     }
     FetchRecord(infile,inputline);  // M END line
     FetchRecord(infile,inputline);
     if (got_title == FALSE)
        strcpy(Struct_Title,inputline);
     fclose(infile);
     ncount = strlen(Struct_Title);
     for (i=0; i < ncount; i++)
     {
         if (Struct_Title[i] == '\n')
         {
             Struct_Title[i] = '\0';
             break;
         }
     }
//   search for quaternary centers - check if flat
     dz = 0.0;
     for (i=1; i <= natom; i++)
     {
         dz += atom[i].z;
         jji = jj1 = jj2 = jj3 = jj4 = 0;
         if (atom[i].type != 0)
         {
             for (j=0; j < 6; j++)
             {
                 if (atom[i].iat[j] != 0)
                   jji++;
             }
         }
         if (jji == 4)
         {
             if (atom[atom[i].iat[0]].z == 0.0 && atom[atom[i].iat[0]].z == 0.0 &&
                   atom[atom[i].iat[0]].z == 0.0 && atom[atom[i].iat[0]].z == 0.0)  // flat center
             {
                 for (j=0; j < 4; j++)
                 {
                     itemp[j] = 0;
                     if (atom[atom[i].iat[0]].iat[j] != 0) jj1++;
                     if (atom[atom[i].iat[1]].iat[j] != 0) jj2++;
                     if (atom[atom[i].iat[2]].iat[j] != 0) jj3++;
                     if (atom[atom[i].iat[3]].iat[j] != 0) jj4++;
                 }
                 icount = 0;
                 if (jj1 == 1)
                 {
                     itemp[icount] = atom[i].iat[0];
                     icount++;
                 }
                 if (jj2 == 1)
                 {
                     itemp[icount] = atom[i].iat[1];
                     icount++;
                 }
                 if (jj3 == 1)
                 {
                     itemp[icount] = atom[i].iat[2];
                     icount++;
                 }
                 if (jj3 == 1)
                 {
                     itemp[icount] = atom[i].iat[3];
                     icount++;
                 }
                 if (icount >= 2)
                 {
                     atom[itemp[0]].z += 0.5;
                     atom[itemp[1]].z -= 0.5;
                 }
             }
         }
     }
     for (i=1; i < natom; i++)
     {
         for (j=i+1; j <= natom; j++)
         {
             xtmp = atom[i].x - atom[j].x;
             ytmp = atom[i].y - atom[j].y;
             ztmp = atom[i].z - atom[j].z;
             if ( (xtmp + ytmp + ztmp) < 0.1)
             {
                 atom[i].x += 0.1;
                 atom[i].y += 0.1;
                 atom[i].z += 0.1;
                 atom[j].x -= 0.1;
                 atom[j].y -= 0.1;
                 atom[j].z -= 0.1;
             }
         }
     }
              
     if (has_Aromatic == TRUE)
       mopaco(1,natom);
     return TRUE;
}
// ==================================================
void read_schakal(int isel,int isubred)
{
    int i, itype,  newatom, iz;
    float xtmp, ytmp, ztmp;
    char  dummy[30];
    char  atomchar[6];
    char  inputline[150];
    FILE   *infile;
    
    infile = fopen_path(Openbox.path,Openbox.fname,"r");

    if (infile == NULL)
    {
        message_alert("Error opening Schakal file","Schakal Setup");
        return;
    }
    while ( FetchRecord(infile,inputline))
    {
        sscanf(inputline,"%s",dummy);
        if (strcmp(dummy,"TITLE") == 0)
        {
            sscanf(inputline,"%s %s",dummy,Struct_Title);
        } else if (strcmp(dummy,"ATOM") == 0)
        {
            sscanf(inputline,"%s %s %f %f %f",dummy,atomchar,&xtmp,&ytmp,&ztmp);
            // strip off numbers
            iz = strlen(atomchar);
            for (i=0; i < iz; i++)
            {
                if (isdigit(atomchar[i]))
                {
                    atomchar[i] = '\0';
                    break;
                }
            }
            itype = 0;
            newatom = make_atom(itype,xtmp,ytmp,ztmp,atomchar);
        } else if (strcmp(dummy,"END") == 0)
        {
            break;
        }
    }
    fclose(infile);
    mopaco(1,natom);
//
}
// ==================================================
void write_schakal()
{
    int i,j,lptest;
    char atomchar[6];
    FILE *wfile;
    
    lptest = 0;
    for( i = 1; i <= natom; i++ )
    {
        if( atom[i].mmx_type == 20 )
        {
            lptest = 1;
            hdel( lptest );
            break;
        }
    }

    /*     now write the schakal file */
    if (files.append)
        wfile = fopen_path(Savebox.path,Savebox.fname,"a");
    else
        wfile = fopen_path(Savebox.path,Savebox.fname,"w");

    j = strlen(Struct_Title);
    for (i=0; i < j; i++)
    {
        if (Struct_Title[i] == '\n')
        {
            Struct_Title[i] = '\0';
            break;
        }
    }
    fprintf(wfile,"TITLE  %s\n",Struct_Title);
    fprintf(wfile,"CELL \n");
    for (i=1; i <= natom; i++)
    {
        sprintf(atomchar,"%s%d",Elements[atom[i].atomnum-1].symbol,i);
            
        fprintf(wfile,"ATOM  %-5s %12.7f%12.7f%12.7f\n",atomchar,atom[i].x,
           atom[i].y, atom[i].z);
    }    
    fprintf(wfile,"END \n");
    fclose(wfile);
}


