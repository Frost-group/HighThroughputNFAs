#define EXTERN extern
#include "pcwin.h"
#include "pcmod.h"
#include "utility.h"
#include "energies.h"
#include "torsions.h" 
#include "gmmx.h"
#include "pot.h"
#include "field.h"
#include "nonbond.h"

#include <time.h>
#include <errno.h>

struct t_logp {
        float logp;
        } logp_calc;
struct t_vibdata {
        char ptgrp[4];
        float mom_ix,mom_iy,mom_iz;
        float etot,htot,stot,gtot,cptot;
       } vibdata;
    
EXTERN struct  t_optimize {
        int param_avail, converge;
        float initial_energy, final_energy, initial_heat, final_heat;
        } optimize_data;

EXTERN struct t_files {
        int nfiles, append, batch, icurrent, ibatno;
        }       files;
EXTERN struct t_dipolemom {
        double total, xdipole, ydipole, zdipole;
       }  dipolemom;

EXTERN struct t_hfof {
        float hfo, si;
        int iunk;
        }  hfof;
EXTERN struct t_pcmfile {
        char string[200];
        int head;
        char token[20];
        int state;
        unsigned int nocaps;
        }       pcmfile;
EXTERN struct t_minim_values {
        int iprint, ndc, nconst;
        float dielc;
        } minim_values;
EXTERN struct t_minim_control {
        int type, method, field, added_const;
        char added_path[256],added_name[256];
        } minim_control;
EXTERN struct t_rotbond {
    int nbonds, bond[200][2], bond_res[200];
    int incl_amide, incl_alkene;
    } rotbond;
            
struct t_tmp {
    int tmp_nrings, tmp_natoms[4], tmp_ratoms[30][4], tmp_clo_bond[4][4];
    float tmp_clo_ang[2][4], tmp_clo_distance[4], tmp_ring_resolution[4];
    } tmp;

int input_type;

int nerr;
int gmmx_abort;

int rd_sdf(FILE *);
int check_ring1(int);
int is_ring31(int);
int is_ring41(int);
int is_ring51(int);
int is_ring61(int);
int get_hybrid(int);
void set_atomtype(int,int,int,int,int,int);
void sort_file(char *, char *);
void gettoken(void);
int is_bond(int,int);
void read_atomtypes(int);
//double compute_rms(int, int **, double [150][3], double [150][3]);
//void fndumt( int, int **, double [150][3], double [150][3] );
//int fast_compare(double [150][3], double [150][3]);
//void slow_compare(int, int **, double [150][3], double [150][3]);
double compute_rms(int, int **, double **, double **);
void fndumt( int, int **, double **, double ** );
int fast_compare(double **, double **);
void slow_compare(int, int **, double **, double **);
void message_alert(char *, char *);
void gradient(void);
void eigen(int norder,double (*)[3],double *, double (*)[3]);
int check_structure(void);
int check_id(void);  
double distance(int,int);
void rotb(int,int,int,int, float);
void make_bond(int , int , int );
void deletebond(int, int);
int setup_calculation(void);
void end_calculation(void);
void hster(int, int *);
int lepimer(int);
double dihdrl(int,int,int,int);
void mvatom(void);
void mvbond(void);
void minimize(void);
int findcd(int);
int findtor(int);
void InitialTransform(void);
int bad15(int);
int close_contact(int);
void gmmx2(void);
int check_stop(void);
void hbondreset(void);
void setup_output(char *);
void pimarkselection(void);
void mark_hbond(void);
void pireset(void);
void pcmfout(int);
void center(int);
void pcmfin(int,int);
void initialize(void);
void generate_bonds(void);
int  bstereo(int);
void type(void);
void mmxsub(int);
void set_atom_color(void);
void eheat(void);
void charge_dipole(void);
void mmp22mod(int,int);
void check_numfile(int);
void dipole_dipole(void);
void set_active(void);
double energy(void);
void write_restart(void);
int  read_restart(void);
void rdfile(int,int);
void montc(void);
void include_min(void);
void jacobi(int,int,double **,double *,double **,double *,double *);
void quatfit(int,int **,double **,double **);
FILE * fopen_path ( char * , char * , char * ) ;
void read_gmmxinp(char*, char*, char*,int);
void run_gmmx(void);
int rmsck(int, int *);
void write_gmmx(void);
int read_sdf(int,int);
float ran1(int *);
void hdel(int);
void hadd(void);
void hcoord(void);
void inesc(char *);
void find_bonds(void);
int FetchRecord(FILE *, char *);
void deleteatom(int);
void write_sdf(int);
void zero_data(void);
void type_mmx(void);
void read_datafiles(char *);
void xlogp(float *);
void vibrate(void);

// =====================================
void read_gmmxinp(char *log_file, 
		  char *out_file, /* output file name */
		  char *paramfile,
		  int flags)
{
   char line[121];
   int i,ncount,nret,j,k,jj,nc;
   int icount;
   int ngood, nbparam, nbatom,nbcontact;
   int bcontact = FALSE;
   int batom = FALSE;
   float logp;
   char *std_file;
   char bad_atom[80],bad_contact[80],bad_param[80];
   clock_t start_time, end_time;
   FILE *infile, *logfile;

// check filetype
    ncount = 0;
    infile = fopen(Openbox.fname,"r");
    if (infile == NULL)
    {
        printf("Unable to open - %s - Please check filename\n",gmmx_data.finame);
        exit(0);
    }
    input_type = 0;
// build output filename
    for (i=0; i < strlen(Openbox.fname); i++)
    {
        if (Openbox.fname[i] != '.' && Openbox.fname[i] != '\0')
           line[i] = Openbox.fname[i];
        else
           break;
    }
    line[i] = '\0';

    std_file = strdup(out_file);
    strcpy(Savebox.fname, out_file);

    strcpy(bad_atom,line);
    strcpy(bad_contact,line);
    strcpy(bad_param,line);

// build filenames
    strcat(bad_atom,"_batom.sdf");
    strcat(bad_contact,"_bcontact.sdf");
    strcat(bad_param,"_bparam.sdf");
    
    // open logfile
    logfile = fopen(log_file,"w");
    
    files.nfiles = 0;
    // assume SDF input
    while (FetchRecord(infile, line) )
    {
        if (strcmp(line,"$$$$") == 0)
           files.nfiles++;
    }
    fclose(infile);
//
    minim_control.field = MMFF94;
    strcpy(line,paramfile);
    zero_data();
    read_datafiles(line);  
    gmmx.run = TRUE;
    minim_control.method = 1;  // just do first deriv minimization
    icount = 0;
//
    infile = fopen(Openbox.fname,"r");
    if (infile == NULL)
    {
        printf("Unable to open - %s - Please check filename\n",gmmx_data.finame);
        exit(0);
    }
    ngood = nbparam = nbatom = nbcontact = 0;
    for (i=1; i <= files.nfiles; i++)
    {
        initialize();
        nret = rd_sdf(infile);        
	
        if (natom == 1) 
        {
	   fprintf(logfile,"Strnum: %d has only one atom\n",i);
           goto L_10;
	}
	//        if (i%20 == 0)
	//            printf("Strnum: %d of %d\n",i,files.nfiles);
        if (nret == TRUE)
	  {
            nc = close_contact(1);
            if (nc == FALSE)
	      {
	        fprintf(logfile,"Strnum: %d CID: %s fails on bad contact\n",i,Struct_Title);
                strcpy(Savebox.fname,bad_contact);
                sprintf(Struct_Title,"Bad Contact %d\n",i);
                files.append = TRUE;
                if (bcontact == FALSE)
		  {
                    files.append = FALSE;
                    bcontact = TRUE;
		  }
		nbcontact++;
                write_sdf(flags);
                strcpy(Savebox.fname,std_file);
                goto L_10;
	      }
	    ncount = natom;
	    for (j=1; j<= ncount; j++)
	      {
		jj = 0;
		if (atom[j].atomnum == 1)  // bridging hydrogens
		  {
		    if (atom[j].iat[0] != 0 && atom[j].iat[1] != 0)
		      goto L_10;
		  } 
	      }
	    hdel(0);
	    hadd();
	    type();
	    hdel(0);
	    start_time = clock();
	    nret = setup_calculation();
	    if (nret == TRUE)
              minimize();
	    end_calculation();

	    //           minim_control.method = 3;
	    hdel(0);
	    hadd();
	    type_mmx();
         
	    nret = setup_calculation();
	    if (nret == TRUE)
	      {
		minimize();
		files.append = TRUE;
		if ( icount == 0)
		  {
		    files.append = FALSE;
		    icount++;
		  }
		// compute xlogp
		if (energies.total < 1000.0)
		  {
		    if (flags & DO_XLOGP) {
		      if (VERBOSE) fprintf(stderr, "  Evaluating XlogP\n");
		      xlogp(&logp);
		      logp_calc.logp = logp;
		    }
		    // compute dipole moment
		    dipolemom.xdipole = 0.0;
		    dipolemom.ydipole = 0.0;
		    dipolemom.zdipole = 0.0;
		    if (flags & DO_DIPOLE) {
		      if (VERBOSE) fprintf(stderr, "  Evaluating dipole moment\n");
		      charge_dipole();
		      dipolemom.total = sqrt(dipolemom.xdipole*dipolemom.xdipole +
					     dipolemom.ydipole*dipolemom.ydipole +
					     dipolemom.zdipole*dipolemom.zdipole);
		    }
		    // compute vib
		    if (flags & DO_VIBRATION) {
		      if (VERBOSE) fprintf(stderr, "  Evaluating vibrational parameters\n");		      
		      vibrate();
		    }
		    write_sdf(flags);
		    ngood++;
		  }
	      } else
	      {
		strcpy(Savebox.fname,bad_param);
		files.append = TRUE;
		write_sdf(flags);
		nbparam++;
		strcpy(Savebox.fname,std_file);
		fprintf(logfile,"Strnum: %d  CID: %s fails on missing parameters\n",i,Struct_Title);
		if (VERBOSE) 
		  fprintf(stdout, "Missing parameters - no calc - %s\n",Struct_Title);
	      }
	    end_calculation();
	    end_time = clock(); 
	    fprintf(logfile,"Strnum: %d of %d %s natom %d  time %lu sec\n",i,files.nfiles,Struct_Title,
		    natom,(end_time-start_time)/CLOCKS_PER_SEC);
	    if (VERBOSE) {
	      fprintf(stdout,
		      "Strnum: %d of %d %s natom %d  time %lu sec\n",i,files.nfiles,Struct_Title,
		      natom,(end_time-start_time)/CLOCKS_PER_SEC);
	    }
	  } else  // read_sdf failed
	  {
	    fprintf(logfile,"Strnum: %d CID: %s fails on unsupported atom\n",i,Struct_Title);
            strcpy(Savebox.fname,bad_atom);
            files.append = TRUE;
            if (batom == FALSE)
            {
                batom = TRUE;
                files.append = FALSE;
            }
            write_sdf(flags);
	    nbatom++;
            strcpy(Savebox.fname,std_file);
        }
        L_10:
           continue;
    }
    fclose(infile);
    fprintf(logfile,"Ngood: %d Nbparam: %d Nbatom: %d Nbcontact: %d \n",ngood,nbparam,nbatom,nbcontact);
    if (VERBOSE) {
    fprintf(stdout, 
	    "Ngood: %d Nbparam: %d Nbatom: %d Nbcontact: %d \n",
	    ngood,nbparam,nbatom,nbcontact);
    }

    fclose(logfile);
}
// ================================================
// ==============================
void initialize_gmmx()
{
    int i, j, k, nheav, nhyd,stmp;
    long int mask;

    mask = (1L << 0);
    tmp.tmp_nrings = 0;
    gmmxring.nrings = 0;
    for (i=0; i < 4; i++)
    {
        tmp.tmp_natoms[i] = 0;
        for (j=0; j < 4; j++)
        {
            gmmx_data.rng_size[j] = 0;
            gmmxring.nring_atoms[i] = 0;
            for (i=0; i <  30; i++)
            {
                gmmx_data.ring_atoms[i][j] = 0 ;
                tmp.tmp_ratoms[i][j] = 0 ;
            }
            gmmx_data.clo_distance[j] = 0;
            tmp.tmp_clo_distance[j] = 0 ;
            gmmx_data.clo_ang[0][j] = 0;
            gmmx_data.clo_ang[1][j] = 0;
            tmp.tmp_clo_ang[0][j] = 0;
            tmp.tmp_clo_ang[1][j] = 0;
            gmmx_data.ring_resolution[j] = 0.0;
            tmp.tmp_ring_resolution[j] = 0.0;
            gmmx_data.clo_bond[0][j] = 0 ;
            gmmx_data.clo_bond[1][j] = 0 ;
            gmmx_data.clo_bond[2][j] = 0 ;
            gmmx_data.clo_bond[3][j] = 0 ;
            gmmx_data.clo_bond[4][j] = 0 ;
            gmmx_data.clo_bond[5][j] = 0 ;
            tmp.tmp_clo_bond[0][j] = 0 ;
            tmp.tmp_clo_bond[1][j] = 0 ;
            tmp.tmp_clo_bond[2][j] = 0 ;
            tmp.tmp_clo_bond[3][j] = 0 ;
        }
    }
    stmp = rand();
    if(stmp >= 10000)
       stmp = stmp/10;
    if(stmp >= 10000)
       stmp = stmp/10;
    if(stmp >= 10000)
       stmp = stmp/10;
    if(stmp >= 10000)
       stmp = stmp/10;
    if(stmp >= 10000)
       stmp = stmp/10;
    if(stmp >= 10000)
       stmp = stmp/10;
    if(stmp >= 10000)
       stmp = stmp/10;
    if(stmp >= 10000)
       stmp = stmp/10;
    sprintf(gmmx_data.jobname,"gmx%d",stmp);
    strcpy(gmmx_data.gmmx_comment,"GMMX Conf Search");
        
    gmmx_data.method = 3;
    gmmx_data.iseed = 71277;
    gmmx_data.its = 990;
    gmmx_data.lnant = TRUE;
    gmmx_data.hybrid = TRUE;
    gmmx_data.ecut = TRUE;
    gmmx_data.chig = TRUE;
    gmmx_data.bad15 = TRUE;
    gmmx_data.nopi1 = FALSE;
     for (i=1; i <= natom; i++)
     {
         if (atom[i].flags & mask)
          {
           gmmx_data.nopi1 = TRUE;
           break;
          }
     }
    gmmx_data.hbond = TRUE;
    gmmx_data.heat = FALSE;
    
    gmmx_data.comp = 0;
    gmmx_data.qpmr = FALSE;
    gmmx_data.qdist = FALSE;
    gmmx_data.qang = FALSE;
    gmmx_data.qdihed = FALSE;
    gmmx_data.npmr = 0;
    gmmx_data.ndist = 0;
    gmmx_data.nang = 0;
    gmmx_data.ndihed = 0;

    gmmx_data.nrings = 0;
    gmmx_data.nbonds = 0;
    gmmx_data.ewindow = 3.5;
    gmmx_data.ewindow2 = 3.0;
    gmmx_data.boltz = 300.0;
    gmmx_data.ecutoff = 0.100;
    gmmx_data.bad15_cutoff = 3.00;
        
    gmmx_data.nsrms = 0;
    gmmx_data.nsrmsa = 0;
    gmmx_data.comp_method = 0;
    gmmx_data.comp_method2 = 1;
    gmmx_data.ermsa = 0.100;
    gmmx_data.crmsa = 0.250;
    gmmx_data.restart = FALSE;
    gmmx_data.include_file = FALSE;

    nheav = 0;
    nhyd = 0;
    for (i=1; i <= natom; i++)
    {
        if (atom[i].atomnum != 1 && atom[i].atomnum != 2)
            nheav++;
        else
            nhyd++;
    }

    gmmx_data.kstop = 5;
    gmmx_data.kmin = 5*nheav;
    gmmx_data.kdup = 5*nheav/2;
    if (gmmx_data.kdup > 50)
      gmmx_data.kdup = 50;
    gmmx_data.max_search = 100000;
    
    gmmx_data.nrings = 0;
    for (i=0; i < 4; i++)
      gmmx_data.nring_bonds[i] = 0; 
    for (i=0; i < 30; i++)
    {
       gmmxring.nring_atoms[i] = 0;
       for (j=0; j < 30; j++)
         gmmxring.ring_atoms[i][j]=0;
       for (j=0; j < 4; j++)
       for (k=0; k < 3; k++)
        gmmx_data.ring_bond_data[j][i][k] = 0;
    }
    
}
/* =============================================== */
// get hybridization of atom - tetrahedral = 1, planar = 2, linear = 3
//
int get_hybrid(int ia)
{
    int itype;

    itype = atom[ia].mmx_type;
    if (itype == 2 || itype == 3 || itype == 7 || itype == 9 || itype == 25 ||
        itype == 26 || itype == 29 || itype == 30 || itype == 37 || itype == 38 ||
        itype == 40 || itype == 57 )
        return 2;
    else if (itype == 4 || itype == 10)
        return 3;
    else
        return 1;
}
// ==================================
int check_ring1(int ia)
{
    if (is_ring61(ia)) return TRUE;
    if (is_ring51(ia)) return TRUE;
    if (is_ring31(ia)) return TRUE;
    if (is_ring41(ia)) return TRUE;
    return FALSE;
}
// =======================================
int close_contact(int mode)
{
  int i, j;
  double dx,dy,dz;

  for (i=1; i < natom; i++)
  {
    for (j=i+1; j <= natom; j++)
      {
        dx = fabs(atom[i].x - atom[j].x);
        dy = fabs(atom[i].y - atom[j].y);
        dz = fabs(atom[i].z - atom[j].z);
        if ( (dx + dy + dz) < 0.1)
        {
            return FALSE;
        }
      }
  }
    return TRUE;
}

