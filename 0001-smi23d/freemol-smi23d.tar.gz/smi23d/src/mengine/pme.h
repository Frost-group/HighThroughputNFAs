#define MAXFFT 80
#define MAXORDER 12
#define MAXTABLE1 4*MAXFFT + 15
#define MAXGRID  2*(MAXFFT/2) + 1

EXTERN struct t_pme {
       int nfft1,nfft2,nfft3,order;
       int *ifac1, *ifac2, *ifac3;
       double aewald, recip[3][3];
       double bsmod1[MAXFFT], bsmod2[MAXFFT],bsmod3[MAXFFT];
       double *fr1, *fr2, *fr3, **theta1, **theta2, **theta3;
       double **dtheta1, **dtheta2, **dtheta3;
       double wsave1[MAXTABLE1], wsave2[MAXTABLE1],wsave3[MAXTABLE1];
       } pme;
       
EXTERN double qgrid[MAXGRID][MAXGRID][MAXGRID][2];

