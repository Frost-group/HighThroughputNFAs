#define EXTERN

#include "pcwin.h"
#include "pcmod.h"
#include "energies.h"
#include "substr.h"
#include "pot.h"
#include "angles.h"

#include "rings.h"
#include "torsions.h"
#include "nonbond.h"
#include "bonds_ff.h"
#include "derivs.h"
#include "hess.h"
#include "field.h"
#include "atom_k.h"
#include "cutoffs.h"
#include "solv.h"
#include "gmmx.h"
#include "fix.h"

#include <unistd.h>
#include <string.h>

struct t_rotbond {
    int nbonds, bond[200][2], bond_res[200];
    int incl_amide, incl_alkene;
    } rotbond;
struct t_minim_values {
        int iprint, ndc, nconst;
        float dielc;
        } minim_values;
        
struct t_minim_control {
        int type, method, field, added_const;
        char added_path[256],added_name[256];
        } minim_control;
EXTERN struct t_files {
        int nfiles, append, batch, icurrent, ibatno;
        }       files;
char Savename[80];
       
void initialize_pcmodel(char*);
void mmp22mod(int,int);
void pcmfin(int, int);
void initialize(void);
void mmxsub(int);
void check_numfile(int, char *);
void mac2mod(int, int);
void bbchk(void);
void type(void);
void initialize_gmmx(void);
void read_gmmxinp(char*, char*, char*, int);
void run_gmmx(void);
void search_rings(int);

void usage(void) {
  printf("\nUsage: mengine [-hvopcedxi] INPUTFILE\n\n"
	 "-h\tThis help page\n"
	 "-v\tVerbose output\n"
	 "-o\tOutput file name (default: output.sdf)\n"
	 "-p\tMMFF94 Parameter file name (default: mm94.prm)\n"
	 "-c\tConstants parameter file name (default: mmxconst.prm)\n"
	 "-e\tLog file name (default: error.log)\n"
	 "-d\tEvaluate dipole moment\n"
	 "-x\tEvaluate XlogP\n"
	 "-i\tEvaluate vibrational data\n\n");
}

/* ==================================================== */
int main(int argc, char *argv[])
{
    int i;
    char *filename = NULL;
    char *line = NULL;

    char *outfile = NULL;
    char *mmff94file = NULL;
    char *mmxfile = NULL;
    char *logfilename = NULL;

    VERBOSE = 0;
    int flags = 0;

    if (argc < 2) {
      usage();
      exit(-1);
    }    

    int c;
    while ((c = getopt(argc, argv, "e:o:p:c:hvdxi")) != -1) {
      switch(c) {
      case 'd':
	flags = flags | DO_DIPOLE;
	break;
      case 'x':
	flags = flags | DO_XLOGP;
	break;
      case 'i':
	flags = flags | DO_VIBRATION;
	break;
      case 'v':
	VERBOSE = 1;
	break;
      case 'h':
	usage();
	exit(-1);
      case 'o':
	outfile = strdup(optarg);
	break;
      case 'p':
	mmff94file = strdup(optarg);
	break;
      case 'c':
	mmxfile = strdup(optarg);
	break;
      case 'e':
	logfilename = strdup(optarg);
	break;
      case '?':
	if (isprint (optopt))
	  fprintf (stderr, "Unknown option `-%c'.\n", optopt);
	else
	  fprintf (stderr,
		   "Unknown option character `\\x%x'.\n",
		   optopt);
	return 1;
      default:
	abort ();	
      }
    }

    // there should only be 1 non-option argument, which is
    // the smi file to process
    filename = (char*) malloc(sizeof(char*) * strlen(argv[optind]));
    filename = strncpy(filename, argv[optind], strlen(argv[optind]));

    // check whether we got anything, otherwise put in defaults
    if (outfile == NULL) outfile = strdup("output.sdf");
    if (mmff94file == NULL) mmff94file = strdup("mmff94.prm");
    if (mmxfile == NULL) mmxfile = strdup("mmxconst.prm");
    if (logfilename == NULL) logfilename= strdup("error.log");

    pcmoutfile = fopen_path(pcwindir,outfile,"w");
    initialize_pcmodel(mmxfile);
    initialize();
    strcpy(Openbox.fname,filename);
    minim_values.iprint = FALSE;
    initialize_gmmx();

    read_gmmxinp(logfilename, outfile, mmff94file, flags);

    fclose(pcmoutfile);

    free(outfile);
    free(mmff94file);
    free(mmxfile);
    free(logfilename);
    free(filename);

    exit(0);
    return TRUE;
}
//
