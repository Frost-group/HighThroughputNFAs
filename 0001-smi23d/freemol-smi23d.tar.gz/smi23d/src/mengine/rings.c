#define EXTERN extern

#include "pcwin.h"
#include "pcmod.h"

#include "angles.h"
#include "torsions.h"
#include "rings.h"


int isbond(int, int);
int isangle(int,int);
int is_ring31(int);
int is_ring41(int);
int is_ring42(int,int);
int is_ring43(int, int, int);
int is_ring44(int *);
int is_ring51(int);
int is_ring52(int, int);
int is_ring53(int, int, int);
int is_ring54(int, int, int, int);
int is_ring55(int *);
int is_ring61(int);
int is_ring62(int, int);
int is_ring63(int,int,int);
int is_ring66(int *);
void ksort(int, int *);
void message_alert(char *, char *);
int is_cyclo6(int, int *);

int is_ring31(int ia)
{
    int i,j;

    for (i=0; i < rings.nring3; i++)
    {
        for (j=0; j < 3; j++)
        {
            if (ia == rings.r13[i][j])
            {
               return(TRUE);
            }
        }
    }
    return FALSE;
}
/* ============================ */
int is_ring41(int ia)
{
    int i,j, found;

    found = FALSE;
    for (i=0; i < rings.nring4; i++)
    {
        for (j=0; j < 4; j++)
        {
            if (ia == rings.r14[i][j])
            {
                found = TRUE;
                return (found);
            }
        }
    }
    return (found);
}
/* -------------------------------------------------------- */            
int is_ring42(int ia, int ib)
{
    int i,j, k, itmp, jtmp;
    if (ia < ib )
    {
        itmp = ia;
        jtmp = ib;
    }else
    {
        itmp = ib;
        jtmp = ia;
    }
    for (i=0; i < rings.nring4; i++)
    {
        for (j = 0; j < 3; j++)
        {
            if ( itmp == rings.r14[i][j])
            {
                for (k=j+1; k < 4; k++)
                {
                    if (jtmp == rings.r14[i][k])
                       return(TRUE);
                }
            }
        }
    }
    return(FALSE);
}
/* -------------------------------------------------------- */            
int is_ring43(int ia, int ib, int ic)
{
    int i, found;
    int array[5];

    found = FALSE;
    array[0] = ia;
    array[1] = ib;
    array[2] = ic;
    ksort(3,array);
    for (i=0; i < rings.nring4; i++)
    {
        if ( array[0] == rings.r14[i][0] && rings.r14[i][1] == array[1] && rings.r14[i][2] == array[2])
        {
            found = TRUE;
            return(found);
        }
        if ( rings.r14[i][0] == array[0] && rings.r14[i][1] == array[1] && rings.r14[i][3] == array[2])
        {
            found = TRUE;
            return(found);
        }
        if ( rings.r14[i][0] == array[0] && rings.r14[i][2] == array[1] && rings.r14[i][3] == array[2])
        {
            found = TRUE;
            return(found);
        }
        if ( rings.r14[i][1] == array[0] && rings.r14[i][2] == array[1] && rings.r14[i][3] == array[2])
        {
            found = TRUE;
            return(found);
        }
    }
    return(found);
}
/* -------------------------------------------------------- */    
int is_ring44(int *array)
{
    int i;
    for (i=0; i < rings.nring4; i++)
    {
        if (array[0] == rings.r14[i][0] && array[1] == rings.r14[i][1] &&
            array[2] == rings.r14[i][2] && array[3] == rings.r14[i][3])
            return(TRUE);
    }
    return FALSE;
}
/* -------------------------------------------------------- */    
int is_ring51(int ia)
{
    int i,j;

    for(i=0; i < rings.nring5; i++)
    {
        for (j=0; j < 5; j++)
        {
            if (rings.r15[i][j] == ia)
            {
                return(TRUE);
            }
        }
    }
    return(FALSE);
}
/* -------------------------------------------------------- */
int is_ring52(int ia, int ib)
{
    int i, j,k, itmp, jtmp;
    if (ia < ib)
    {
        itmp = ia;
        jtmp = ib;
    }else
    {
        itmp = ib;
        jtmp = ia;
    }
    for (i=0; i < rings.nring5; i++)
    {
       for (j=0; j < 4; j++)
       {
           if (itmp == rings.r15[i][j])
           {
               for (k=j+1; k < 5; k++)
               {
                   if (jtmp == rings.r15[i][k])
                       return(TRUE);
               }
           }
       }
    }
    return(FALSE);
}     
/* -------------------------------------------------------- */    
int is_ring53(int ia, int ib, int ic)
{
    int i, j,k,l;
    int array[5];

    array[0] = ia;
    array[1] = ib;
    array[2] = ic;
    ksort(3,array);
    for (i=0; i < rings.nring5; i++)
    {
        for (j=0; j < 3; j++)
        {
            if (array[0] == rings.r15[i][j])
            {
                for (k=j+1; k < 4; k++)
                {
                    if (array[1] == rings.r15[i][k])
                    {
                        for (l=j+1; l < 5; l++)
                        {
                            if (array[2] == rings.r15[i][l])
                                return(TRUE);
                        }
                    }
                }
            }
        }
    }
    return(FALSE);
}
/* -------------------------------------------------------- */
int is_ring54(int ia, int ib, int ic, int id)
{
    int i;
    int array[5];
    array[0] = ia;
    array[1] = ib;
    array[2] = ic;
    array[3] = id;
    ksort(4,array);
    for (i=0; i < rings.nring5; i++)
    {
        if (array[0] == rings.r15[i][0])
        {
            if (array[1] == rings.r15[i][1])
            {
                if (array[2] == rings.r15[i][2])
                {
                    if (array[3] == rings.r15[i][3])
                       return(TRUE);
                    else if (array[3] == rings.r15[i][4])
                       return(TRUE);
                    else
                       return(FALSE);
                } else if (array[2] == rings.r15[i][3] && array[3] == rings.r15[i][4])
                     return(TRUE);
            } else if (array[1] == rings.r15[i][2] &&
                       array[2] == rings.r15[i][3] && array[3] == rings.r15[i][4])
                       return(TRUE);
            
        } else if (array[0] == rings.r15[i][1] && array[1] == rings.r15[i][2] &&
            array[2] == rings.r15[i][3] && array[3] == rings.r15[i][4])
            return(TRUE); 
    }
    return (FALSE);
}
/* -------------------------------------------------------- */    
int is_ring55(int *array)
{
    int i;
    for(i=0; i < rings.nring5; i++)
    {
        if ( array[0] == rings.r15[i][0] && array[1] == rings.r15[i][1] && array[2] == rings.r15[i][2] &&
             array[3] == rings.r15[i][3] && array[4] == rings.r15[i][4])
             return(TRUE);
    }
    return (FALSE);
}
/* -------------------------------------------------------- */    
int is_ring61(int ia)
{
    int i, j;
    for(i=0; i < rings.nring6; i++)
    {
        for(j=0; j < 6; j++)
        {
            if (ia == rings.r16[i][j])
               return (TRUE);
        }
    }
    return (FALSE);
}
/* -------------------------------------------------------- */
int is_ring62(int ia, int ib)
{
    int i, j,k, itmp, jtmp;
    if (ia < ib)
    {
        itmp = ia;
        jtmp = ib;
    }else
    {
        itmp = ib;
        jtmp = ia;
    }
    for (i=0; i < rings.nring6; i++)
    {
       for (j=0; j < 5; j++)
       {
           if (itmp == rings.r16[i][j])
           {
               for (k=j+1; k < 6; k++)
               {
                   if (jtmp == rings.r16[i][k])
                       return(TRUE);
               }
           }
       }
    }
    return(FALSE);
}     
/* -------------------------------------------------------- */    
int is_ring63(int ia, int ib, int ic)
{
    int i, j, k, l;
    int array[5];

    array[0] = ia;
    array[1] = ib;
    array[2] = ic;
    ksort(3,array);
    for (i=0; i < rings.nring6; i++)
    {
        for (j=0; j < 4; j++)
        {
            if (array[0] == rings.r16[i][j])
            {
                for (k=j+1; k < 5; k++)
                {
                    if (array[1] == rings.r16[i][k])
                    {
                        for (l=k+1; l < 6; l++)
                        {
                            if (array[2] == rings.r16[i][l])
                                return(TRUE);
                        }
                    }
                }
            }
        }
    }
    return(FALSE);
}
/* -------------------------------------------------------- */    
int is_ring66(int *array)
{
    int i;
    for(i=0; i < rings.nring6; i++)
    {
        if ( array[0] == rings.r16[i][0] && array[1] == rings.r16[i][1] && array[2] == rings.r16[i][2] &&
             array[3] == rings.r16[i][3] && array[4] == rings.r16[i][4] && array[5] == rings.r16[i][5])
             return(TRUE);
    }
    return (FALSE);
}
/* -------------------------------------------------------- */    

void get_rings()
{
   int i,j, add_ring, k, l;
   int jatm,katm;
   int array[6];

   rings.nring3 = 0;
   rings.nring4 = 0;
   rings.nring5 = 0;
   rings.nring6 = 0;

// get three membered rings
   for (i=0; i < angles.nang; i++)
   {
       if (isbond(angles.i13[i][0], angles.i13[i][2]))
       {
           array[0] = angles.i13[i][0];
           array[1] = angles.i13[i][1];
           array[2] = angles.i13[i][2];
           ksort(3, array);
           add_ring = TRUE;
           for (j = 0; j < rings.nring3; j++)
           {
               if (array[0] == rings.r13[j][0] && array[1] == rings.r13[j][1]
                 && array[2] == rings.r13[j][2])
               {
                   add_ring = FALSE;
                   break;
               }
           }
           if (add_ring == TRUE)
           {                              
              rings.r13[rings.nring3][0] = array[0];
              rings.r13[rings.nring3][1] = array[1];
              rings.r13[rings.nring3][2] = array[2];
              rings.nring3++;
           }
       }
   }
// get four membered rings
   for(i=1; i <= natom; i++)
   {
       for(j=0; j < MAXIAT; j++)
       {
           if (atom[i].iat[j] != 0 && atom[i].bo[j] != 9)
           {
               jatm = atom[i].iat[j];
               for (k=0; k < MAXIAT; k++)
               {
                   if (atom[jatm].iat[k] != 0 && atom[jatm].bo[k] != 9 && atom[jatm].iat[k] != i)
                   {
                       katm = atom[jatm].iat[k];
                       if (!(isbond(katm,i)))
                       {
                           for(l=0; l < MAXIAT; l++)
                           {
                               if (atom[katm].iat[l] != 0 && atom[katm].bo[l] != 9 && atom[katm].iat[l] != jatm)
                               {
                                   if (isbond(i,atom[katm].iat[l]) )
                                   {
                                        array[0] = i;
                                        array[1] = jatm;
                                        array[2] = katm;
                                        array[3] = atom[katm].iat[l];
                                        ksort(4, array);
                                        if ( is_ring44(array) == FALSE )
                                        {          
                                          rings.r14[rings.nring4][0] = array[0];
                                          rings.r14[rings.nring4][1] = array[1];
                                          rings.r14[rings.nring4][2] = array[2];
                                          rings.r14[rings.nring4][3] = array[3];
                                          rings.nring4++;
                                        }
                                   }
                               }
                           }
                       }
                   }
               }
           }
       }
   }
// get five membered rings
   for(i=0; i < torsions.ntor; i++)
   {
      if (!isbond(torsions.i14[i][0],torsions.i14[i][3]))
      {
        for (j=0; j < MAXIAT; j++)
        {
          jatm = atom[torsions.i14[i][0]].iat[j];
          if ( jatm != torsions.i14[i][1] && jatm != torsions.i14[i][2] && jatm != torsions.i14[i][3] )
          {
              if (isbond(jatm,torsions.i14[i][3]))
              {
                array[0] = jatm;
                array[1] = torsions.i14[i][0];
                array[2] = torsions.i14[i][1];
                array[3] = torsions.i14[i][2];
                array[4] = torsions.i14[i][3];
                ksort(5,array);
                if ( is_ring55(array) == FALSE )
                {               
                   rings.r15[rings.nring5][0] = array[0];
                   rings.r15[rings.nring5][1] = array[1];
                   rings.r15[rings.nring5][2] = array[2];
                   rings.r15[rings.nring5][3] = array[3];
                   rings.r15[rings.nring5][4] = array[4];
                   rings.nring5++;
                   if (rings.nring5 >= natom)
                       message_alert("Error. Too many 5 membered rings!","ERROR");
                       
                }
             }
          }
        }
      }
   }
// get six membered rings
   for(i=0; i <= natom; i++)
   {
       if (atom[i].type != 5 && atom[i].type != 20)
       {
           if (is_cyclo6(i, array))
           {
              ksort(6,array);
              if (is_ring66(array) == FALSE)
              {
                  rings.r16[rings.nring6][0] = array[0];
                  rings.r16[rings.nring6][1] = array[1];
                  rings.r16[rings.nring6][2] = array[2];
                  rings.r16[rings.nring6][3] = array[3];
                  rings.r16[rings.nring6][4] = array[4];
                  rings.r16[rings.nring6][5] = array[5];
                  rings.nring6++;
                  if (rings.nring6 >= natom)
                          message_alert("Error. Too many 6 membered rings!","ERROR");
              }
           }  
       }
   }
  
/*   if (rings.nring3 != 0)
      printf("Number of three membered rings: %d\n",rings.nring3);
   if (rings.nring4 != 0)
      printf("Number of four membered rings: %d\n",rings.nring4);
   if (rings.nring5 != 0)
      printf("Number of five membered rings: %d\n",rings.nring5);
   if (rings.nring6 != 0)
      printf("Number of six membered rings: %d\n",rings.nring6); */
      
}
/* =================================================== */
void ksort(int num, int array[])
{
    int i,temp;
    int found;

L_1:
    found = FALSE;
    for (i=0; i < num-1; i++)
    {
       if (array[i+1] < array[i])
       {
          temp = array[i];
          array[i] = array[i+1];
          array[i+1] = temp;
          found = TRUE;
       }
    }
    if (found == TRUE)
       goto L_1;
}

