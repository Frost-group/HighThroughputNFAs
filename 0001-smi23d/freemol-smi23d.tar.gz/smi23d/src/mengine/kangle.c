#define EXTERN extern
#include "pcwin.h"
#include "pcmod.h"

#include "angles.h"
#include "rings.h"
#include "field.h"
#include "bonds_ff.h"
#include "atom_k.h"

int is_ring43(int, int, int);
int is_ring53(int, int, int);
int is_ring63(int, int, int);
int is_delocalbond(int, int);
int is_TS(int, int, int);
int isbond(int,int);
int find_bond(int,int);
void transtheta(int *, float *, float *, char *, char *, char *, char *);
void ts_four(int *, float *, float *,char *, char *,char *,char *);
long ipack(int ,int ,int ,int);
long kang(int,int,int);
void numeral(int,char *,int);
float get_general_angle(int);


EXTERN struct t_ts_bondorder {
        float fbnd[15];
        }       ts_bondorder;

EXTERN struct t_angk1 {
        int use_ang3, use_ang4, use_ang5;
        int nang, nang3, nang4, nang5;
        int ndel, ndel3, ndel4;
        char  ktype[MAXANGCONST][10],ktype3[MAXANG3CONST][10],ktype4[MAXANG4CONST][10],ktype5[MAXANG5CONST][10];
        char  kdel[MAXANGDEL][10],kdel3[MAXANG3DEL][10],kdel4[MAXANG4DEL][10];
        float con[MAXANGCONST], ang[MAXANGCONST][3];
        float con3[MAXANG3CONST], ang3[MAXANG3CONST][3];        
        float con4[MAXANG4CONST], ang4[MAXANG4CONST][3];        
        float con5[MAXANG5CONST], ang5[MAXANG5CONST][3];
        float condel[MAXANGDEL],  angdel[MAXANGDEL][3];      
        float condel3[MAXANG3DEL], angdel3[MAXANG3DEL][3];      
        float condel4[MAXANG4DEL], angdel4[MAXANG4DEL][3];      
         } angk1;

EXTERN struct t_angkp1 {
        int  npiang;
        char kpa[MAXPIANGCONST][10];
        float pacon[MAXPIANGCONST], panat[MAXPIANGCONST][3], piobp[MAXPIANGCONST];
        } angkp1;

EXTERN  struct t_angf {
        int use_angf, nfang;
        char kftype[MAXANGCONST][10];
        float fcon[MAXANGCONST],fc0[MAXANGCONST],fc1[MAXANGCONST],fc2[MAXANGCONST];
        float fc3[MAXANGCONST],fc4[MAXANGCONST],fc5[MAXANGCONST],fc6[MAXANGCONST];
        } angf;
        
EXTERN int Missing_constants;

void kangle()
{
    long int pi_mask, aromatic_mask;
    int i, j, k, izero, ierr, nh, nRc, nligand, jji;
    int ia, ib, ic, ie;
    int iaa, ibb, icc;
    int cl_a, cl_b, cl_c;
    int nbo1, nb1, nb2;
    char pa[4],pb[4],pc[4],pt[10], pt1[10], pt2[10],pt3[10], pt4[10], pt5[10], pt6[10], pt7[10];
    char zero[4];
    float bkan, at;

    pi_mask = (1L << PI_MASK);
    aromatic_mask = (1 << AROMATIC_MASK);

        if( angles.nang != 0 )
        {
           for( i = 0; i < angles.nang; i++ )
           {
               ia = angles.i13[i][0];
               ib = angles.i13[i][1];
               ic = angles.i13[i][2];
               iaa = atom[ia].type;
               ibb = atom[ib].type;
               icc = atom[ic].type;
               cl_a = atom[ia].tclass;
               cl_b = atom[ib].tclass;
               cl_c = atom[ic].tclass;
               
/* get bond index each bond for MMFF94  */
               nb1 = find_bond(ia,ib);
               nb2 = find_bond(ib,ic);
                              
/* special metal cases */
               if( iaa >= 300)
                    cl_a = 300;
                       
               if( ibb >= 300)
                    cl_b = 300;
                        
               if( icc >= 300)
                    cl_c = 300;

/* special MMX cases  */
               if ( field.type == MMX)
               {                                               
                    if( iaa == 40 )
                         iaa = 2;
                       
                    if( ibb == 40 )
                         ibb = 2;
                        
                    if( icc == 40 )
                         icc = 2;
                         
                }
                numeral(iaa,pa,3);
                numeral(ibb,pb,3);
                numeral(icc,pc,3);
                if( iaa <= icc )
                {
                   strcpy(pt,pa);
                   strcat(pt,pb);
                   strcat(pt,pc);
                }
                if( iaa > icc )
                {
                   strcpy(pt,pc);
                   strcat(pt,pb);
                   strcat(pt,pa);
                }
                izero = 0;
                strcpy(zero,"  0");
                strcpy(pt1,pa); strcat(pt1,pb); strcat(pt1,zero);
                strcpy(pt2,pc); strcat(pt2,pb); strcat(pt2,zero);
                strcpy(pt3,zero); strcat(pt3,pb); strcat(pt3,pc);
                strcpy(pt4,zero); strcat(pt4,pb); strcat(pt4,pa);
                strcpy(pt5,zero); strcat(pt5,pb); strcat(pt5,zero);

                numeral(cl_a,pa,3);
                numeral(cl_b,pb,3);
                numeral(cl_c,pc,3);
                if (cl_a < cl_c)
                {
                   strcpy(pt6,pa); strcat(pt6,pb); strcat(pt6,pc);
                }else
                {
                   strcpy(pt6,pc); strcat(pt6,pb); strcat(pt6,pa);
                }

                if (field.type == MMFF94)
                {
                    cl_a = atom_k.tclass1[atom[ia].type];
                    cl_b = atom_k.tclass1[atom[ib].type];
                    cl_c = atom_k.tclass1[atom[ic].type];
                    numeral(cl_a,pa,3);
                    numeral(cl_b,pb,3);
                    numeral(cl_c,pc,3);
                    if (cl_a < cl_c)
                    {
                       strcpy(pt7,pa); strcat(pt7,pb); strcat(pt7,pc);
                    }else
                    {
                       strcpy(pt7,pc); strcat(pt7,pb); strcat(pt7,pa);
                    }
                }
                angles.acon[i] = 0.0;
                angles.anat[i] = 0.0;
                angles.angtype[i] = HARMONIC;

                ierr = FALSE;
/*     check TS constants  */
/*  check delocalized angles in MMFF94 cyclopropanes */
                if (field.type == MMFF94 && angk1.ndel3 > 0)
                {
                    if (isbond(ia,ic) )
                    {
                        nbo1 = bonds_ff.index[nb1] + bonds_ff.index[nb2];
                        if (nbo1 == 1 || nbo1 == 2)
                        { 
                           for(j=0; j < angk1.ndel3; j++)
                           {
                               if (strcmp(angk1.kdel3[j],pt) == 0)
                               {
                                   angles.acon[i] = angk1.condel3[j];
                                   angles.anat[i] = angk1.angdel3[j][0];
                                   if (nbo1 == 1)
                                      angles.index[i] = 5;
                                   else if (nbo1 == 2)
                                      angles.index[i] = 6;
                                   ierr = TRUE;
                                   break;
                               }
                           }
                        }
                    
                        if (ierr == TRUE)
                          goto L_10;
                    }
                } 
/*     check three membered rings */
                if ( (rings.nring3 > 0) && (angk1.nang3 > 0) )
                {
                    if (isbond(ia,ic))
                    {
/*                         search three membered ring parameters */
                      for (j = 0; j < angk1.nang3; j++)
                      {
                        if ( (strcmp(angk1.ktype3[j],pt) == 0) || (strcmp(angk1.ktype3[j],pt1) == 0) ||
                            (strcmp(angk1.ktype3[j],pt2) == 0) || (strcmp(angk1.ktype3[j],pt3) == 0) ||           
                            (strcmp(angk1.ktype3[j],pt4) == 0) || (strcmp(angk1.ktype3[j],pt5) == 0))
                        {
                           if ( angk1.ang3[j][1] == 0.0 && angk1.ang3[j][2] == 0)
                           {
                             angles.acon[i] = angk1.con3[j];
                             angles.anat[i] = angk1.ang3[j][0];
                             angles.index[i] = 3;
                             ierr = TRUE;
                             break;
                           } else
                           {
                              nh = 0;
                              for (k=0; k < MAXIAT; k++)
                              {
                                ie = atom[ib].iat[k];
                                if ( (atom[ie].type == 5 || atom[ie].type == 36) && (ie != ia) && (ie != ic))
                                  nh++;
                              }
                              angles.acon[i] = angk1.con3[j];
                              angles.anat[i] = angk1.ang3[j][nh];
                              angles.index[i] = 3;
                              ierr = TRUE;
                              break;
                           }
                        }
                     }
                     if (ierr == TRUE)
                       goto L_10;
                     else
                     {
                            Missing_constants = TRUE;
                     }
                    }
                }
/*  check delocalized angles in MMFF94 cyclobutanes */
                if (field.type == MMFF94 && angk1.ndel4 > 0)
                {
                    nRc = is_ring43(ia, ib, ic);
                    if (nRc == TRUE)
                    {
                        nbo1 = bonds_ff.index[nb1] + bonds_ff.index[nb2];
                        if (nbo1 == 1 || nbo1 == 2)
                        {
                           for(j=0; j < angk1.ndel4; j++)
                           {
                               if (strcmp(angk1.kdel4[j],pt) == 0)
                               {
                                   angles.acon[i] = angk1.condel4[j];
                                   angles.anat[i] = angk1.angdel4[j][0];
                                   if (nbo1 == 1)
                                      angles.index[i] = 7;
                                   else if (nbo1 == 2)
                                      angles.index[i] = 8;
                                   ierr = TRUE;
                                   break;
                               }
                            }
                        }
                        if (ierr == TRUE)
                          goto L_10;
                    }
                } 
/*     check four memebered rings */
                if ( (rings.nring4 > 0) && (angk1.nang4 > 0) )
                {
                    nRc = is_ring43(ia, ib, ic);
                    if (nRc == TRUE)
                    {
 /*                        search four membered ring parameters */
                      for (j = 0; j < angk1.nang4; j++)
                      {
                        if ( (strcmp(angk1.ktype4[j],pt) == 0) || (strcmp(angk1.ktype4[j],pt1) == 0) ||
                            (strcmp(angk1.ktype4[j],pt2) == 0) || (strcmp(angk1.ktype4[j],pt3) == 0) ||           
                            (strcmp(angk1.ktype4[j],pt4) == 0) || (strcmp(angk1.ktype4[j],pt5) == 0))
                        {
                           if ( angk1.ang4[j][1] == 0.0 && angk1.ang4[j][2] == 0)
                           {
                             angles.acon[i] = angk1.con4[j];
                             angles.anat[i] = angk1.ang4[j][0];
                             angles.index[i] = 4;
                             ierr = TRUE;
                             break;
                           } else
                           {
                              nh = 0;
                              for (k=0; k < MAXIAT; k++)
                              {
                                ie = atom[ib].iat[k];
                                if ( (atom[ie].type == 5 || atom[ie].type == 36) && (ie != ia) && (ie != ic))
                                  nh++;
                              }
                              angles.acon[i] = angk1.con4[j];
                              angles.anat[i] = angk1.ang4[j][nh];
                              angles.index[i] = 4;
                              ierr = TRUE;
                              break;
                           }
                        }
                     }
                     if (ierr == TRUE)
                        goto L_10;
                     else
                     {
                           Missing_constants = TRUE;                         
                     }
                    }
                }                    
/*     check five membered rings */
                if ( (rings.nring5 > 0) && (angk1.nang5 > 0) )
                {
                    nRc = is_ring53(ia,ib, ic);
                    if (nRc == TRUE)
                    {
 /*                        search five memebered ring parameters */
                      for (j = 0; j < angk1.nang5; j++)
                      {
                        if ( (strcmp(angk1.ktype5[j],pt) == 0) || (strcmp(angk1.ktype5[j],pt1) == 0) ||
                            (strcmp(angk1.ktype5[j],pt2) == 0) || (strcmp(angk1.ktype5[j],pt3) == 0) ||           
                            (strcmp(angk1.ktype5[j],pt4) == 0) || (strcmp(angk1.ktype5[j],pt5) == 0) )
                        {
                           if ( angk1.ang5[j][1] == 0.0 && angk1.ang5[j][2] == 0)
                           {
                             angles.acon[i] = angk1.con5[j];
                             angles.anat[i] = angk1.ang5[j][0];
                             angles.index[i] = 0;
                             ierr = TRUE;
                             break;
                           } else
                           {
                              nh = 0;
                              for (k=0; k < MAXIAT; k++)
                              {
                                ie = atom[ib].iat[k];
                                if ( (atom[ie].type == 5 || atom[ie].type == 36) && (ie != ia) && (ie != ic))
                                  nh++;
                              }
                              angles.acon[i] = angk1.con5[j];
                              angles.anat[i] = angk1.ang5[j][nh];
                              angles.index[i] = 0;
                              ierr = TRUE;
                              break;
                           }
                        }
                     }
                     if (ierr == TRUE)
                        goto L_10;
                     // don't fail on missing 5 ring parameters
                   }
                }
/*  check delocalized angles in MMFF94  */
                if (field.type == MMFF94 && angk1.ndel > 0)
                {
                   if ( bonds_ff.index[nb1] == 1 || bonds_ff.index[nb2] == 1 )
                   {
                      nbo1 = bonds_ff.index[nb1] + bonds_ff.index[nb2];
                      for(j=0; j < angk1.ndel; j++)
                      {
                         if (strcmp(angk1.kdel[j],pt) == 0)
                         {
                             angles.acon[i] = angk1.condel[j];
                             angles.anat[i] = angk1.angdel[j][0];
                             if (nbo1 == 1)
                                angles.index[i] = 1;
                             else if (nbo1 == 2)
                                angles.index[i] = 2;
                             ierr = TRUE;
                             break;
                         }
                      }
                      if (ierr == TRUE)
                        goto L_10;
                   }
                } 
// look for fourier angles
                if (angf.nfang > 0)
                {
                    for (j=0; j < angf.nfang; j++)
                    {
                        if (strcmp(angf.kftype[j],pt) == 0)
                        {
                            angles.fcon[i] = angf.fcon[j];
                            angles.c0[i] = angf.fc0[j];
                            angles.c1[i] = angf.fc1[j];
                            angles.c2[i] = angf.fc2[j];
                            angles.c3[i] = angf.fc3[j];
                            angles.c4[i] = angf.fc4[j];
                            angles.c5[i] = angf.fc5[j];
                            angles.c6[i] = angf.fc6[j];
                            angles.angtype[i] = FOURIER;
                            ierr = TRUE;
                            break;
                        }
                    }
                    if (ierr == TRUE)
                       goto L_10;
                }
                        
/*     check regular parameters  for specific angles*/
                for (j = 0; j < angk1.nang; j++)
                {
                    if ( (strcmp(angk1.ktype[j],pt) == 0) )
                    {
                        if ( angk1.ang[j][1] == 0.0 && angk1.ang[j][2] == 0)
                        {
                          angles.acon[i] = angk1.con[j];
                          angles.anat[i] = angk1.ang[j][0];
                          angles.index[i] = 0;
                          ierr = TRUE;
                          break;
                        } else
                        {
                            nh = 0;
                            for (k=0; k < MAXIAT; k++)
                            {
                                ie = atom[ib].iat[k];
                                if ( (atom[ie].atomnum == 1) && (ie != ia) && (ie != ic))
                                  nh++;
                            }
                            angles.acon[i] = angk1.con[j];
                            angles.anat[i] = angk1.ang[j][nh];
                            angles.index[i] = 0;
                            ierr = TRUE;
                            break;
                        }
                    }
                }
                if (ierr == TRUE)
                   goto L_10;
// did not find any specific look for generalized                         
                for (j = 0; j < angk1.nang; j++)
                {
                    if ( (strcmp(angk1.ktype[j],pt) == 0) || (strcmp(angk1.ktype[j],pt1) == 0)  ||
                         (strcmp(angk1.ktype[j],pt2) == 0) || (strcmp(angk1.ktype[j],pt3) == 0) ||           
                         (strcmp(angk1.ktype[j],pt4) == 0) || (strcmp(angk1.ktype[j],pt5) == 0) ||
                         (strcmp(angk1.ktype[j],pt6) == 0))
                    {
                        if ( angk1.ang[j][1] == 0.0 && angk1.ang[j][2] == 0)
                        {
                          angles.acon[i] = angk1.con[j];
                          angles.anat[i] = angk1.ang[j][0];
                          angles.index[i] = 0;
                          ierr = TRUE;
                          break;
                        } else
                        {
                            nh = 0;
                            for (k=0; k < MAXIAT; k++)
                            {
                                ie = atom[ib].iat[k];
                                if ( (atom[ie].atomnum == 1) && (ie != ia) && (ie != ic))
                                  nh++;
                            }
                            angles.acon[i] = angk1.con[j];
                            angles.anat[i] = angk1.ang[j][nh];
                            angles.index[i] = 0;
                            ierr = TRUE;
                            break;
                        }
                    }
                }                         
                if (ierr == TRUE)
                   goto L_10;
/*     check MMFF for class1 parameters    */
             if (field.type == MMFF94)
             {
                for (j = 0; j < angk1.nang; j++)
                {
                    if ( (strcmp(angk1.ktype[j],pt7) == 0) )
                    {
                        if ( angk1.ang[j][1] == 0.0 && angk1.ang[j][2] == 0)
                        {
                          angles.acon[i] = angk1.con[j];
                          angles.anat[i] = angk1.ang[j][0];
                          angles.index[i] = 0;
                          ierr = TRUE;
                          break;
                        } else
                        {
                            nh = 0;
                            for (k=0; k < MAXIAT; k++)
                            {
                                ie = atom[ib].iat[k];
                                if ( (atom[ie].atomnum == 1) && (ie != ia) && (ie != ic))
                                  nh++;
                            }
                            angles.acon[i] = angk1.con[j];
                            angles.anat[i] = angk1.ang[j][nh];
                            angles.index[i] = 0;
                            ierr = TRUE;
                            break;
                        }
                    }
                }
                if (ierr == TRUE)
                   goto L_10;
             }
             if (ierr != TRUE)
             {
                 bkan = get_general_angle(ibb);
                 angles.acon[i] = 0.80;
                 angles.anat[i] = bkan;
                 angles.index[i] = 0;
// ====  done with angle lookup =============
L_10:
                if (field.type == MMX && ierr != TRUE)
                {
                    if (ibb >= 300)
                    {
                        nligand = 0;
                        jji = 0;
                        for ( k=0; k < MAXIAT; k++)
                        {
                            if (atom[ib].iat[k] != 0 &&  atom[ib].bo[k] != 9)
                              jji++;
                            if (atom[ib].bo[k] == 9)
                              nligand++;
                        }
                        if (jji == 2 && nligand == 0)
                        {
                            angles.acon[i] = .1;
                            angles.anat[i] = 180.;
                        }
                        if ((jji == 3 && nligand == 0) || (jji == 2 && nligand == 1) )
                        {
                            angles.acon[i] = .1;
                            angles.anat[i] = 120.;
                        }    
                        if ((jji == 4 && nligand == 0) || (jji == 3 && nligand == 1) || (jji == 2 && nligand == 2))
                        {
                            if (jji == 4 && (atom[ib].type >= 300 && (atom[ib].flags & (1L << SATMET_MASK) && 
                                atom[ib].flags & (1L << GT18e_MASK) && atom[ib].flags & (1L <<  SQPLAN_MASK) &&
                                !(atom[ib].flags & (1L << LOWSPIN_MASK)))) )
                            { 
                              angles.acon[i] = .0001;
                              angles.anat[i] = 90.;
                            } else
                            {
                              angles.acon[i] = .1;
                              angles.anat[i] = 109.5;
                            }
                        }    
                            
                    }
                }
	     }
	   }
	}
}
// ===================================
// generalized angles for MMFF with no hydrogen minimization
float get_general_angle(int ia)
{
    float angs[80] = {
       109.0, 120.0, 120.0, 180.0, 0.000, 109.0, 0.000, 109.0, 120.0, 118.0,
       0.000, 0.000, 0.000, 0.000, 109.0, 109.0, 120.0, 109.0, 109.0, 90.00,
       0.000, 60.00, 0.000, 0.000, 109.0, 109.0, 0.000, 0.000, 0.000, 90.00,
       0.000, 0.000, 0.000, 109.0, 0.000, 0.000, 120.0, 120.0, 120.0, 120.0,
       120.0, 180.0, 120.0, 120.0, 120.0, 120.0, 0.000, 0.000, 109.0, 0.000,
       109.0, 0.000, 180.0, 120.0, 120.0, 120.0, 120.0, 120.0, 120.0, 180.0,
       180.0, 120.0, 120.0, 120.0, 120.0, 120.0, 120.0, 109.0, 120.0, 109.0,
       0.000, 109.0, 109.0, 120.0, 120.0, 109.0, 0.000, 109.0, 109.0, 109.0 };

       if (ia < 80)
         return (angs[ia-1]);
       else
         return 109.0;
}   
/* --------------------------------- */
long kang(int i,int j,int k)
{
        long int kang_v;
        static long i10000 = 10000;
        static long i100 = 100;

        kang_v = i10000*i + i100*j + k;
        return( kang_v );
} 

/* -------------------- */
long ipack(int i,int j,int k,int l)
{
        long int ipack_v;
        static long itbig = 200000000;
        static long itmid = 2000000;
        static long ithou = 1000;

        ipack_v = itbig*i + itmid*j + ithou*k + l;
        return( ipack_v );
}
