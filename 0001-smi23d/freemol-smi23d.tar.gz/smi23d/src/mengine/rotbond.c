#define EXTERN extern
#include "pcwin.h"
#include "pcmod.h"
#include "utility.h"
#include "substr.h"
        
void matident(float (*)[4]);
void matrotsc(float (*)[4], int, float, float);
void matrotat(float (*)[4], int, float);
void mattrans(float (*)[4], float, float, float);
void matriply(float (*)[4], float (*)[4], float (*)[4]);
void matxform(float (*)[4], int);
void rotb(int, int, int, int, float);
void chain(int, int, int);
double dihdrl(int,int,int,int);
void RefreshScreen(void);
void message_alert(char *, char *);


void rotb(int ia1,int n1,int n2,int ia4, float degree)
{
        int issnum;
        long int mask;
        int i;
        float aa, cos1, cos2, denom, rot1[4][4], sin1, 
         sin2, trans1[4][4], x1, x2, xform1[4][4], xform2[4][4], y1, y2, 
         z1, z2, xtmp, ytmp, ztmp;

        /* subroutine to rotate about a bond. the atoms of the bond are n1 and n2,
         * the degree to rotate is idegree, and issnum is the substructure number
         * we get from chain to tell matxform which atoms to rotate
         * we assume chain has been called to set up the atoms to rotate
         * we use xaxis and xyplan to generate the rotation matrices to put
         * n1 at the origin and n2 on the x axis
         * */

        for( i = 0; i < MAXSS; i++ )
        {
                if(!substr.istract[i])
                        goto L_1;
        }
        fprintf( pcmoutfile, "Error in rotbond- no substructs left\n" );
        goto L_2;

L_1:
        issnum = i;
        mask = (1L << issnum);
        chain( n1, n2, issnum );

        x1 = atom[n1].x;
        y1 = atom[n1].y;
        z1 = atom[n1].z;
        x2 = atom[n2].x - x1;
        y2 = atom[n2].y - y1;
        z2 = atom[n2].z - z1;
        denom = sqrt( x2*x2 + y2*y2 );
        if( fabs( denom ) < .00001 )
        {
                cos1 = 1.0;
                sin1 = 0.0;
        }
        else
        {
                sin1 = -y2/denom;
                cos1 = x2/denom;
        }
        x2 = x2*cos1 - y2*sin1;
        denom = sqrt( x2*x2 + z2*z2 );
        if( fabs( denom ) < .00001 )
        {
                cos2 = 1.0;
                sin2 = 0.0;
        }
        else
        {
                sin2 = z2/denom;
                cos2 = x2/denom;
        }
        aa = degree - dihdrl( ia1, n1, n2, ia4 );

        i = 3;
        xtmp = -x1;
        ytmp = -y1;
        ztmp = -z1;
        mattrans( trans1, xtmp, ytmp, ztmp );
        matrotsc( rot1, i, sin1, cos1 );
        matriply( trans1, rot1, xform1 );

        i = 2;
        matrotsc( rot1, i, sin2, cos2 );
        matriply( xform1, rot1, xform2 );

        i = 1;
        matrotat( rot1, i, aa );
        matriply( xform2, rot1, xform1 );

        i = 2;
        xtmp = -sin2;
        matrotsc( rot1, i, xtmp, cos2 );
        matriply( xform1, rot1, xform2 );

        i = 3;
        xtmp = -sin1;
        matrotsc( rot1, i, xtmp, cos1 );
        matriply( xform2, rot1, xform1 );

        mattrans( trans1, x1, y1, z1 );
        matriply( xform1, trans1, xform2 );

        matxform( xform2, issnum );

        for( i = 1; i <= natom; i++ )
        {
                atom[i].substr[0] &= ~mask ;
        }
L_2:
        return;
} 
/* ------------------------------------------ */
void chain(int ia,int ib,int issnum)
{
        int newmem;
        int i, ij, j;
        long int mask;

        /**** this routine starts at atom ia and fills
         *     iarray with the atoms attached directly
         *     or indirectly to ia but not attached either
         *     directly or indirectly to ib.  iarray is
         *     filled such that a non-zero value for the
         *     i-th member means that atom i is either
         *     directly or indirectly attached to ia. *** */
        /**** zero the output array *** */

        mask = 1L << issnum ;
        
        /**** find the atoms adjacent to ia other than atom ib *** */
        
        for( j = 0; j < MAXIAT; j++ )
        {
           if( atom[ia].iat[j])
           {
               if( atom[ia].iat[j] != ib )
               {
                  atom[atom[ia].iat[j]].substr[0] = 0 ;
                  atom[atom[ia].iat[j]].substr[0] |= mask ;
               }
           }
        }

        /**** repetitively loop through the output array
         *     looking for adjacent atoms until no new
         *     attachments are found *** */
        while( TRUE )
        {
           newmem = FALSE;
           for( i = 1; i <= natom; i++ )
           {
              if( atom[i].substr[0] & mask)   // atom not previously marked
              {
                 for( j = 0; j < MAXIAT; j++ )
                 {
                      if( atom[i].iat[j] != 0 &&  atom[i].iat[j] != ia && !(atom[atom[i].iat[j]].substr[0] & mask))
                      {
                         /**** a new atom has been found *** */
                           atom[atom[i].iat[j]].substr[0] = 0 ;
                           atom[atom[i].iat[j]].substr[0] |= mask ;
                           newmem = TRUE;
                      }
                 }
              }
           }
           /**** check for newly added atoms *** */
           if( !newmem )
              break;
        }
        if( ib )
        {
                if( atom[ib].substr[0] & mask)
                {
                        atom[ib].substr[0] &= ~mask;
                        for( ij = 0; ij < MAXIAT; ij++ )
                        {
                                if( atom[ib].iat[ij] )
                                {
//                                        if( atom[ib].bo[ij] != 9 )
                                        {
                                                if( atom[ib].iat[ij] != ia )
                                                   atom[atom[ib].iat[ij]].substr[0] &= ~mask;
                                        }
                                }
                        }
                }
        }
        return;
} 
