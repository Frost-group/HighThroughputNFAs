#define EXTERN extern

#include "pcwin.h"
#include "pcmod.h"
#include "pot.h"
#include "field.h"
#include "cutoffs.h"
#include "energies.h"
#include "utility.h"
#include "fix.h"
#include "substr.h"
#include "atom_k.h"

void reset_atom_data(void);
void reset_calc_parameters(void);
FILE * fopen_path ( char * , char * , char * ) ;
void InitialTransform(void);
void zero_data(void);
void read_datafiles(char *);
void initialize_pcmodel(char*);
void fixdisreset(void);
void coordreset(void);
void ddrivereset(void);
void hbondreset(void);
void pireset(void);
void generate_bonds(void);
void set_field(void);
void fixangle_reset(void);
void message_alert(char *, char *);
int strmessage_alert(char *);
void gettoken(void);
void free_dotmem(void);
void init_pov(void);
void reset_fixtype(void);
void set_window_title(void);
void remove_file(char *,char *);

struct  t_optimize {
        int param_avail, converge;
        float initial_energy, final_energy, initial_heat, final_heat;
        } optimize_data;


struct t_ts_bondorder {
        float fbnd[15];
        }       ts_bondorder;

EXTERN struct t_files {
        int nfiles, append, batch, icurrent;
        int ibatno;
        } files;

EXTERN struct t_minim_control {
        int type, method, field, added_const;
        char added_path[256],added_name[256];
        } minim_control;

EXTERN struct t_minim_values {
        int iprint, ndc, nconst;
        float dielc;
        } minim_values;

                
EXTERN struct t_units {
        double bndunit, cbnd, qbnd;
        double angunit, cang, qang, pang, sang, aaunit;
        double stbnunit, ureyunit, torsunit, storunit, v14scale;
        double aterm, bterm, cterm, dielec, chgscale;
        } units;


struct t_user {
        int dielec;
        } user;

EXTERN struct t_pcmfile {
        char string[200];
        int head;
        char token[20];
        int state;
        unsigned int nocaps;
        }       pcmfile;

EXTERN struct t_residues {
        int  nchain, ichainstart[10];
        int  ngroup, iresnum[200], irestype[200], istartatom[200];
        }       residues;

EXTERN struct t_dipolemom {
        double total, xdipole, ydipole, zdipole;
       }  dipolemom;

struct t_dmomv {
        float xn,yn,zn,xp,yp,zp;
        } dmomv;

#define NL gettoken(); if (pcmfile.head == 1000) goto L_30;
#define ALPHABETIC      2
#define NUMERIC 1

// =======================================
void message_alert(char *astring, char *title)
{
//    MessageBox(NULL, astring, title, MB_ICONEXCLAMATION);
      printf("%s\n",astring);
}
// ===================================
void initialize_pcmodel(char *mmxfile)
{
    int i;
    char string[256];
        strcpy(pcwindir,"");
        user.dielec = FALSE;
        units.dielec = 1.0;
        dipolemom.total = 0.0;
        use_external_chrg = FALSE;
        use_gast_chrg = FALSE;
        zero_data();
        strcpy(string,mmxfile);
        read_datafiles(string);  
        set_field();
// initialize atom definitions
        atom_def.natomtype = atom_k.natomtype;
        for (i=1; i < MAXATOMTYPE; i++)
        {
                atom_def.type[i] = atom_k.type[i];
                atom_def.valency[i] = atom_k.valency[i];
                atom_def.number[i] = atom_k.number[i];
                atom_def.ligands[i] = atom_k.ligands[i];
                atom_def.weight[i] = atom_k.weight[i];
                strcpy(atom_def.symbol[i],atom_k.symbol[i]);
        }
        LPTYPE = 20;
        if (field.type == MMX ||field.type == MM2 ||field.type == MM3  )
          LPTYPE = 20;
        else
          LPTYPE = 0;
        Openbox.ftype = FTYPE_PCM;
        Savebox.ftype = FTYPE_PCM;
        default_intype = MMX;
        default_outtype = MMX;
        strcpy(Openbox.path,pcwindir);
        strcpy(Savebox.path,pcwindir);
        hbond_flag = TRUE;
        pot.use_hbond = TRUE;
        reset_calc_parameters();
        curtype = 1;
        natom = 0;
        bonds.numbonds = -1;
        residues.ngroup = 0;
/*  minimizer control */
        minim_control.method = 3;
        minim_control.field = MMX;
        minim_control.added_const = FALSE;
// printout
        minim_values.iprint = FALSE;
/*  cutoffs    */
        cutoffs.vdwcut = 10.0;
        cutoffs.pmecut = 9.0;
        cutoffs.chrgcut = 100.0;
        cutoffs.dipcut = 8.0;
/*  solvation stuff  */
        pot.use_bounds = FALSE;
        pot.use_image = FALSE;
        pot.use_deform = FALSE;
        pot.use_solv = FALSE;
}

int initialize(void)
{
    curtype = 1;
    natom = 0;
    bonds.numbonds = -1;
    reset_calc_parameters();
    pot.use_bounds = FALSE;
    pot.use_image = FALSE;
    pot.use_deform = FALSE;
    dipolemom.total = 0.0;
// optimization flags
    optimize_data.param_avail = FALSE;
    optimize_data.converge = FALSE;
    optimize_data.initial_energy = 0.0;
    optimize_data.final_energy = 0.0;
    optimize_data.initial_heat = 0.0;
    optimize_data.final_heat = 0.0;
//
    reset_atom_data();
    return(0);
}
/* ============================================== */
void reset_calc_parameters(void)
{
   flags.noh = False;
   flags.nohyd = False;
   flags.immx = True;

/* default to hydrogen bonding on  */
   minim_values.ndc = 4;
   minim_values.nconst= 0;
}
/* =============================================== */
void pireset()
{
        long int i,mask;
        mask = 1L << PI_MASK;
}
/* =============================================== */
void reset_fixtype()
{
        long int i,mask;
        mask = 1L << NO_RETYPE;
        for (i = 1; i <= natom; i++)
                atom[i].flags &= ~mask;
}
/* ------------------------- */
void hbondreset()
{
        long int i,mask;

        mask = 1L << HBOND_MASK;
        for (i = 1; i <= natom; i++)
                atom[i].flags &= ~mask;
}
/* ------------------------- */
void resetsubstrmem()
{
}
/* ------------------------- */
void coordreset()
{
        long int i,j, mask4,mask5,mask6,mask7,mask8;

        mask4 = 1L << METCOORD_MASK;
        mask5 = 1L << SATMET_MASK;
        mask6 = 1L << GT18e_MASK;
        mask7 = 1L << LOWSPIN_MASK;
        mask8 = 1L << SQPLAN_MASK;

        for (i=1; i <= natom; i++)
        {
                atom[i].flags &= ~mask4;
                atom[i].flags &= ~mask5;
                atom[i].flags &= ~mask6;
                atom[i].flags &= ~mask7;
                atom[i].flags &= ~mask8;

                for (j=0; j < MAXIAT; j++)
                {
                        if (atom[i].bo[j] == 9)
                        {
                                atom[i].bo[j] = 0;
                                atom[i].iat[j] = 0;
                        }
                }
        }
        generate_bonds();
}               
/* ------------------------- */
void fixdisreset()
{
}
/* ============================================== */
void fixangle_reset()
{
}
/* ============================================== */       
void reset_atom_data(void)
{
        int i, j;

    for (i = 0; i < MAXATOM; i++) 
    {
        selatom[i] = 0;
        atom[i].use = 0;
        atom[i].x = 0.0F; atom[i].y = 0.0F; atom[i].z = 0.0F;
        atom[i].color = 0;
        atom[i].chrg_color = 7;
        atom[i].charge = 0.0F;
        atom[i].energy = 0.0F;
        atom[i].atomnum = 0;
        atom[i].serno = 0;
        atom[i].molecule = 0;
        atom[i].residue = 0;
        atom[i].formal_charge = 0;
        atom[i].atomwt = 0.0;
        atom[i].type = 0;
        atom[i].mmx_type = 0;
        atom[i].mm3_type = 0;
        atom[i].mmff_type = 0;
        atom[i].tclass = 0;
        *atom[i].name = '\0';
        atom[i].flags = 0;
        for (j = 0; j < MAXIAT; j++) 
        {
           atom[i].bo[j] = 0;
           atom[i].iat[j] = 0;
        }
        for (j=0; j < MAXSS; j++)
        {
          atom[i].substr[j] = 0;
          substr.istract[j] = 0;
        }
     }
}
#ifdef PCM_WIN
// =======================================
/*int strcasecmp(char *str1,char *str2)
{
     char c1,c2;
     while(1)
     {
         c1 = tolower(*str1++);
         c2 = tolower(*str2++);
         if (c1 < c2) return -1;
         if (c1 > c2) return 1;
         if (c1 == 0) return 0;
     }
} */
// ========================================
/*int strncasecmp(char *s1,char *s2,int n)
{
    int i;
    char c1, c2;
    for (i=0; i<n; i++)
    {
        c1 = tolower(*s1++);
        c2 = tolower(*s2++);
        if (c1 < c2) return -1;
        if (c1 > c2) return 1;
        if (!c1) return 0;
    }
    return 0;
}*/
#endif
// void itoa(int n,char *s, int radix)
//{
//    sprintf(s,"%d",n);
//}
// ========================================
void remove_file(char *path,char *name)
{
    char tempname[255];
    int ix;

    strcpy(tempname,"");
    if ( (ix = strlen(path)) != 0)
    {
        strcpy(tempname,path);
        strcat(tempname,"\\");
        strcat(tempname,name);
    } else
    {
        strcpy(tempname,name);
    }
    remove(tempname);
}
