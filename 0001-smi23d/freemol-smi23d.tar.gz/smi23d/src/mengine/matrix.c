#define EXTERN extern

#include "pcwin.h"
#include "pcmod.h"

void matident(float (*)[4]);
void matrotsc(float (*)[4], int, float, float);
void matrotat(float (*)[4], int, float);
void mattrans(float (*)[4], float, float, float);
void matriply(float (*)[4], float (*)[4], float (*)[4]);
void matxform(float (*)[4], int);

/*     -------------------------------------- */
void matident(float matrix[][4])
{
        int i, j;

        for( i = 0; i < 4; i++ )
        {
            for( j = 0; j < 4; j++ )
            {
               if( i == j )
                  matrix[j][i] = 1.;
               else
                  matrix[j][i] = 0.;
            }
        }
        return;
} 
/*     -------------------------------------- */
void matrotsc(float matrix[][4],int iaxis,float sine,float cose)
{

        matident( matrix );
        if( iaxis == 1 ){
                matrix[1][1] = cose;
                matrix[2][1] = sine;
                matrix[1][2] = -sine;
                matrix[2][2] = cose;
                }
        else if( iaxis == 2 ){
                matrix[0][0] = cose;
                matrix[2][0] = -sine;
                matrix[0][2] = sine;
                matrix[2][2] = cose;
                }
        else if( iaxis == 3 ){
                matrix[0][0] = cose;
                matrix[1][0] = sine;
                matrix[0][1] = -sine;
                matrix[1][1] = cose;
                }
        return;
} 
/*     -------------------------------------- */
void matrotat(float matrix[][4],int iaxis,float angle)
{
        float cose, sine;

        matident( matrix );
        sine = sin( -angle*0.017453 );
        cose = cos( -angle*0.017453 );
        if( iaxis == 1 ){
                matrix[1][1] = cose;
                matrix[2][1] = sine;
                matrix[1][2] = -sine;
                matrix[2][2] = cose;
                }
        else if( iaxis == 2 ){
                matrix[0][0] = cose;
                matrix[2][0] = -sine;
                matrix[0][2] = sine;
                matrix[2][2] = cose;
                }
        else if( iaxis == 3 ){
                matrix[0][0] = cose;
                matrix[1][0] = sine;
                matrix[0][1] = -sine;
                matrix[1][1] = cose;
                }
        return;
} 
/*     -------------------------------------- */
void mattrans(float matrix[][4],float x,float y,float z)
{

        matident( matrix );
        matrix[0][3] = x;
        matrix[1][3] = y;
        matrix[2][3] = z;
        return;
} 
/*     -------------------------------------- */
void matriply(float m1[][4],float m2[][4],float m3[][4])
{
        int i, j, k;

        for( i = 0; i < 4; i++ ){
                for( j = 0; j < 4; j++ ){
                        m3[j][i] = 0.;
                        for( k = 0; k < 4; k++ ){
                                m3[j][i] = m3[j][i] + m1[k][i]*m2[j][k];
                                }
                        }
                }
        return;
} 
/*     -------------------------------------- */
void matxform(float matrix[][4],int issnum)
{
    int i, k;
    long int mask;
    float x1[3];

    mask = 0;
    if (issnum != -1)
    mask = 1L << issnum;

    for( i = 1; i <= natom; i++ )
    {
       if ( (atom[i].substr[0] & mask) || issnum == -1)
       {
           for( k = 0; k < 3; k++ )
           {
                 x1[k] = atom[i].x*matrix[k][0] + atom[i].y*matrix[k][1] + atom[i].z*
                     matrix[k][2] + matrix[k][3];
            }
            atom[i].x = x1[0];
            atom[i].y = x1[1];
            atom[i].z = x1[2];
       }
    }
    return;
}

