#if defined __APPLE__
#define PCM_MAC
#elif defined linux
#define PCM_LINUX
#elif defined __CYGWIN__
#define PCM_LINUX
#endif

#undef PCM_WIN
/* #define PCM_MAC */
/* #undef PCM_LINUX */

#define TRUE True
#define FALSE False

#ifndef PI   /* Avoid Linux Warnings! */
#define PI   3.14159265358979323846
#endif

#define Rad2Deg      (180.0/PI)
#define Deg2Rad      (PI/180.0)
#define AbsFun(a)    (((a)<0)? -(a) : (a))
#define MinFun(a,b)  (((a)<(b))? (a) : (b) )
#define MaxFun(a,b)  (((a)>(b))? (a) : (b) )


#ifdef PCM_WIN

#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <direct.h>
#include <ctype.h>
#include <math.h>
#include <limits.h>
#define strnicmp  strncasecmp
#endif

#ifdef PCM_MAC
#include <Carbon/Carbon.h>
#endif

#ifdef PCM_LINUX
#include <stdio.h>
#include <sys/signal.h>
#include <limits.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#ifndef FREEBSD
#include <malloc.h>
#endif
#define MAX_ARGS     15
#endif


#define DISPLAY 1
#define CTRL    2
#define ALL     3

EXTERN char szarString[128];
EXTERN char szarAppName[20];
EXTERN char szarDRAWINGAppName[30];
EXTERN char szarOutputName[30];
EXTERN char szarPlt1AngName[30];
EXTERN char szarCompareName[30];

struct FileInfoStruct {
  int  ftype ;
  char   path[255] ;
  char   fname[255] ;
} ;

typedef struct FileInfoStruct Boxstruct;
EXTERN Boxstruct Openbox ,Savebox;

#ifdef PCM_WIN
//int strcasecmp(char *,char *);
//int strncasecmp(char *,char *,int);
#endif  // Windows

#ifdef PCM_LINUX
/* Motif Specific */
extern char * fexists_error_message ( void ) ;
extern void * malloc_filename ( char * , char * ) ;
extern int fexists_path ( char * , char * ) ;
extern FILE * fopen_path ( char * , char * , char * ) ;
extern void fullpath_to_fileinfo ( char * , Boxstruct * ) ;
#endif
