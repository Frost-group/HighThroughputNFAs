#define EXTERN extern

#include "pcwin.h"
#include "pcmod.h"
#include "utility.h"

void getvec(void);
void revec(void);
void xaxis(float *, float *, float *);
void xyplan(float *, float *, float *);
void chain(int,int, int);
void message_alert(char *, char *);
void epimer(void);

void epimer()
{
        int i, ii, izaxis, natm1, natm2, natm3, natm4, natm5;
        float xa, ya, za, zdif1, zdif2;
        long int mask;

        if (selatom[1] == 0 || selatom[2] == 0 || selatom[3] == 0 ) 
        {
          message_alert("You must select three atoms - center and two attachments - for epimer","Epimer Setup");
          return;
        }
        natm1 = selatom[1];
        natm2 = selatom[2];
        natm3 = selatom[3];

        getvec();

        natm4 = 0;
        natm5 = 0;
        for( i = 0; i < MAXIAT; i++ )
        {
                if( atom[natm1].iat[i] != 0 && atom[natm1].iat[i] != natm1 && 
                        atom[natm1].iat[i] != natm2 &&  atom[natm1].iat[i] !=  natm3 )
                {
                        if( !natm4 )
                        {
                                natm4 = atom[natm1].iat[i];
                        }
                        else
                        {
                                if( !natm5 )
                                        natm5 = atom[natm1].iat[i];
                        }
                }
        }

        xa = atom[natm1].x;
        ya = atom[natm1].y;
        za = atom[natm1].z;
        for( ii = 1; ii <= natom; ii++ )
        {
                atom[ii].x -= xa;
                atom[ii].y -= ya;
                atom[ii].z -= za;
        }
        zdif1 = atom[natm2].z - atom[natm3].z;
        zdif2 = atom[natm4].z - atom[natm5].z;
        if( zdif1 < 0.0 )
                zdif1 = -zdif1;
        if( zdif2 < 0.0 )
                zdif2 = -zdif2;
        izaxis = 0;
        if( zdif2 < zdif1 )
                izaxis = 1;
        if( izaxis )
        {
                xa = atom[natm5].x;
                ya = atom[natm5].y;
                za = atom[natm5].z;
                for( ii = 1; ii <= natom; ii++ )
                {
                        atom[ii].x -= xa;
                        atom[ii].y -= ya;
                        atom[ii].z -= za;
                }
                xa = atom[natm4].x;
                ya = atom[natm4].y;
                za = atom[natm4].z;

                /*     *** now place these two atoms "natm1, natm4" on x-axis *** */
                xaxis( &xa, &ya, &za );
                xa = atom[natm1].x;
                ya = atom[natm1].y;
                za = atom[natm1].z;
                /*     *** now place the two atoms "namt1, natm3" on xy-plane *** */
                xyplan( &xa, &ya, &za );
        }
        xa = atom[natm2].x;
        ya = atom[natm2].y;
        za = atom[natm2].z;
        for( ii = 1; ii <= natom; ii++ )
        {
                atom[ii].x -= xa;
                atom[ii].y -= ya;
                atom[ii].z -= za;
        }
        xa = atom[natm3].x;
        ya = atom[natm3].y;
        za = atom[natm3].z;
        /*     *** now place these two atoms "natm2, natm3" on x-axis *** */
        xaxis( &xa, &ya, &za );
        xa = atom[natm1].x;
        ya = atom[natm1].y;
        za = atom[natm1].z;
        /*     *** now place the two atoms "namt1, natm3" on xy-plane *** */
        xyplan( &xa, &ya, &za );
        /* place natm1 (chiral center) at 0,0,0 */
        xa = atom[natm1].x;
        ya = atom[natm1].y;
        za = atom[natm1].z;
        for( ii = 1; ii <= natom; ii++ )
        {
                atom[ii].x -= xa;
                atom[ii].y -= ya;
                atom[ii].z -= za;
        }
        /* find and reflect x coord of all atoms attached to natm and natm2 */

        mask = (1 << DOT_SURF);
        for( ii = 1; ii <= natom; ii++ )
                atom[ii].substr[0] &= ~mask ;

        
        chain( natm2, natm1, DOT_SURF);
        for( ii = 1; ii <= natom; ii++ )
        {
            atom[ii].flags &= ~mask;
            if( atom[ii].substr[0] & mask)
            {
                atom[ii].flags |= mask;
                atom[ii].x = -atom[ii].x;
                atom[ii].z = -atom[ii].z;
            }
        }
        
        for( ii = 1; ii <= natom; ii++ )
                atom[ii].substr[0] &= ~mask ;
        chain( natm3, natm1, DOT_SURF );
        
        for( ii = 1; ii <= natom; ii++ )
        {
            if( (atom[ii].substr[0] & mask) && !(atom[ii].flags & mask) )
            {
                atom[ii].flags |= mask;
                atom[ii].x = -atom[ii].x;
                atom[ii].z = -atom[ii].z;
            }
        }
        if( !(atom[natm2].flags & mask) )
        {
                atom[natm2].x = -atom[natm2].x;
                atom[natm2].z = -atom[natm2].z;
        }
        if( !(atom[natm3].flags & mask) )
        {
                atom[natm3].x = -atom[natm3].x;
                atom[natm3].z = -atom[natm3].z;
        }
        /* reorient structure by rotating plane and the axis */
        revec();
        return;
} 


