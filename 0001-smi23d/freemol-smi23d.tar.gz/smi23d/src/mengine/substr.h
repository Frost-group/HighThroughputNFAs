EXTERN struct t_substr {
        int icurstr;
        int show_dummy;
        long int istract[MAXSS];
        char strname[MAXSS][31];
        }       substr;

