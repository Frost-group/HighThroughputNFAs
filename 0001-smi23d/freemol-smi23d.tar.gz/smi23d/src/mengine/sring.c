#define EXTERN extern
#include "pcwin.h"
#include "pcmod.h"
#include "utility.h"

int is_cyclo3(int, int *);
int is_cyclo4(int, int *);
int is_cyclo5(int, int *);
int is_cyclo6(int, int *);
int icompare(int, int *,int *);
int find_rsize(int,int);
int aromatic_5(int,int *);
int aromatic_6(int *);
void get_rsize(int,int,int,int *);
void search_rings(int);

struct t_ringdata {
        int nring3, nring4, nring5, nring6;
        int tot3, tot4, tot5, tot6;
        int **iring3,**iring4,**iring5,**iring6;
       }  ringdata;

void search_rings(int mode)
{
    int i,j,ij,k,unique,ifive,isix;
    int array[7],array1[6],array2[6];
    long int mask3, mask4, mask5, mask6, aromatic_mask;

    if (mode == -1)
    {
       if (ringdata.nring3 > 0)
         free_imatrix(ringdata.iring3, 0,ringdata.nring3, 0,4);
       if (ringdata.nring4 > 0)
         free_imatrix(ringdata.iring4, 0,ringdata.nring4, 0,5);
       if (ringdata.nring5 > 0)
         free_imatrix(ringdata.iring5, 0,ringdata.nring5, 0,6);
       if (ringdata.nring6 > 0)
         free_imatrix(ringdata.iring6, 0,ringdata.nring6, 0,7);
        return;
    }

    mask3 = (1L << RING3);
    mask4 = (1L << RING4);
    mask5 = (1L << RING5);
    mask6 = (1L << RING6);
    aromatic_mask = (1L << AROMATIC_MASK);
    
    for (i=1; i <= natom; i++)
    {
        atom[i].flags &= ~aromatic_mask;
    }

    for (i=1; i <= natom; i++)
    {
       if (atom[i].atomnum > 1)
       {
         if ( !(atom[i].flags & mask3))  // cyclopropane
         {
            if (is_cyclo3(i, array))
                atom[i].flags |= mask3;
         }
         if ( !(atom[i].flags & mask4)) // cyclobutane
         {
            if (is_cyclo4(i, array))
                atom[i].flags |= mask4;
         }
         if ( !(atom[i].flags & mask5)) // cyclopentane
         {
            if (is_cyclo5(i,array))
            {
                for (j=0; j < 5; j++)
                    atom[array[j]].flags |= mask5;
            }
         }
         if ( !(atom[i].flags & mask6)) // cyclohexane
         {
            if (is_cyclo6(i,array))
            {
                for (j=0; j < 6; j++)
                   atom[array[j]].flags |= mask6;
            }
         }
       }
    }
//  count rings and allocate memory
    ringdata.nring3 = 0;
    ringdata.nring4 = 0;
    ringdata.nring5 = 0;
    ringdata.nring6 = 0;
    for (i=1; i <= natom; i++)
    {
        if (atom[i].flags & mask3)
          ringdata.nring3++;
        if (atom[i].flags & mask4)
          ringdata.nring4++;
        if (atom[i].flags & mask5)
          ringdata.nring5++;
        if (atom[i].flags & mask6)
          ringdata.nring6++;
    }
//    ringdata.nring6 /= 2;

    if (ringdata.nring3 > 0)
      ringdata.iring3 = imatrix(0,ringdata.nring3, 0,4);
    if (ringdata.nring4 > 0)
      ringdata.iring4 = imatrix(0,ringdata.nring4, 0,5);
    if (ringdata.nring5 > 0)
      ringdata.iring5 = imatrix(0,ringdata.nring5, 0,6);
    if (ringdata.nring6 > 0)
      ringdata.iring6 = imatrix(0,ringdata.nring6, 0,7);

    for (i=0; i < ringdata.nring5; i++)
    {
        for (j=0; j < 5; j++)
            ringdata.iring5[i][j] = 0;
        ringdata.iring5[i][5] = FALSE;
    }
    for (i=0; i < ringdata.nring6; i++)
    {
        for (j=0; j < 6; j++)
            ringdata.iring6[i][j] = 0;
        ringdata.iring6[i][6] = FALSE;
    }
    
// find rings
    ringdata.tot3 = 0;
    ringdata.tot4 = 0;
    ringdata.tot5 = 0;
    ringdata.tot6 = 0;
    
    for (i=1; i <= natom; i++)
    {
        if (atom[i].flags & mask3)
        {
            is_cyclo3(i,array);
            unique = TRUE;
            for (j=0; j < 3 ;j++)
                array1[j] = array[j];
            for(j=0; j < ringdata.tot3; j++)
            {
                for (k=0; k < 3; k++)
                   array2[k] = ringdata.iring3[j][k];
                if ( icompare(3,array1,array2))
                   unique = FALSE;
            }
            if (unique == TRUE)
            {
                ringdata.iring3[ringdata.tot3][0] = array[0];
                ringdata.iring3[ringdata.tot3][1] = array[1];
                ringdata.iring3[ringdata.tot3][2] = array[2];
                ringdata.tot3++;
            }
        }
        if (atom[i].flags & mask4)
        {
            is_cyclo4(i,array);
            unique = TRUE;
            for (j=0; j < 4 ;j++)
                array1[j] = array[j];
            for(j=0; j < ringdata.tot4; j++)
            {
                for (k=0; k < 4; k++)
                   array2[k] = ringdata.iring4[j][k];
                if ( icompare(4,array1,array2))
                   unique = FALSE;
            }
            if (unique == TRUE)
            {
                ringdata.iring4[ringdata.tot4][0] = array[0];
                ringdata.iring4[ringdata.tot4][1] = array[1];
                ringdata.iring4[ringdata.tot4][2] = array[2];
                ringdata.iring4[ringdata.tot4][3] = array[3];
                ringdata.tot4++;
            }
        }
        if (atom[i].flags & mask5)
        {
            is_cyclo5(i,array);
            unique = TRUE;
            for (j=0; j < 5 ;j++)
                array1[j] = array[j];
            for(j=0; j < ringdata.tot5; j++)
            {
                for (k=0; k < 5; k++)
                   array2[k] = ringdata.iring5[j][k];
                if ( icompare(5,array1,array2))
                   unique = FALSE;
            }
            if (unique == TRUE)
            {
                ringdata.iring5[ringdata.tot5][0] = array[0];
                ringdata.iring5[ringdata.tot5][1] = array[1];
                ringdata.iring5[ringdata.tot5][2] = array[2];
                ringdata.iring5[ringdata.tot5][3] = array[3];
                ringdata.iring5[ringdata.tot5][4] = array[4];
                ringdata.tot5++;
            }
        }
        if (atom[i].flags & mask6)
        {
            is_cyclo6(i,array);
            unique = TRUE;
            for (j=0; j < 6 ;j++)
                array1[j] = array[j];
            for(j=0; j < ringdata.tot6; j++)
            {
                for (k=0; k < 6; k++)
                   array2[k] = ringdata.iring6[j][k];
                if ( icompare(6,array1,array2))
                   unique = FALSE;
            }
            if (unique == TRUE)
            {
                ringdata.iring6[ringdata.tot6][0] = array[0];
                ringdata.iring6[ringdata.tot6][1] = array[1];
                ringdata.iring6[ringdata.tot6][2] = array[2];
                ringdata.iring6[ringdata.tot6][3] = array[3];
                ringdata.iring6[ringdata.tot6][4] = array[4];
                ringdata.iring6[ringdata.tot6][5] = array[5];
                ringdata.tot6++;
            }
        }
    }
 //  now do ring map for fused rings
    for (i=1; i <= natom; i++)
    {
       if ( !(atom[i].flags & aromatic_mask) )
       {
           ifive = find_rsize(5,i);
           isix = find_rsize(6,i);
           if ( isix > 1)   // 6-6 fused ring
           {
               continue;
           } else if (isix == 1 && ifive == 1) // 6-5 fused ring system
           {
               for (ij=0; ij < ringdata.tot6; ij++)
               {
                    get_rsize(i,6,ij,array);
                    isix = aromatic_6(array);
                    if (isix == TRUE)
                    {
                        for(j=0; j < 6; j++)
                        {
                            atom[array[j]].flags |= aromatic_mask;
                        }
                        ringdata.iring6[ij][6] = TRUE;
                    }else
                        ringdata.iring6[ij][6] = FALSE;
               }
               for (ij=0; ij < ringdata.tot5; ij++)
               {
                    get_rsize(i,5,ij,array);
                    isix = aromatic_5(ij,array);
                    if (isix == TRUE)
                    {
                        for(j=0; j < 5; j++)
                        {
                            atom[array[j]].flags |= aromatic_mask;
                        }
                        ringdata.iring5[ij][5] = TRUE;
                    }else
                        ringdata.iring5[ij][5] = FALSE;
               }
           } else if (ifive > 1) // 5-5 fused ring
           {
               continue;
           }
       }
    }
 // now do rest of rings - six rings first
    for (i=0; i < ringdata.tot6; i++)
    {
           for(j=0; j < 6; j++)
              array[j] = ringdata.iring6[i][j];
           isix = aromatic_6(array);
           if (isix == TRUE)
           {
               for(j=0; j < 6; j++)
                  atom[ringdata.iring6[i][j]].flags |= aromatic_mask;
               ringdata.iring6[i][6] = TRUE;
           }else
               ringdata.iring6[i][6] = FALSE;
    }
    for (i=0; i < ringdata.tot5; i++)
    {
           for(j=0; j < 5; j++)
              array[j] = ringdata.iring5[i][j];
           ifive = aromatic_5(i,array);
           if (ifive == TRUE)
           {
               for(j=0; j < 5; j++)
                  atom[ringdata.iring5[i][j]].flags |= aromatic_mask;
               ringdata.iring5[i][5] = TRUE;
           }else
               ringdata.iring5[i][5] = FALSE;
    }
} 

