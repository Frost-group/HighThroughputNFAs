// cutoffs

EXTERN struct t_cutoffs {
           double vdwcut, chrgcut, dipcut,pmecut;
            } cutoffs;
