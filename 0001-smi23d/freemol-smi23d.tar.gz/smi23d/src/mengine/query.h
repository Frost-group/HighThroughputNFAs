#define IDLG_QUERY_CC           59000
#define IDLG_QUERY_DIHED        59010
#define IDLG_QUERY_ANGLE        59020
#define IDLG_QUERY_DIST         59030
#define IDLG_QUERY_SETUP        59040
