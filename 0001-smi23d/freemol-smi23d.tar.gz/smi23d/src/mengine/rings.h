EXTERN struct t_rings {
                int nring3, **r13; //[MAXATOM][3];
                int nring4, **r14; //[MAXATOM][4];
                int nring5, **r15; //[MAXATOM][5];
                int nring6, **r16; //[MAXATOM/2][6];
                } rings;

