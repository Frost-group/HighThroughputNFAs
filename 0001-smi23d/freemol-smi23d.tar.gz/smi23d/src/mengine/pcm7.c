#define EXTERN extern

#include "pcwin.h"
#include "pcmod.h"

#include "energies.h"
#include "angles.h"
#include "rings.h"
#include "torsions.h"
#include "bonds_ff.h"
#include "derivs.h"
#include "hess.h"
#include "pot.h"
#include "gmmx.h"
#include "utility.h"
#include "solv.h"   
#include "field.h"

EXTERN struct  t_optimize {
        int param_avail, converge;
        float initial_energy, final_energy, initial_heat, final_heat;
        } optimize_data;
EXTERN struct t_units {
        double bndunit, cbnd, qbnd;
        double angunit, cang, qang, pang, sang, aaunit;
        double stbnunit, ureyunit, torsunit, storunit, v14scale;
        double aterm, bterm, cterm, dielec, chgscale;
        } units;
                
struct t_cbonds {
        int nbnd, icbonds[MAXCBND][3], lpd[MAXCBND], ia1[MAXCBND],ia2[MAXCBND];
        double vrad[MAXCBND],veps[MAXCBND];
        } cbonds;
EXTERN struct t_high_coord {
        int ncoord, i13[400][3];
        } high_coord;

EXTERN struct t_minim_control {
        int type, method, field, added_const;
        char added_path[256],added_name[256];
        } minim_control;

struct t_dipolemom {
        double total, xdipole, ydipole, zdipole;
       }  dipolemom;
        
EXTERN struct t_minim_values {
        int iprint, ndc, nconst;
        float dielc;
        } minim_values;
struct t_solvent {
    int type;
    double doffset, p1,p2,p3,p4,p5;
    double *shct,*asolv,*rsolv,*vsolv,*gpol,*rborn;
    } solvent;

int Missing_constants;
FILE *errfile;
    
FILE * fopen_path ( char * , char * , char * ) ;
void message_alert(char *,char *);
void get_added_const(void);
void assign_gast_charge();
void lattice(void);
void bounds(void);
void pcm7_min(void);
int iscoord_bond(int, int);
void get_coordbonds(void);
int isbond(int, int);
int isangle(int,int);
int ishbond(int, int);
int istorsion(int, int);
void get_hbond(void);
void mark_hbond(void);
void reset_atom_data(void);
int initialise(void);
void get_bonds(void);
void get_angles(void);
void get_torsions(void);
void get_rings(void);
void set_field(void);
double energy(void);
double print_energy(void);
void pcmfout(int);
void orbital(void);
void free_orbit(void);
void set_active(void);
void estrtor(void);
void echarge(void);
void ewald(void);
void eurey(void);
void ebuck(void);
void ebuckmm3(void);
void estrbnd(void);
void edipole(void);
void etorsion(void);
void eangang(void);
void eangle(void);
void ebond(void);
void eopbend(void);
void ehbond(void);
void eimprop(void);
void eimptors(void);
void elj(void);
void ecoord_bond(void);
void elj_qq(void);
void ebuck_charge(void);
void ehigh_coord(void);

void estrtor1(void);
void echarge1(void);
void ebuck1(void);
void ebuckmm31(void);
void estrbnd1(void);
void edipole1(void);
void etorsion1(void);
void eangang1(void);
void eangle1(void);
void ebond1(void);
void eopbend1(void);
void ehbond1(void);
void eimprop1(void);
void eimptors1(void);
void elj1(void);
void ecoord_bond1(void);
void ewald1(void);
void eurey1(void);
void elj_qq1(void);
void ebuck_charge1(void);
void ehigh_coord1(void);

void kangle(void);
void korbit(void);
void ktorsion(void);
void kdipole(void);
void kstrbnd(void);
void kcharge(void);
void ksolv(void);
void kangang(void);
void kopbend(void);
void kstrtor(void);
void khbond(void);
void piseq(int, int);
void kimprop(void);
void kimptors(void);
void kcoord_bonds(void);
void kvdw(void);
int  kbond(void);
void kewald(void);
void kurey(void);

void get_memory(void);
void free_memory(void);
void gradient(void);
void minimize(void);
void dynamics(void);
void read_datafiles(char *);
void attach(void);
void eheat(void);
void pirite(void);
void charge_dipole(void);
void dipole_dipole(void);
void piden(void);
void hdel(int);
void set_atomtypes(int);
void type(void);
void generate_bonds(void);
void zero_data(void);
void ehal(void);
void ehal1(void);
void ebufcharge(void);
void ebufcharge1(void);
void eopbend_wilson(void);
void eopbend_wilson1(void);
void hbondreset(void);
void vibrate(void);
void pireset(void);
void adjust_mmfftypes(void);
void build_neighbor_list(int);
int setup_calculation(void);
void end_calculation(void);
void egeom1(void);
void esolv1(void);
void egeom(void);
void esolv(void);
void xlogp(float *);

void mmxsub(int ia)
{
    int nret;
    
    minim_control.type = ia;   // 0 to minimize, 1 for single point
    nret = setup_calculation();
    if (nret == FALSE)
    {
         end_calculation();
         return;
    }

    pcm7_min();
    end_calculation();   
}
// ================================================================        
void pcm7_min()
{
  int i, print;
  double etot;

     print = FALSE;
     if (minim_values.iprint == TRUE)
     {
        print = TRUE;
        minim_values.iprint = FALSE;
     }
                
      optimize_data.initial_energy = energies.total;
 
      if (minim_control.type == 1)  // single point calculation
         return;

       minimize();
      
      if (print == TRUE)
         minim_values.iprint = TRUE;
         
      if (minim_values.iprint == TRUE)
         etot = print_energy();
      else
         etot = energy();

      optimize_data.final_energy = energies.total;

//    compute dipole moment here
      dipolemom.xdipole = 0.0;
      dipolemom.ydipole = 0.0;
      dipolemom.zdipole = 0.0;
      if (pot.use_charge || pot.use_bufcharge || use_gast_chrg) charge_dipole();
      if (pot.use_dipole && !use_gast_chrg) dipole_dipole();
      dipolemom.total = sqrt(dipolemom.xdipole*dipolemom.xdipole +
                             dipolemom.ydipole*dipolemom.ydipole +
                             dipolemom.zdipole*dipolemom.zdipole);
}
// ==================================================================
int setup_calculation()
{
    int nRet;
    char string[30];
    double etot;
    if (minim_control.field == MM3)
    {
        // copy mm3 types into type file and retype
        pot.use_hbond = FALSE;
        hbondreset();
        hdel(1);
        strcpy(string,"mm3.prm");
        zero_data();
        read_datafiles(string);
        set_field();
        default_intype = MM3;
        default_outtype = MM3;
        set_atomtypes(MM3);
        generate_bonds();
        if (minim_control.added_const)
           get_added_const();
    } else if (minim_control.field == MMFF94)
    {
        // copy mm3 types into type file and retype
        pot.use_hbond = FALSE;
        pot.use_picalc = FALSE;
        hbondreset();
        pireset();
        hdel(1);
        set_field();
        default_intype = MMFF94;
        default_outtype = MMFF94;
        set_atomtypes(MMFF94);
        generate_bonds();
        if (minim_control.added_const)
           get_added_const();
    } else if (minim_control.field == AMBER)
    {
        pot.use_hbond = FALSE;
        pot.use_picalc = FALSE;
        hbondreset();
        pireset();
        hdel(2);
        set_field();
        generate_bonds();
        if (minim_control.added_const)
           get_added_const();
    } else if (minim_control.field == OPLSAA)
    {
        pot.use_hbond = FALSE;
        pot.use_picalc = FALSE;
        hbondreset();
        pireset();
        hdel(1);
        set_field();
        generate_bonds();
        if (minim_control.added_const)
           get_added_const();
    } else
    {
        if (minim_control.added_const)
        {
           strcpy(string,"mmxconst.prm");
           zero_data();
           read_datafiles(string);
           get_added_const();
        }
        type();
        set_field();
        generate_bonds();
    }

            
  // allocate memeory for derivatives
  get_memory();
 
  // setup bonds, angles, torsions, improper torsions and angles, allenes
  get_bonds();
  get_angles();
  get_torsions();
  get_coordbonds();

  if (high_coord.ncoord > 0)
      pot.use_highcoord = TRUE;

  attach();

  
  get_rings();
  // need allene

  // set active atoms
  set_active();

/*  assign local geometry potential function parameters  */
    Missing_constants = FALSE;
    //     errfile = fopen_path(pcwindir,"pcmod.err","w");
     if (pot.use_bond || pot.use_strbnd)  nRet = kbond();
     if (nRet == FALSE) // use end_calc to free memory
     {
       //         message_alert("Parameters missing. See pcmod.err for information","Error");
         optimize_data.param_avail = 1;
	 //         fclose(errfile);
         energies.total = 9999.;
         return FALSE;
     }
     if (pot.use_angle || pot.use_strbnd || pot.use_angang) kangle();
     if (pot.use_angle || pot.use_opbend || pot.use_opbend_wilson) kopbend();
     if (pot.use_tors  || pot.use_strtor || pot.use_tortor) ktorsion();
     if (pot.use_strbnd) kstrbnd();
      
      if (pot.use_buck || pot.use_hal || pot.use_lj) kvdw();
      if ((pot.use_charge || pot.use_bufcharge || pot.use_ewald) && !use_external_chrg && !use_gast_chrg) kcharge();

       if (Missing_constants == TRUE)
       {
	 //           message_alert("Parameters missing. See pcmod.err for information","Error");
	 //           fclose(errfile);
           optimize_data.param_avail = 1;
           energies.total = 9999.0;
           return (FALSE);
       } else
       {
	 //           fclose(errfile);
	 //           remove("pcmod.err");
       }    
       if (minim_values.iprint == TRUE)
          etot = print_energy();
       else
          etot = energy();
       return TRUE;
}
// =================================================================
void end_calculation()
{
 
    free_memory();
}
// ==================================================================
void gradient()
{
    int i, j;

      energies.estr = 0.0;
      energies.ebend = 0.0;
      energies.estrbnd = 0.0;
      energies.e14 = 0.0;
      energies.evdw = 0.0;
      energies.etor = 0.0;
      energies.eu = 0.0;
      energies.eopb = 0.0;
      energies.eangang = 0.0;
      energies.estrtor = 0.0;
      energies.ehbond = 0.0;
      energies.efix = 0.0;
      energies.eimprop = 0.0;
      energies.eimptors = 0.0;
      energies.eurey = 0.0;
      energies.esolv = 0.0;

      virial.virx = 0.0;
      virial.viry = 0.0;
      virial.virz = 0.0;
      
      for (i=1; i <= natom; i++)
           atom[i].energy = 0.0;
      
      for (i=1; i <= natom; i++)
      {
        for (j=0; j < 3; j++)
        {
            deriv.deb[i][j] = 0.0;
            deriv.dea[i][j] = 0.0;
            deriv.destb[i][j] = 0.0;
            deriv.deopb[i][j] = 0.0;
            deriv.detor[i][j] = 0.0;
            deriv.de14[i][j] = 0.0;
            deriv.devdw[i][j]= 0.0;
            deriv.deqq[i][j] = 0.0;
            deriv.deaa[i][j] = 0.0;
            deriv.destor[i][j] = 0.0;
            deriv.deimprop[i][j] = 0.0;
            deriv.dehb[i][j] = 0.0;
            deriv.desolv[i][j] = 0.0;
        }
      }
   
      if (pot.use_bond)ebond1();
      if (pot.use_angle)eangle1();
      if (pot.use_opbend_wilson) eopbend_wilson1();
      if (pot.use_tors)etorsion1();
      if (pot.use_strbnd)estrbnd1();
     
      // mmff 
      if (pot.use_hal) ehal1();
      if (pot.use_bufcharge) ebufcharge1();
     
      energies.total =  energies.estr + energies.ebend + energies.etor + energies.estrbnd + energies.e14+
                        energies.evdw + energies.eu + energies.ehbond + energies.eangang + energies.estrtor +
                        energies.eimprop + energies.eimptors + energies.eopb + energies.eurey + energies.esolv;
      for (i=1; i <= natom; i++)
      {
          for (j=0; j < 3; j++)
          {
              deriv.d1[i][j] = deriv.deb[i][j] + deriv.dea[i][j] + deriv.deaa[i][j] +
                               deriv.destb[i][j] + deriv.detor[i][j] + deriv.deopb[i][j] + deriv.dehb[i][j] +
                               deriv.destor[i][j] + deriv.deqq[i][j] + deriv.devdw[i][j] + deriv.de14[i][j] +
                               deriv.deimprop[i][j] + deriv.deub[i][j] + deriv.desolv[i][j];

         }
      }
}
// ==================================================================
double energy()
{
    double etot;
    int i;
//    struct timeb start,end;
    
      energies.total = 0.0;
      energies.estr = 0.0;
      energies.ebend = 0.0;
      energies.etor = 0.0;
      energies.estrbnd = 0.0;
      energies.evdw = 0.0;
      energies.e14 = 0.0;
      energies.ehbond = 0.0;
      energies.eu = 0.0;
      energies.eangang = 0.0;
      energies.estrtor = 0.0;
      energies.eimprop = 0.0;
      energies.eimptors = 0.0;
      energies.eopb = 0.0;
      energies.eurey = 0.0;
      energies.esolv = 0.0;

      for (i=1; i <= natom; i++)
           atom[i].energy = 0.0;

      if (pot.use_bond)ebond();
      if (pot.use_angle)eangle();
      if (pot.use_opbend_wilson) eopbend_wilson();
      if (pot.use_tors)etorsion();
      if (pot.use_strbnd)estrbnd();
      // mmff 
      if (pot.use_hal) ehal();
      if (pot.use_bufcharge) ebufcharge();
                              
      energies.total =  energies.estr + energies.ebend + energies.etor + energies.estrbnd
             + energies.evdw + energies.e14 + energies.ehbond + energies.eu + energies.eangang +
               energies.estrtor + energies.eimprop + energies.eimptors + energies.eopb + energies.eurey + energies.esolv;
      etot = energies.total;
      return (etot);
}
/* =========================================================================== */ 
double print_energy()
{
    double etot;
    int i;
    
      energies.total = 0.0;
      energies.estr = 0.0;
      energies.ebend = 0.0;
      energies.etor = 0.0;
      energies.estrbnd = 0.0;
      energies.evdw = 0.0;
      energies.e14 = 0.0;
      energies.ehbond = 0.0;
      energies.eu = 0.0;
      energies.eangang = 0.0;
      energies.estrtor = 0.0;
      energies.eimprop = 0.0;
      energies.eimptors = 0.0;
      energies.eopb = 0.0;
      energies.eurey = 0.0;
      energies.esolv = 0.0;

      for (i=1; i <= natom; i++)
           atom[i].energy = 0.0;

      if (pot.use_bond)ebond();
      if (pot.use_angle)eangle();
      if (pot.use_opbend_wilson) eopbend_wilson();
      if (pot.use_tors)etorsion();
      if (pot.use_strbnd)estrbnd();
      // mmff 
      if (pot.use_hal) ehal();
      if (pot.use_bufcharge) ebufcharge();
      
      energies.total =  energies.estr + energies.ebend + energies.etor + energies.estrbnd
             + energies.evdw + energies.e14 + energies.ehbond + energies.eu + energies.eangang +
               energies.estrtor + energies.eimprop + energies.eimptors + energies.eopb + energies.eurey + energies.esolv;
      etot = energies.total;
      
      return (etot);
}    

/* ================================================================== */

int iscoord_bond(int i, int j)
{
    int k;
    long int mask;

    mask = 1 << METCOORD_MASK ;

    for (k=0; k < MAXIAT; k++)
    {
        if (atom[i].iat[k] == j && atom[i].bo[k] == 9)
        {
            if (atom[i].type >= 300)
            {
                if (atom[j].type == 2 || atom[j].type == 4 || atom[j].type == 29 ||
                    atom[j].type == 30 || atom[j].type == 40 || atom[j].type == 48 )
                      return TRUE;
            }
            if (atom[j].type >= 300)
            {
                if (atom[i].type == 2 || atom[i].type == 4 || atom[i].type == 29 ||
                    atom[i].type == 30 || atom[i].type == 40 || atom[i].type == 48 )
                      return TRUE;
            }
        }
    }
// throughout Metal-lone pairs if coordinated bond
//  metal to donor atom
    if ( (atom[i].type >= 300) && atom[j].flags & mask)
      return TRUE;
    if ( (atom[j].type >= 300) && atom[i].flags & mask)
      return TRUE;
   
    return FALSE;
}

void get_coordbonds()
{
    int i, j, k, iatype, jatm;

    cbonds.nbnd = 0;
    pot.use_coordb = FALSE;
        
    for (i=1; i <= natom; i++)
    {
        if (atom[i].mmx_type >= 300)
        {
           for (j=0; j <= MAXIAT; j++)
           {
               if (atom[i].bo[j] == 9)  // coord bond
               {
                   iatype = atom[atom[i].iat[j]].mmx_type;
                   if (iatype == 2 || iatype == 4 || iatype == 29 ||
                       iatype == 30 || iatype == 40 || iatype == 48 )
                   {
                      cbonds.icbonds[cbonds.nbnd][0] = i;
                      cbonds.icbonds[cbonds.nbnd][1] = atom[i].iat[j];
                      cbonds.icbonds[cbonds.nbnd][2] = 0;
                      cbonds.nbnd++;
                   } else
                   {
                      jatm = atom[i].iat[j];
                      for (k = 0; k < MAXIAT; k++)
                      {
                          if (atom[atom[jatm].iat[k]].mmx_type == 20) // lp
                          {
                              cbonds.icbonds[cbonds.nbnd][0] = i;
                              cbonds.icbonds[cbonds.nbnd][1] = jatm;
                              cbonds.icbonds[cbonds.nbnd][2] = atom[jatm].iat[k];
                              cbonds.nbnd++;
                          }
                      }
                   }
                   if (cbonds.nbnd > MAXCBND)
                   {
                      fprintf(pcmoutfile,"Error - Too many coordinated bonds!\nProgram will now quit.\n");
                       exit(0);
                   }
               }
           }
        }
    }
    if (cbonds.nbnd > 0)
       pot.use_coordb = TRUE;
}
int isbond(int i, int j)
{
    int k;
    for (k=0; k < MAXIAT; k++)
    {
        if (atom[i].iat[k] == j && atom[i].bo[k] != 9)
            return TRUE;
    }
    return FALSE;
}

void get_bonds()
{
    int i, j;
    long int mask;

    bonds_ff.nbnd = 0;
    mask = 1L << 0;     // flag for pi atoms 
    
    for (i=1; i <= natom; i++)
    {
        for (j=i+1; j <= natom; j++)
        {
           if (isbond(i,j))
           {
              bonds_ff.i12[bonds_ff.nbnd][0] = i;
              bonds_ff.i12[bonds_ff.nbnd][1] = j;
              bonds_ff.nbnd++;
              if (bonds_ff.nbnd > MAXBND)
              {
                 fprintf(pcmoutfile,"Error - Too many bonds!\nProgram will now quit.\n");
                 exit(0);
               }
           }
        }
    }
}

