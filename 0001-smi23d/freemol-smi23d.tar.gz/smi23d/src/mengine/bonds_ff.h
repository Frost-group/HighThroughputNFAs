EXTERN struct t_bonds_ff {
        int nbnd, i12[MAXBND][2], idpl[MAXBND][2], index[MAXBND];
        double bk[MAXBND],bl[MAXBND], bmom[MAXBND];
        } bonds_ff;

