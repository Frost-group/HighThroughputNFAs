#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define TRUE 1
#define FALSE 0

int FetchRecord(FILE *, char *);

int main(int argc, char *argv[])
{
    int i,ncount,fcount;
    int MAXLINE = 15625;
    char filename[80],line[2000],outfile[80];
    char astring[2000],pubID[15];
    char tmpname[80],tag[5];
    FILE *infile,*wfile;
    
    // check command line for filename
    if (argc > 1)
       strcpy(filename,argv[1]);
    else
    {
        printf("Enter filename:");
        gets(filename);
    }
    // build outfile name
    for (i=0; i < strlen(filename); i++)
    {
        if (filename[i] != '.' && filename[i] != '\0')
           tmpname[i] = filename[i];
        else
           break;
    }
    tmpname[i] = '\0';
//
    infile = fopen(filename,"r");
    if (infile == NULL)
    {
        printf("Error opening file\n");
        exit(0);
    }
    fcount = -1;
    strcpy(outfile,tmpname);
    strcat(outfile,".new");
    wfile = fopen(outfile,"w");
    while (FetchRecord(infile,line))
    {
        fprintf(wfile,"%s\n",line);
    }
    fclose(infile);
    if (wfile != NULL)
      fclose(wfile);
    return TRUE;
}
/* =============================================  */
int FetchRecord(FILE *fp, char *buffer)
{
      int ch;
      char *ptr;
      
      ptr = buffer;
      do 
      {
         ch = getc(fp);
         if (ch >= ' ')
            *ptr++ = ch;
         else if (ch == '\n')
         {
            *ptr = 0;
            return TRUE;
         } else if (ch == '\r')
         {
            ch = getc(fp);
            if (ch != '\n')
                ungetc(ch,fp);
            *ptr = 0;
            return TRUE;
         } else if (ch == EOF)
         {
             *ptr = 0;
             return (ptr != buffer);
         } else
            *ptr++ = ch;
      } while (ptr < buffer+1999);
      
      do 
      {
           ch = getc(fp);
       } while (ch !='\n' && ch != '\r' && ch != EOF);
       if (ch == '\r')
       {
           ch = getc(fp);
           if (ch != '\n')
              ungetc(ch,fp);
        }
        *ptr = 0;
        return TRUE;
} 

