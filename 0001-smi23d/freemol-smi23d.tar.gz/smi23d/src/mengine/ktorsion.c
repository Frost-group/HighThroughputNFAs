#define EXTERN extern

#include "pcwin.h"
#include "pcmod.h"
#include "torsions.h"
#include "rings.h"
#include "field.h"
#include "atom_k.h"
#include "fix.h"

int isbond(int,int);
int is_delocalbond(int,int);
void numeral(int,char *,int);
void angle(int,int,int,float *);
void four(char *,char *,char *,char *, char *);
int is_ring42(int,int);
int is_ring54(int, int, int, int);
void message_alert(char *, char *);
void  transomeg(float *, float *, float *, int *, int *, char *, char *, char *, char *,
         char *, char *, char *, char *, char *, char *, char *);
        
EXTERN struct t_allene {
    int nallene, ntor[10];
     } allene;
        
        
EXTERN struct t_torkn1 {
        int  use_tor4, use_tor5;
        int  ntor, ntor4, ntor5, ntordel, torindex[MAXTORDEL];
        char  kv[MAXTORCONST][13], kv4[MAXTOR4CONST][13], kv5[MAXTOR5CONST][13];
        char  kvdel[MAXTORDEL][13];
        float tv1[MAXTORCONST], tv2[MAXTORCONST], tv3[MAXTORCONST];
        float tv4[MAXTORCONST], tv5[MAXTORCONST], tv6[MAXTORCONST];
        int   phase1[MAXTORCONST], phase2[MAXTORCONST], phase3[MAXTORCONST];
        int   phase4[MAXTORCONST], phase5[MAXTORCONST], phase6[MAXTORCONST];
        float tv41[MAXTOR4CONST], tv42[MAXTOR4CONST], tv43[MAXTOR4CONST];
        int   phase41[MAXTOR4CONST], phase42[MAXTOR4CONST], phase43[MAXTOR4CONST];
        float tv51[MAXTOR5CONST], tv52[MAXTOR5CONST], tv53[MAXTOR5CONST];
        int   phase51[MAXTOR5CONST], phase52[MAXTOR5CONST], phase53[MAXTOR5CONST];
        float tvdel1[MAXTORDEL], tvdel2[MAXTORDEL], tvdel3[MAXTORDEL];
        int   phasedel1[MAXTORDEL], phasedel2[MAXTORDEL], phasedel3[MAXTORDEL];
        } torkn1;

EXTERN struct t_torknp {
        int npitor;
        char kp[MAXPITORCONST][13];
        int ph1[MAXPITORCONST], ph2[MAXPITORCONST], ph3[MAXPITORCONST];
        float   tv1[MAXPITORCONST], tv2[MAXPITORCONST], tv3[MAXPITORCONST];
        } torknp;


EXTERN struct t_ts_bondorder {
        float fbnd[15];
        }       ts_bondorder;
EXTERN struct t_high_coord {
        int ncoord, i13[400][3];
        } high_coord;
        
EXTERN int Missing_constants;
//EXTERN FILE *errfile;

void ktorsion()
{
    int i, j, ierr, itor, ii, ki, k;
    int ia, ib, ic, id;
    int ita, itb, itc, itd;
    int cl_a, cl_b, cl_c, cl_d;
    int use_ring4, use_ring5;
    long int mask;
    char izero[4];
    char pa[4],pb[4],pc[4],pd[4],pt[13], kv1[13];
    char k1[13], k2[13], k3[13], k4[13], k5[13], k6[13], k7[13], k8[13], k9[13], k10[13],
              k11[13], k12[13], k13[13], k14[13], k15[13];
    float v1, v2, v3, rangle;

    mask = (1L << 0);
    itor = 0;
    use_ring4 = FALSE;
    if (rings.nring4 > 0 && torkn1.ntor4 > 0)
       use_ring4 = TRUE;

    use_ring5 = FALSE;
    if (rings.nring5 > 0 && torkn1.ntor5 > 0)
       use_ring5 = TRUE;

    for (i=0; i < torsions.ntor; i++)
    {
        ia = torsions.i14[i][0];
        ib = torsions.i14[i][1];
        ic = torsions.i14[i][2];
        id = torsions.i14[i][3];

        ita = atom[ia].type;
        itb = atom[ib].type;
        itc = atom[ic].type;
        itd = atom[id].type;

        cl_a = atom[ia].tclass;
        cl_b = atom[ib].tclass;
        cl_c = atom[ic].tclass;
        cl_d = atom[id].tclass;

        if (field.type == MMX)
        {
            if (ita == 40)
               ita = 2;
            if (itb == 40)
               itb = 2;
            if (itc == 40)
               itc = 2;
            if (itd == 40)
               itd = 2;

            if (ita == 56 && itb == 56 && itc == 56 && itd == 56)
            {
                ita = 1; itb = 1; itc = 1; itd = 1;
            }
        }
        numeral(ita,pa,3);
        numeral(itb,pb,3);
        numeral(itc,pc,3);
        numeral(itd,pd,3);
        
        if (itb < itc )
           four(pa,pb, pc, pd, pt);
        else if (itb > itc)
           four(pd,pc, pb, pa, pt);
        else if (ita < itd)
           four(pa,pb, pc, pd, pt);
        else
           four(pd,pc, pb, pa, pt);
        strcpy(izero,"  0");

        if (field.type == MMFF94)
        {

           numeral(atom_k.tclass1[ita],pa,3);
           numeral(atom_k.tclass[itb],pb,3);
           numeral(atom_k.tclass[itc],pc,3);
           numeral(atom_k.tclass1[itd],pd,3);
           
        
           if (atom_k.tclass[itb] < atom_k.tclass[itc] )
           {
              four(pa, pb, pc, izero,k2);
              four(izero ,pb, pc, pd,k3);
           } else if (atom_k.tclass[itb] > atom_k.tclass[itc])
           {
              four(izero,pc, pb, pa, k2);
              four(pd,pc, pb, izero, k3);
           } else if (atom_k.tclass1[ita] < atom_k.tclass1[itd])
           {
              four(pa,pb, pc, izero, k2);
              four(izero,pb, pc, pd, k3);
           } else
           {
              four(izero,pc, pb, pa, k2);
              four(pd,pc, pb, izero, k3);
           }
        } else
        {
           four( izero, pc, pb, pa, k1 );
           four( pd, pc, pb, izero, k2 );
           four( izero, pb, pc, pd, k3 );
        }
        
        numeral(ita,pa,3);
        numeral(itb,pb,3);
        numeral(itc,pc,3);
        numeral(itd,pd,3);

        four( pa, pb, pc, izero, k4 );
        four( izero, pc, pb, izero, k5 );
        four( izero, pb, pc, izero, k6 );
        four( pd, pc, izero, izero, k7 );
        four( izero, izero, pc,pd, k8 );

        four( izero, izero, pb, pa, k9 );
        four( pa, pb, izero, izero, k10 );
        four( izero, izero, pc, izero, k11 );
        four( izero, pc, izero, izero, k12 );
        four( izero, izero, pb, izero, k13 );
        four( izero, pb, izero, izero, k14 );

        numeral(cl_a,pa,3);
        numeral(cl_b,pb,3);
        numeral(cl_c,pc,3);
        numeral(cl_d,pd,3);
        if (itb < itc )
           four(pa,pb, pc, pd, k15);
        else if (itb > itc)
           four(pd,pc, pb, pa, k15);
        else if (ita < itd)
           four(pa,pb, pc, pd, k15);
        else
           four(pd,pc, pb, pa, k15);

        ierr = FALSE;
//   check for linear angles in high coordinate atoms
        if (high_coord.ncoord > 0)
        {
            for (k = 0; k < high_coord.ncoord; k++)
            {
                if (high_coord.i13[k][1] == ib) // high coordinate atom in center
                {
                    if (high_coord.i13[k][0] == ia && high_coord.i13[k][2] == ic)
                    {
                        angle(ia,ib,ic,&rangle);
                        if (rangle > 175 || rangle < -175)
                        {
                           torsions.v1[i] = 0.0;
                           torsions.v2[i] = 0.0;
                           torsions.v3[i] = 0.0;
                           ierr = TRUE;
                           goto L_10;
                        }
                    } else if (high_coord.i13[k][2] == ia && high_coord.i13[k][0] == ic)
                    {
                        angle(ia,ib,ic,&rangle);
                        if (rangle > 175 || rangle < -175)
                        {
                           torsions.v1[i] = 0.0;
                           torsions.v2[i] = 0.0;
                           torsions.v3[i] = 0.0;
                           ierr = TRUE;
                           goto L_10;
                        }
                    }
                } else if ( high_coord.i13[k][1] == ic)
                {
                    if (high_coord.i13[k][0] == ib && high_coord.i13[k][2] == id)
                    {
                        angle(ib,ic,id,&rangle);
                        if (rangle > 175 || rangle < -175)
                        {
                           torsions.v1[i] = 0.0;
                           torsions.v2[i] = 0.0;
                           torsions.v3[i] = 0.0;
                           ierr = TRUE;
                           goto L_10;
                        }
                    } else if (high_coord.i13[k][2] == ib&& high_coord.i13[k][0] == id)
                    {
                        angle(ib,ic,id,&rangle);
                        if (rangle > 175 || rangle < -175)
                        {
                           torsions.v1[i] = 0.0;
                           torsions.v2[i] = 0.0;
                           torsions.v3[i] = 0.0;
                           ierr = TRUE;
                           goto L_10;
                        }
                    }
                }
            }
        }
                    
//  check for four membered rings
        if ( isbond(ia,id) )
        {
          for(j=0; j < torkn1.ntor4; j++)
          {
             strcpy(kv1,torkn1.kv4[j]);
             if (strcmp(pt,kv1) == 0 || strcmp(k1,kv1) == 0 || strcmp(k2,kv1) == 0 || strcmp(k3,kv1) == 0 ||      
                 strcmp(k4,kv1) == 0 || strcmp(k5,kv1) == 0 || strcmp(k6,kv1) == 0 || strcmp(k7,kv1) == 0 ||      
                 strcmp(k8,kv1) == 0 || strcmp(k9,kv1) == 0 || strcmp(k10,kv1) == 0 || strcmp(k11,kv1) == 0 ||      
                 strcmp(k12,kv1) == 0 || strcmp(k13,kv1) == 0 || strcmp(k14,kv1) == 0 )
             {
               torsions.v1[i] =  torkn1.tv41[j];
               torsions.ph1[i] = torkn1.phase41[j];     
               torsions.v2[i] =  torkn1.tv42[j];
               torsions.ph2[i] = torkn1.phase42[j];     
               torsions.v3[i] =  torkn1.tv43[j];
               torsions.ph3[i] = torkn1.phase43[j];
               ierr = TRUE;
               goto L_10;
             }  
          }
        }
//   delocalized torsions 
        if ( is_delocalbond(ib,ic) )
        {
          for(j=0; j < torkn1.ntordel; j++)
          {
             strcpy(kv1,torkn1.kvdel[j]);
             if (strcmp(pt,kv1) == 0 || strcmp(k1,kv1) == 0 || strcmp(k2,kv1) == 0 || strcmp(k3,kv1) == 0 ||      
                 strcmp(k4,kv1) == 0 || strcmp(k5,kv1) == 0 || strcmp(k6,kv1) == 0 || strcmp(k7,kv1) == 0 ||      
                 strcmp(k8,kv1) == 0 || strcmp(k9,kv1) == 0 || strcmp(k10,kv1) == 0 || strcmp(k11,kv1) == 0 ||      
                 strcmp(k12,kv1) == 0 || strcmp(k13,kv1) == 0 || strcmp(k14,kv1) == 0 )
             {
               torsions.v1[i] =  torkn1.tvdel1[j];
               torsions.ph1[i] = torkn1.phasedel1[j];     
               torsions.v2[i] =  torkn1.tvdel2[j];
               torsions.ph2[i] = torkn1.phasedel2[j];     
               torsions.v3[i] =  torkn1.tvdel3[j];
               torsions.ph3[i] = torkn1.phasedel3[j];
               ierr = TRUE;
               goto L_10;
             }  
          }
        }
//   check for five membered rings
         if (is_ring54(ia,ib,ic,id) )
         {
          for(j=0; j < torkn1.ntor5; j++)
          {
             strcpy(kv1,torkn1.kv5[j]);
             if (strcmp(pt,kv1) == 0 || strcmp(k1,kv1) == 0 || strcmp(k2,kv1) == 0 || strcmp(k3,kv1) == 0 ||      
                 strcmp(k4,kv1) == 0 || strcmp(k5,kv1) == 0 || strcmp(k6,kv1) == 0 || strcmp(k7,kv1) == 0 ||      
                 strcmp(k8,kv1) == 0 || strcmp(k9,kv1) == 0 || strcmp(k10,kv1) == 0 || strcmp(k11,kv1) == 0 ||      
                 strcmp(k12,kv1) == 0 || strcmp(k13,kv1) == 0 || strcmp(k14,kv1) == 0 )
             {
               torsions.v1[i] =  torkn1.tv51[j];
               torsions.ph1[i] = torkn1.phase51[j];     
               torsions.v2[i] =  torkn1.tv52[j];
               torsions.ph2[i] = torkn1.phase52[j];     
               torsions.v3[i] =  torkn1.tv53[j];
               torsions.ph3[i] = torkn1.phase53[j];
               ierr = TRUE;
               goto L_10;
             }  
          }
         }
//   check regular parameters
         if (field.type == MMFF94)
         {
             for(j=0; j < torkn1.ntor; j++)   // specific constants
             {
                 strcpy(kv1,torkn1.kv[j]);
                 if (strcmp(pt,kv1) == 0)
                 {
                     torsions.v1[i] = torkn1.tv1[j];
                     torsions.ph1[i] = torkn1.phase1[j];     
                     torsions.v2[i] = torkn1.tv2[j];
                     torsions.ph2[i] = torkn1.phase2[j];     
                     torsions.v3[i] = torkn1.tv3[j];
                     torsions.ph3[i] = torkn1.phase3[j];     
                     torsions.v4[i] = torkn1.tv4[j];
                     torsions.ph4[i] = torkn1.phase4[j];     
                     torsions.v5[i] = torkn1.tv5[j];
                     torsions.ph5[i] = torkn1.phase5[j];     
                     torsions.v6[i] = torkn1.tv6[j];
                     torsions.ph6[i] = torkn1.phase6[j];
                     goto L_10;
                 }
             }
             for(j=0; j < torkn1.ntor; j++)  //  class 2
             {
                 strcpy(kv1,torkn1.kv[j]);
                 if (strcmp(k2,kv1) == 0 || strcmp(k3,kv1) == 0 )
                 {
                     torsions.v1[i] = torkn1.tv1[j];
                     torsions.ph1[i] = torkn1.phase1[j];     
                     torsions.v2[i] = torkn1.tv2[j];
                     torsions.ph2[i] = torkn1.phase2[j];     
                     torsions.v3[i] = torkn1.tv3[j];
                     torsions.ph3[i] = torkn1.phase3[j];     
                     torsions.v4[i] = torkn1.tv4[j];
                     torsions.ph4[i] = torkn1.phase4[j];     
                     torsions.v5[i] = torkn1.tv5[j];
                     torsions.ph5[i] = torkn1.phase5[j];     
                     torsions.v6[i] = torkn1.tv6[j];
                     torsions.ph6[i] = torkn1.phase6[j];
                     goto L_10;
                 }
             }
             for(j=0; j < torkn1.ntor; j++)  // wild cards
             {
                 strcpy(kv1,torkn1.kv[j]);
                 if (strcmp(k5,kv1) == 0 || strcmp(k6,kv1) == 0 || strcmp(k7,kv1) == 0 || strcmp(k8,kv1) == 0 )
                 {
                     torsions.v1[i] = torkn1.tv1[j];
                     torsions.ph1[i] = torkn1.phase1[j];     
                     torsions.v2[i] = torkn1.tv2[j];
                     torsions.ph2[i] = torkn1.phase2[j];     
                     torsions.v3[i] = torkn1.tv3[j];
                     torsions.ph3[i] = torkn1.phase3[j];     
                     torsions.v4[i] = torkn1.tv4[j];
                     torsions.ph4[i] = torkn1.phase4[j];     
                     torsions.v5[i] = torkn1.tv5[j];
                     torsions.ph5[i] = torkn1.phase5[j];     
                     torsions.v6[i] = torkn1.tv6[j];
                     torsions.ph6[i] = torkn1.phase6[j];
                     goto L_10;
                 }
             }
         }              
// check regular specific parameters
         for(j=0; j < torkn1.ntor; j++)
         {
             strcpy(kv1,torkn1.kv[j]);
             if (strcmp(pt,kv1) == 0)
             {
               torsions.v1[i] = torkn1.tv1[j];
               torsions.ph1[i] = torkn1.phase1[j];     
               torsions.v2[i] = torkn1.tv2[j];
               torsions.ph2[i] = torkn1.phase2[j];     
               torsions.v3[i] = torkn1.tv3[j];
               torsions.ph3[i] = torkn1.phase3[j];     
               torsions.v4[i] = torkn1.tv4[j];
               torsions.ph4[i] = torkn1.phase4[j];     
               torsions.v5[i] = torkn1.tv5[j];
               torsions.ph5[i] = torkn1.phase5[j];     
               torsions.v6[i] = torkn1.tv6[j];
               torsions.ph6[i] = torkn1.phase6[j];
               goto L_10;
               break;
             }  
          }
// check regular generalized parameters
         for(j=0; j < torkn1.ntor; j++)
         {
             strcpy(kv1,torkn1.kv[j]);
             if (strcmp(pt,kv1) == 0 || strcmp(k1,kv1) == 0 || strcmp(k2,kv1) == 0 || strcmp(k3,kv1) == 0 ||      
                 strcmp(k4,kv1) == 0 || strcmp(k5,kv1) == 0 || strcmp(k6,kv1) == 0 || strcmp(k7,kv1) == 0 ||      
                 strcmp(k8,kv1) == 0 || strcmp(k9,kv1) == 0 || strcmp(k10,kv1) == 0 || strcmp(k11,kv1) == 0 ||      
                 strcmp(k12,kv1) == 0 || strcmp(k13,kv1) == 0 || strcmp(k14,kv1) == 0 || strcmp(k15,kv1) == 0)
             {
               torsions.v1[i] = torkn1.tv1[j];
               torsions.ph1[i] = torkn1.phase1[j];     
               torsions.v2[i] = torkn1.tv2[j];
               torsions.ph2[i] = torkn1.phase2[j];     
               torsions.v3[i] = torkn1.tv3[j];
               torsions.ph3[i] = torkn1.phase3[j];     
               torsions.v4[i] = torkn1.tv4[j];
               torsions.ph4[i] = torkn1.phase4[j];     
               torsions.v5[i] = torkn1.tv5[j];
               torsions.ph5[i] = torkn1.phase5[j];     
               torsions.v6[i] = torkn1.tv6[j];
               torsions.ph6[i] = torkn1.phase6[j];
               goto L_10;
               break;
             }  
          }
//  missing parameters
          if (ierr == FALSE)
          {
//              Missing_constants = TRUE;
          }
L_10:
    continue;
    }

    if (allene.nallene > 0)
    {
        for (i = 0; i < allene.nallene; i++)
        {
            torsions.v1[allene.ntor[i]] = 0;
            torsions.v2[allene.ntor[i]] = -11.5;
            torsions.v3[allene.ntor[i]] = 0;
        }
    }
}
/*  --------------------------------------------   */
void four(char *pa, char *pb, char *pc, char *pd, char *pt)
{
        strcpy(pt,pa);
        strcat(pt,pb);
        strcat(pt,pc);
        strcat(pt,pd);
} 
