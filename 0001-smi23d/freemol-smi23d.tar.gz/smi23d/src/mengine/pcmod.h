#ifndef True
#define True 1
#define False 0
#endif 

#include "pcmsiz.h"

/* These flags allow us to choose whether to do the extra calculations */
#define DO_VIBRATION     2
#define DO_DIPOLE        4
#define DO_XLOGP         8

/* Global to indicate verbose output or not */
EXTERN int VERBOSE;

#define MAXSELBND 50
#define MAXQUERY  100

EXTERN  int     LPTYPE;

#define radian 57.29577951308

#define Retype 122
EXTERN int hitcount;

#define         MMX             1
#define         MM2             2
#define         MM3             3
#define         MM4             4
#define         AMBER           5
#define         CHARMM          6
#define         MMFF94          7
#define         OPLS            8
#define         OPLSAA          9
#define         UNKNOWN         10

// File Information
#define FTYPE_MMX                   102
#define FTYPE_MM2                   103
#define FTYPE_MM3                   104
#define FTYPE_ALC                   106
#define FTYPE_SYBYL                 107
#define FTYPE_MMOD                  108
#define FTYPE_PCM                   109
#define FTYPE_XRA                   110
#define FTYPE_C3D                   111
#define FTYPE_MOL                   112
#define FTYPE_PDB                   115
#define FTYPE_CSD                   118
#define FTYPE_SDF                   123
#define FTYPE_TINKER                124
#define FTYPE_MOL2                  125

#define FTYPE_MOP                   105
#define FTYPE_ARC                   114
#define FTYPE_GAU                   113   // read gaussian output
#define FTYPE_GAUSOUT               119   // write gaussian job file
#define FTYPE_GAU_IRC               122
#define FTYPE_GAUSFCHK              128
#define FTYPE_PSGVBIN               116
#define FTYPE_PSGVBOUT              117
#define FTYPE_GAMES                 120
#define FTYPE_GAMESOUT              121
#define FTYPE_EHT                   126
#define FTYPE_HONDO                 127
#define FTYPE_HONDOPUN              131
#define FTYPE_TURBOMOLE             129
#define FTYPE_ADF                   130

#define FTYPE_SMILES                131
#define FTYPE_CHEMDRAW              132
#define FTYPE_XML                   133
#define FTYPE_CML                   134

#define SUB_MOVE                        0
#define SUB_HIDE                        1
#define SUB_MINIMIZE                    2

//  flags definitions
#define PI_MASK                 0
#define HBOND_MASK              1
#define AROMATIC_MASK           2
//  metal flags
#define METCOORD_MASK           3
#define SATMET_MASK             4
#define GT18e_MASK              5
#define LOWSPIN_MASK            6
#define SQPLAN_MASK             7

// type rules
#define NO_RETYPE               8
//  invisible
#define VIS_MASK                9
//  minimize 
#define MIN_MASK                10
// cpk surface
#define CPK_SURF                11
//  dotsurf
#define DOT_SURF                12
// Nterm, CNterm, Oterm, COterm, DUMMY
#define NTERM                   13
#define CNTERM                  14
#define OTERM                   15
#define COTERM                  16
#define DUMMY                   17
#define P5                      18
#define P3                      19
// Ring Size
#define RING3                   20
#define RING4                   21
#define RING5                   22
#define RING6                   23

/*  PCMODEL specific definitions */
#ifndef ATOMTYPE
typedef struct {
                        double x,y,z;
                        int type;
                        int tclass;
                        int mmx_type;
                        int mm3_type;
                        int amber_type;
                        int mmff_type;
                        int charm_type;
                        int opls_type;
                        int atomnum;
                        int serno;
                        int molecule;
                        int residue;
                        int biotype;
                        double atomwt;
                        float energy;
                        int use;
                        int color;
                        int chrg_color;
                        int iat[MAXIAT];
                        int bo[MAXIAT];
                        char name[3];
                        double charge;
                        float formal_charge;
                        float sigma_charge;
                        float radius;
                        float vdw_radius;
                        long int flags;
                        long int substr[MAXSSCLASS];
                        } ATOMTYPE;
#endif

EXTERN struct {
                int numbonds;
                int ia1[MAXATOM], ia2[MAXATOM], bondorder[MAXATOM];
                } bonds;

EXTERN struct {
                int   istereo;
                int   noh;
                int   immx;
                int   minimized;
                int   modified;
                float dielc;
                float avleg;
                int   rescale;
                int   nohyd; } flags;

EXTERN struct {
                int nquery, qatom[MAXQUERY][4],qtype[MAXQUERY];
                float qxpos[MAXQUERY],qypos[MAXQUERY];
                int queryon;
                } query;

EXTERN ATOMTYPE         atom[MAXATOM];
EXTERN int              selatom[MAXATOM];
EXTERN int              selbnd[MAXSELBND][2];
EXTERN int              last_atom;
EXTERN int              natom;
EXTERN int              DrawAtoms, DrawBonds;
EXTERN long             StrScale;
EXTERN long             MaxAtomRadius;
EXTERN float            currentx,currenty,currentz;
EXTERN int              curtype;
EXTERN int              cur_label;
EXTERN int              curmetal;
EXTERN int              cur_color;
EXTERN char             Struct_Title[100];
EXTERN FILE             *pcmoutfile, *PSfile, *HPGLfile;
EXTERN char             pcwindir[80];
EXTERN int              hbond_flag;
EXTERN int              cmap[225][3];
EXTERN int              Mopac_Charges;
EXTERN int              use_external_chrg;
EXTERN int              use_gast_chrg;
EXTERN int              default_intype, default_outtype;

