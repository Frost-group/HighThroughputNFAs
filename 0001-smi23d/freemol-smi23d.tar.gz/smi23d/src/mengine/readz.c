#define EXTERN extern

#include "pcwin.h"
#include "pcmod.h"
#include "substr.h"
#include "utility.h"

#define MAIN 0L
#define SUBSTRUCTURE 1L

struct t_mopdata {
        int iaopt, ibopt, idopt;
        int scf1, ef, force,precise, grad, vectors;
        int Hamiltonian;
        char keywords[90],title[80],title1[80];
        } mopdata;
EXTERN struct ElementType { char symbol[3];
                             int atomnum;
                             float weight, covradius, vdwradius;
                              int s,p,d,f, type;
                            } Elements[];

void distjm(int,int, float *);
void angljm(int, int, int, float *);
void type(void);
void hdel(int);
void hadd(void);
double dihdrl(int, int, int, int);
void generate_bonds(void);
void readz(int, int);
void read_arcfile(int, int);
void mopaco(int,int);
int make_atom(int,float,float,float,char *);
void message_alert(char *, char *);
void z2xyz(int, float *, float *, float *,int *, int *, int *,float *, float *, float *);
int is_metal(char *);
FILE * fopen_path ( char * , char * , char * ) ;
int FetchRecord(FILE *, char *);

float      *bl, *alpha, *beta, *mcharge;
float      *xtmp, *ytmp, *ztmp;

void readz(int mndotype, int isubred)
{
        FILE       *infile;

        char       inputline[251], dummy[3];
        int        i,j,ibotptr,niatom,idummy,newatom;
        int        ia1, ia2, ia3;
        int        inumarg, iline, ntemp;
        int        icart, isym;
        float      wtt,blen, bangle, dihed;
        int        *na, *nb, *nc, *mtype;
        int        metalcount;
              
        if (isubred == MAIN)
        {
                ibotptr = 0;
        }else
        {
                ibotptr = natom;
                substr.istract[substr.icurstr] = TRUE;
        }

        infile = fopen_path(Openbox.path,Openbox.fname,"r");

        FetchRecord(infile,inputline);  // keyword
        FetchRecord(infile,inputline);  // title
        strncpy(Struct_Title,inputline,60);
        FetchRecord(infile,inputline);  // comment

        ntemp= 0;
        metalcount = 0;
        icart = FALSE;
        isym = TRUE;
        while ( FetchRecord(infile,inputline))
        {
            inumarg = sscanf(inputline,"%s %f %d %f %d %f %d %d %d %d %f ", 
                dummy, &blen, &j, &bangle, &j, &dihed, &j, &ia1, &ia2,
                &ia3, &wtt);
            if (inumarg == 1 && ntemp > 1)
               break;
             if (inumarg <= 0)
                break;
           if (inumarg > 0)
                ntemp++;
            if (ntemp == 1 && ia1 == 99)
               icart = TRUE;
            if (ntemp == 1)
            {
                if (isdigit(dummy[0]) != 0)
                  isym = FALSE;
            }
        }

        fclose(infile);

        bl = vector(0, ntemp);
        alpha = vector(0,ntemp);
        beta = vector(0,ntemp);
        mcharge = vector(0,ntemp);
        mtype = ivector(0,ntemp);
        na = ivector(0,ntemp);
        nb = ivector(0,ntemp);
        nc = ivector(0,ntemp);
        xtmp = vector(0,ntemp);
        ytmp = vector(0,ntemp);
        ztmp = vector(0,ntemp);
                
        for (i = 0; i < ntemp; i++)
        {
                bl[i] = 0.0F;
                alpha[i] = 0.0F;
                beta[i] = 0.0F;
                mtype[i] = 0;
                na[i] = 0;
                nb[i] = 0;
                nc[i] = 0;
        }

        infile = fopen_path(Openbox.path,Openbox.fname,"r");
        FetchRecord(infile,inputline);
        FetchRecord(infile,inputline);
        FetchRecord(infile,inputline);
        niatom = 0;
        iline = 0;
        while ( FetchRecord(infile,inputline)) 
        {
            iline++;
            blen = 0.0F;
            bangle = 0.0F;
            dihed = 0.0F;
            ia1 = 0;
            ia2 = 0;
            ia3 = 0;
            inumarg = sscanf(inputline,"%s %f %d %f %d %f %d %d %d %d %f ", 
                dummy, &blen, &j, &bangle, &j, &dihed, &j, &ia1, &ia2,
                &ia3, &mcharge[niatom]);

             if ( inumarg >= 10 && (strcmp(dummy,"0") == 0))  // termination with line of 0's
                goto L_10;
             else if ( inumarg >= 10)
             {
                 bl[niatom] = blen;
                 alpha[niatom] = bangle;
                 beta[niatom] = dihed;
                 na[niatom] = ia1;
                 nb[niatom] = ia2;
                 nc[niatom] = ia3;
              } else if (inumarg == 1 && iline > 4)
              {
                 goto L_10;
              } else if (iline  == 1)
              {
                 bl[niatom] = 0.0F;
                 alpha[niatom] = 0.0F;
                 beta[niatom] = 0.0F;
                 na[niatom] = 0;
                 nb[niatom] = 0;
                 nc[niatom] = 0;
               } else if (iline == 2) // line 2
               {
                 sscanf(inputline,"%s %f %d %d %d %d", dummy, &blen, &j, &ia1, &ia2, &ia3); 
                 bl[niatom] = blen;
                 na[niatom] = ia1;
                 nb[niatom] = 0;
                 nc[niatom] = 0;
               } else if (iline == 3)  // line 3
               {
                 sscanf(inputline,"%s %f %d %f %d %d %d %d", dummy, &blen, &j, &bangle,&j,&ia1, &ia2, &ia3); 
                 bl[niatom] = blen;
                 alpha[niatom] = bangle;
                 na[niatom] = ia1;
                 nb[niatom] = ia2;
                 nc[niatom] = 0;
               } else if (inumarg < 10 && iline > 4)
                 goto L_10;

                if (isdigit(dummy[0]) != 0)  // we have atomic numbers
                    mtype[niatom] = atoi(dummy);
                else if (strcasecmp(dummy,"XX") == 0 || dummy[0] == 'X')
                    mtype[niatom] = 99;
                else
                {
                    for (j=0; j < 103; j++)
                    {
                        if (strcasecmp(dummy,Elements[j].symbol) == 0)
                        {
                            mtype[niatom] = Elements[j].atomnum;
                            break;
                        }
                    }
                }
                idummy = mtype[niatom];
                niatom++;
        }
L_10:
        fclose(infile);
        if (icart == FALSE)
            z2xyz(niatom,bl,alpha,beta,na,nb,nc,xtmp,ytmp,ztmp);
        else
        {
            for (i=0; i < niatom; i++)
            {
                xtmp[i] = bl[i];
                ytmp[i] = alpha[i];
                ztmp[i] = beta[i];
            }
        }

                /*  need to remove dummy atoms */
        while( TRUE )
        {
           idummy = 0;
           for (i=0; i < niatom; i++)
           {
              if (mtype[i] == 99) 
              {
                 idummy = 1;
                 for ( j = i; j < niatom-1; j++)
                 {
                    mtype[j] = mtype[j+1];
                    xtmp[j] = xtmp[j+1];
                    ytmp[j] = ytmp[j+1];
                    ztmp[j] = ztmp[j+1];
                  }
                  mtype[niatom] = 0;
                  xtmp[niatom] = 0.0F;
                  ytmp[niatom] = 0.0F;
                  ztmp[niatom] = 0.0F;
                }
            }
            if (idummy != 1)
            break;
        }

   /*  generate atoms   */
       idummy = 0;
       for (i= 0; i < niatom; i++)
       {
          if (mtype[i] > 0)
          {
             newatom = make_atom(0,xtmp[i],ytmp[i],ztmp[i],Elements[mtype[i]-1].symbol);
             if (isubred == 1)
             {
                atom[newatom].substr[0] = 0;
                atom[newatom].substr[0] |= (1L << substr.icurstr);
             }
          }

       }

                  
    /*  need to generate bonds using mopaco */
    mopaco(ibotptr+1,natom);

    free_vector(bl, 0,ntemp);
    free_vector(alpha, 0,ntemp);
    free_vector(beta, 0,ntemp);
    free_vector(mcharge, 0,ntemp);
    free_ivector(na, 0,ntemp);
    free_ivector(nb, 0,ntemp);
    free_ivector(nc, 0,ntemp);
    free_ivector(mtype, 0,ntemp);
    free_vector(xtmp, 0,ntemp);
    free_vector(ytmp, 0,ntemp);
    free_vector(ztmp, 0,ntemp);
}
/* =========================================  */
void read_arcfile(int isel, int isubred)
{
        FILE       *infile;

        char       inputline[251],atomchar[3];
        char       *p;
        int        i,j,ibotptr,niatom,idummy,newatom;
        int        ia1, ia2, ia3;
        int        inumarg, iline, ntemp, ipoint;
        float      blen, bangle, dihed;
        int        *na, *nb, *nc, *mtype;
        float      *bl, *alpha, *beta, *mcharge;
        float      *xtmp, *ytmp, *ztmp;
        
        if (isubred == MAIN)
                ibotptr = 0;
        else
                ibotptr = natom;
                
        infile = fopen_path(Openbox.path,Openbox.fname,"r");
        if (infile == NULL)
        {
                message_alert("Error reading arc file","Arcfile Setup");
                return;
        }
        iline = 0;
        while ( FetchRecord(infile,inputline) )
              iline++;
        fclose(infile);
        infile = fopen_path(Openbox.path,Openbox.fname,"r");
       
        ntemp = iline-3;
        bl = vector(0, ntemp);
        alpha = vector(0,ntemp);
        beta = vector(0,ntemp);
        mcharge = vector(0,ntemp);
        mtype = ivector(0,ntemp);
        na = ivector(0,ntemp);
        nb = ivector(0,ntemp);
        nc = ivector(0,ntemp);
        xtmp = vector(0,ntemp);
        ytmp = vector(0,ntemp);
        ztmp = vector(0,ntemp);

        for (i = 0; i <= ntemp; i++)
        {
                bl[i] = 0.0F;
                alpha[i] = 0.0F;
                beta[i] = 0.0F;
                mtype[i] = 0L;
                na[i] = 0L;
                nb[i] = 0L;
                nc[i] = 0L;
        }

       ipoint = 0;
        while ( FetchRecord(infile,inputline) )
        {
                p = strtok(inputline," ");
                if (p != NULL)
                {
                   if (strcasecmp(p,"FINAL") == 0)
                     ipoint++;
                   if (ipoint == isel)
                     goto L_20;
                }
        }

L_20:
// start file read
        FetchRecord(infile,inputline);  // keyword
        FetchRecord(infile,inputline);  // title
        strncpy(Struct_Title,inputline,60);
        FetchRecord(infile,inputline);  // comment

        niatom = 0;
        iline = 0;
        while ( FetchRecord(infile,inputline)) 
        {
                        iline++;
                        blen = 0.0F;
                        bangle = 0.0F;
                        dihed = 0.0F;
                        ia1 = 0;
                        ia2 = 0;
                        ia3 = 0;
                        inumarg = sscanf(inputline,"%s %f %d %f %d %f %d %d %d %d %f ", 
                                atomchar, &blen, &j, &bangle, &j, &dihed, &j, &ia1, &ia2,
                                &ia3, &mcharge[niatom]);

                        if (strcmp(atomchar,"0") == 0)  // end of file in Ampac
                           goto L_10;
                           
                        if ( inumarg >= 10)
                        {
                                bl[niatom] = blen;
                                alpha[niatom] = bangle;
                                beta[niatom] = dihed;
                                na[niatom] = ia1+ibotptr;
                                nb[niatom] = ia2+ibotptr;
                                nc[niatom] = ia3+ibotptr;
                        } else if (inumarg == 1 && iline > 4)
                        {
                                goto L_10;
                        } else if (inumarg == 1 && iline  == 1)
                        {
                                bl[niatom] = 0.0F;
                                alpha[niatom] = 0.0F;
                                beta[niatom] = 0.0F;
                                na[niatom] = 0+ibotptr;
                                nb[niatom] = 0+ibotptr;
                                nc[niatom] = 0+ibotptr;

                        } else if (inumarg == 4 && iline == 2) // line 2
                        {
                                bl[niatom] = blen;
                                na[niatom] = (int) bangle+ibotptr;
                        } else if (inumarg == 7 && iline == 3)  // line 3
                        {
                                bl[niatom] = blen;
                                alpha[niatom] = bangle;
                                na[niatom] = (int) dihed+ibotptr;
                                nb[niatom] = j+ibotptr;
                        } else if (inumarg < 10 && iline > 4)
                                goto L_10;

                        for (j=0; j < 103; j++)
                        {
                            if (strcasecmp(atomchar,Elements[j].symbol) == 0)
                            {
                                mtype[niatom] = Elements[j].atomnum;
                                break;
                            }
                        }
                        niatom++;
        }
L_10:
        fclose(infile);

        z2xyz(niatom,bl,alpha,beta,na,nb,nc,xtmp,ytmp,ztmp);

                /*  need to remove dummy atoms */
        while( TRUE )
        {
            idummy = 0;
            for (i=0; i < niatom; i++)
            {
               if (mtype[i] == 99) 
               {
                  idummy = 1;
                  for ( j = i; j < niatom-1; j++)
                  {
                     mtype[j] = mtype[j+1];
                     xtmp[j] = xtmp[j+1];
                     ytmp[j] = ytmp[j+1];
                     ztmp[j] = ztmp[j+1];
                   }
                   mtype[niatom] = 0;
                   xtmp[niatom] = 0.0F;
                   ytmp[niatom] = 0.0F;
                   ztmp[niatom] = 0.0F;
                }
           }
       if (idummy != 1)
       break;
      }

   /*  generate atoms   */
       for (i= 0; i < niatom; i++)
          newatom = make_atom(0,xtmp[i],ytmp[i],ztmp[i],Elements[mtype[i]-1].symbol);


   /*  need to set atom types  and charges */
        for (i = ibotptr; i < ibotptr + niatom; i++) 
            atom[i+1].charge= mcharge[i];
                  
   /*  need to generate bonds using mopaco */
         mopaco(ibotptr+1,natom);
         
    free_vector(bl, 0,ntemp);
    free_vector(alpha, 0,ntemp);
    free_vector(beta, 0,ntemp);
    free_vector(mcharge, 0,ntemp);
    free_ivector(na, 0,ntemp);
    free_ivector(nb, 0,ntemp);
    free_ivector(nc, 0,ntemp);
    free_ivector(mtype, 0,ntemp);
    free_vector(xtmp, 0,ntemp);
    free_vector(ytmp, 0,ntemp);
    free_vector(ztmp, 0,ntemp);
}
/* ======================================================= */
void z2xyz(int nat, float *bl, float *ang, float *dihed,int *na, int *nb, int *nc,
           float *xtmp, float *ytmp, float *ztmp)
{
    // nat = number of atoms
    // bl, ang, dihed, na, nb, nc  = internal coord and connectivity
    // xtmp, ytmp, ztmp  = new cartesian coordinates

        int i, k, ma, mb, mc;
        float ccos, cosa, cosd, coskh, cosph, costh, dpr, pi, rbc, sina, 
         sind, sinkh, sinph, sinth, xa, xb, xd, xpa, xpb, xpd, xqa, xqd, 
         xrd, xyb, ya, yb, yd, ypa, ypd, yqd, yza, za, zb, zd, zpd, zqa, 
         zqd;

        /*    nz = end number of atoms
         *    nat = start number of atoms = ibotptr
         *     converts z matrix to cartesians.obtain as many cartesian sets
         *     as entries in z matrix, so dummy atoms are included. */

        pi = 4*atan( 1.0F );
        dpr = 180.0F/pi;
// atom 1
        xtmp[0] = 0.0F;
        ytmp[0] = 0.0F;
        ztmp[0] = 0.0F;
// atom 2
        xtmp[1] = bl[1];
        ytmp[1] = 0.0F;
        ztmp[1] = 0.0F;

        if (nat > 2)
        {
            // atom 3
            ccos = cos(ang[2]/dpr);
            if ( na[2] == 1)
                xtmp[2] = xtmp[0] + bl[2]*ccos;
            else
                xtmp[2] = xtmp[1] - bl[2]*ccos;
                
            ytmp[2] = bl[2]*sin(ang[2]/dpr);
            ztmp[2] = 0.0;

            // atom 4 to end
            for (i=3; i < nat; i++)
            {
                cosa = cos(ang[i]/dpr);
                mb = nb[i]-1;
                mc = na[i]-1;
                xb = xtmp[mb] - xtmp[mc];
                yb = ytmp[mb] - ytmp[mc];
                zb = ztmp[mb] - ztmp[mc];
                rbc = 1.0F/sqrt(xb*xb + yb*yb + zb*zb);
                if ( fabs(cosa) < (1.0 - 1.0e-10))
                {
                    // atoms are not collinear
                    ma = nc[i]-1;
                    xa = xtmp[ma]-xtmp[mc];
                    ya = ytmp[ma]-ytmp[mc];
                    za = ztmp[ma]-ztmp[mc];
                    xyb = sqrt(xb*xb + yb*yb);
                    k = -1;
                    if (xyb <= 0.1F)
                    {
                        xpa = za;
                        za = -xa;
                        xa = xpa;
                        xpb = zb;
                        zb = -xb;
                        xb = xpb;
                        xyb = sqrt( xb*xb + yb*yb );
                        k = 1;
                    }
/*       rotate about the y-axis to make zb vanish */
                    costh = xb/xyb;
                    sinth = yb/xyb;
                    xpa = xa*costh + ya*sinth;
                    ypa = ya*costh - xa*sinth;
                    sinph = zb*rbc;
                    cosph = sqrt( fabs( 1.e00 - sinph*sinph ) );
                    xqa = xpa*cosph + za*sinph;
                    zqa = za*cosph - xpa*sinph;
/*       rotate about the x-axis to make za=0, and ya positive. */
                    yza = sqrt( ypa*ypa + zqa*zqa );
                    if( yza < 1.e-4 )
                    {
/*       angle too small to be important */
                        coskh = 1.0F;
                        sinkh = 0.0F;
                    } else
                    {
                        coskh = ypa/yza;
                        sinkh = zqa/yza;
                    }
/*       coordinates :-   a=(xqa,yza,0),   b=(rbc,0,0),  c=(0,0,0)
 *       none are negative.
 *       the coordinates of i are evaluated in the new frame. */
                    sina = sin( ang[i]/dpr );
                    sind = -sin( dihed[i]/dpr );
                    cosd = cos( dihed[i]/dpr );
                    xd = bl[i]*cosa;
                    yd = bl[i]*sina*cosd;
                    zd = bl[i]*sina*sind;
/*       transform the coordinates back to the original system. */
                    ypd = yd*coskh - zd*sinkh;
                    zpd = zd*coskh + yd*sinkh;
                    xpd = xd*cosph - zpd*sinph;
                    zqd = zpd*cosph + xd*sinph;
                    xqd = xpd*costh - ypd*sinth;
                    yqd = ypd*costh + xpd*sinth;
                    if( k >= 1 )
                    {
                        xrd = -zqd;
                        zqd = xqd;
                        xqd = xrd;
                    }
                    xtmp[i] = xqd + xtmp[mc];
                    ytmp[i] = yqd + ytmp[mc];
                    ztmp[i] = zqd + ztmp[mc];
                }else
                {
/*       atom mc, mb and i are collinear */
                    rbc *= bl[i]*cosa;
                    xtmp[i] = xtmp[mc] + xb*rbc;
                    ytmp[i] = ytmp[mc] + yb*rbc;
                    ztmp[i] = ztmp[mc] + zb*rbc;
                }     
            }
        }
}
// =======================================
void write_mopac()
{
        int **bvec, **dvec;  
        int  i, i1, ndx, mckel,
         iatk1, ihvy, ij, katm1, katm2, katm3 ,
         iorn, ipass, j, k, jatm, katm, katm4,
         lps, niatm,  nrec, *order, *maxn;
        float xangl, xdist;
        double xdihe;
        FILE    *mopfile;

/*   allocate space for bvec and dvec  */

        bvec = imatrix(0,MAXIAT,1,natom+1);
        dvec = imatrix(0L,3L,1L,natom+1);
        order = ivector(0, natom+1);
        maxn = ivector(0,natom+1);
 
    if (selatom[1] != 0 && selatom[2] != 0 && selatom[3] != 0)
    {
       katm1 = selatom[1];
       katm2 = selatom[2];
       katm3 = selatom[3];
       mckel = 1;
     }else
     {
       katm1 = 1;
       katm2 = 2;
       katm3 = 3;
       mckel = 0;
     }  

        lps = 0;
        /*     see if we have lone pairs or metals */
        for( i = 1; i <= natom; i++ )
        {
                if( atom[i].type == 20 )
                        lps = 1;
        }

           if( lps == 1 )
                hdel(1);
           type();
           mopfile = fopen_path(Savebox.path,Savebox.fname,"w");

 
/*  MOPAC  */
           fprintf(mopfile,"%s\n",mopdata.keywords);
           fprintf(mopfile,"%s\n",mopdata.title);
           fprintf(mopfile,"%s\n",mopdata.title1);

           for( ij = 1; ij <= natom; ij++ )
           {
                order[ij] = 0;
                maxn[ij] = 0;
                ndx = 0;
                for (i=0; i < MAXIAT; i++)
                {
                    if (atom[ij].iat[i] != 0)
                    {
                        if (atom[ij].iat[i] > ndx && atom[ij].iat[i] < ij)
                            ndx = atom[ij].iat[i];
                    }
                }
                maxn[ij] = ndx;
                if (ndx == 0 && ij == 2)
                    maxn[ij] = 1;
                else if (ndx == 0 && ij == 3)
                    maxn[ij] = 2;
                if (ndx == 0 && ij > 3)   // check on separate structures
                {
                    maxn[ij] = maxn[ij-1];
                }
           }
           for( i = 1; i <= natom; i++ )
           {
                for( k = 0; k < 4; k++ )
                {
                        dvec[k][i] = 0.;
                }
                for( k = 0; k < MAXIAT; k++ )
                {
                        bvec[k][i] = atom[i].iat[k];
                }
           }



           i1 = katm1;
           order[katm1] = 1;
           dvec[0][i1] = i1;
           dvec[1][i1] = 0;
           dvec[2][i1] = 0;
           dvec[3][i1] = 0;

           fprintf( mopfile, "%2s%12.6f%3d%12.6f%3d%12.6f%3d %3d %3d %3d \n",  Elements[atom[i1].atomnum-1].symbol,
                0.0, 0, 0.0, 0, 0.0, 0, 0, 0, 0);
 
           i1 = katm2;
            order[katm2] = 2;
            dvec[0][i1] = katm2;
            dvec[1][i1] = katm1;
            dvec[2][i1] = 0;
            dvec[3][i1] = 0;
            distjm( dvec[0][i1], dvec[1][i1], &xdist );
            fprintf( mopfile, "%2s%12.6f%3d%12.6f%3d%12.6f%3d %3d %3d %3d \n", 
                  Elements[atom[i1].atomnum-1].symbol, xdist, mopdata.ibopt,0.0, 0, 0.0, 0, order[dvec[1][i1]], 0, 0 );

            i1 = katm3;
            order[katm3] = 3;
            dvec[0][i1] = katm3;
            dvec[1][i1] = katm2;
            dvec[2][i1] = katm1;
            dvec[3][i1] = 0;
            for (ij=0; ij < MAXIAT; ij++)  // check to see if 3 is bonded to 1
            {
                if (atom[katm3].iat[ij] != 0 && atom[katm3].iat[ij] == katm1)
                {
                 dvec[1][i1] = katm1;
                 dvec[2][i1] = katm2;
                 break;
                }
            } 
            distjm( dvec[0][i1], dvec[1][i1], &xdist );
            angljm( dvec[0][i1], dvec[1][i1], dvec[2][i1], &xangl );
            fprintf( mopfile, "%2s%12.6f%3d%12.6f%3d%12.6f%3d %3d %3d %3d \n", 
                   Elements[atom[i1].atomnum-1].symbol, xdist, mopdata.ibopt, xangl, mopdata.iaopt, 0.0, 0, order[dvec[1][i1]], 
                  order[dvec[2][i1]], 0 );

            nrec = 3;
            niatm = katm3;
            ipass = 0;
            ihvy = 0;

            if (mckel == 0)
            {
                for (ij = 4; ij <= natom; ij++)
                {       
                    i1 = ij;
                    order[ij] = ij;
                    dvec[0][i1] = ij;
                    dvec[1][i1] = maxn[ij];
                    if (maxn[ij] == 1)
                    { 
                       dvec[2][i1] = 2;
                       dvec[3][i1] = 3;
                    } else if (maxn[ij] == 2)
                    {
                       dvec[3][i1] = 3;
                    }
                    if (dvec[2][i1] == 0)
                       dvec[2][i1] = maxn[maxn[ij]];
                    if (dvec[3][i1] == 0)
                       dvec[3][i1] = maxn[dvec[2][i1]];
                    if (dvec[3][i1] == 0)
                    {
                       jatm = dvec[2][i1];
                       for (i=0; i < MAXIAT; i++)
                        {
                            if (atom[jatm].iat[i] != 0 && atom[jatm].iat[i] != dvec[1][i1] && atom[jatm].iat[i] != dvec[0][i1])
                            {
                                dvec[3][i1] = atom[jatm].iat[i];
                                break;
                            }
                        }
                    }
                       
                    if (dvec[3][i1]*dvec[2][i1]*dvec[1][i1] == 0)
                        message_alert("bad vector in mopac setup","Error");

                    distjm( dvec[0][i1], dvec[1][i1], &xdist );
                    angljm( dvec[0][i1], dvec[1][i1], dvec[2][i1], &xangl );
                    xdihe = dihdrl( dvec[0][i1], dvec[1][i1], dvec[2][i1], dvec[3][i1] );
                    fprintf( mopfile, "%2s%12.6f%3d%12.6f%3d%12.6f%3d %3d %3d %3d \n", 
                           Elements[atom[i1].atomnum-1].symbol, xdist, mopdata.ibopt, xangl, mopdata.iaopt, 
                          xdihe, mopdata.idopt, order[dvec[1][i1]], 
                          order[dvec[2][i1]], order[dvec[3][i1]] );
                }
            } else
            {

              while( TRUE )
              {
                if( niatm > natom )
                  niatm = 1;
                if( order[niatm] && atom[niatm].iat[1] > 0 )
                {
                  for( j = 0; j < MAXIAT; j++ )
                  {
                    katm = bvec[j][niatm];
                    if( katm != 0 )
                    {
                     if( (atom[katm].iat[1] != 0 && ihvy == 0) || (atom[katm].iat[1] == 0 && ihvy == 1) )
                     {
                        if( katm && !order[katm] )
                        {
                           nrec += 1;
                           if( nrec == 4 )
                             katm4 = katm;
                           if( nrec > natom )
                             goto L_200;
                           order[katm] = nrec;
                           dvec[0][katm] = katm;
                           iorn = order[niatm];
                           if( iorn == 1 )
                           {
                              dvec[1][katm] = katm1;
                              dvec[2][katm] = katm2;
                              dvec[3][katm] = katm3;
                            }else if( iorn == 2 )
                            {
                               dvec[1][katm] = katm2;
                               if( !atom[katm3].iat[1] )
                               {
                                  dvec[2][katm] = katm1;
                                  for( ij = 0; ij < MAXIAT; ij++ )
                                  {
                                     iatk1 = atom[katm1].iat[ij];
                                     if( iatk1 )
                                     {
                                        if( iatk1 != katm2 && order[iatk1] > 0 )
                                          goto L_98766;
                                     }
                                   }
                                   dvec[3][katm] = katm3;
                                   goto L_110;
L_98766:
                                   dvec[3][katm] = iatk1;
                                }else
                                {
                                    dvec[2][katm] = katm3;
                                    dvec[3][katm] = katm1;
                                 }
                              }else
                              {
                                  dvec[1][katm] = dvec[0][niatm];
                                  dvec[2][katm] = dvec[1][niatm];
                                  dvec[3][katm] = dvec[2][niatm];
                               }
L_110:
                               distjm( dvec[0][katm], dvec[1][katm], &xdist );
                               angljm( dvec[0][katm], dvec[1][katm], dvec[2][katm], &xangl );
                               xdihe = dihdrl( dvec[0][katm], dvec[1][katm], dvec[2][katm], dvec[3][katm] );
                               fprintf( mopfile, "%2s%12.6f%3d%12.6f%3d%12.6f%3d %3d %3d %3d \n", 
                                     Elements[atom[katm].atomnum-1].symbol, xdist, mopdata.ibopt, xangl, mopdata.iaopt, 
                                    xdihe, mopdata.idopt, order[dvec[1][katm]], 
                                    order[dvec[2][katm]], order[dvec[3][katm]] );
                             }
                          }
                       }
                    }
                }

                if( nrec == natom )
                        goto L_200;
                if( niatm == natom )
                        ipass += 1;
                if( ipass <= 5 )
                {
                        niatm += 1;
                }
                else if( nrec < natom && !ihvy )
                {
                        ipass = 0;
                        ihvy = 1;
                }
                else
                {
                        break;
                }
              }
            goto L_98765;
            }
L_200:
        ;
                fprintf(mopfile,"\n");

L_98765:
        fclose(mopfile);
        free_imatrix(bvec,0,MAXIAT,1,natom+1);
        free_imatrix(dvec,0,3,1,natom+1);
        free_ivector(order,0, natom+1);
        free_ivector(maxn,0, natom+1);
        
        if( lps == 1 )
           hadd();
        generate_bonds();
        return;
} 


/*---------------------------------------------------------------- */
void distjm(int id1,int id2, float *xdist)
{
        float xdf, xx, ydf, zdf;


        xdf = atom[id1].x - atom[id2].x;
        ydf = atom[id1].y - atom[id2].y;
        zdf = atom[id1].z - atom[id2].z;

        xx = xdf*xdf + ydf*ydf + zdf*zdf;
        if( xx < 0.0 )
                xx = 0.0;
        *xdist = sqrt( xx );
        return;
} 
/*--------------------------------------------------------------- */
void angljm(int ia1, int ia2, int ia3, float *xangl)
{
        int i, ia[3], j;
        float a[3], aa123, b[3], bb123, fxcos, p[3][3], xa, xb, xcos, 
         xxcos;

        ia[0] = ia1;
        ia[1] = ia2;
        ia[2] = ia3;

        for( j = 0; j < 3; j++ )
        {
                p[0][j] = atom[ia[j]].x;
                p[1][j] = atom[ia[j]].y;
                p[2][j] = atom[ia[j]].z;
        }

        for( i = 0; i < 3; i++ )
        {
                a[i] = p[i][0] - p[i][1];
                b[i] = p[i][2] - p[i][1];
        }

        aa123 = a[0]*a[0] + a[1]*a[1] + a[2]*a[2];
        xa = sqrt( aa123 );
        bb123 = b[0]*b[0] + b[1]*b[1] + b[2]*b[2];
        xb = sqrt( bb123 );

        xxcos = a[0]*b[0] + a[1]*b[1] + a[2]*b[2];
        fxcos = xxcos/xa;
        xcos = fxcos/xb;
        if( xcos > 1.0 )
                xcos = 1.0;
        if( xcos < -1.0 )
                xcos = -1.0;
        *xangl = acos( xcos );
        *xangl *= 57.29578;

        return;
} 

