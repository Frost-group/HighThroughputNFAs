#define EXTERN extern
#include "pcwin.h"
#include "pcmod.h"
#include "substr.h"
#include "field.h"
#include "atom_k.h"
#include "pot.h"
#include "energies.h"
#include "solv.h"
#include "fix.h"

EXTERN int ncol[];

struct t_residues {
        int  nchain, ichainstart[10];
        int  ngroup, iresnum[200], irestype[200], istartatom[200];
        }       residues;

EXTERN struct t_minim_values {
        int iprint, ndc, nconst;
        float dielc;
        } minim_values;
EXTERN struct t_units {
        double bndunit, cbnd, qbnd;
        double angunit, cang, qang, pang, sang, aaunit;
        double stbnunit, ureyunit, torsunit, storunit, v14scale;
        double aterm, bterm, cterm, dielec, chgscale;
        } units;
EXTERN struct t_minim_control {
        int type, method, field, added_const;
        char added_path[256],added_name[256];
        } minim_control;
EXTERN struct t_dmomv {
        float xn,yn,zn,xp,yp,zp;
        } dmomv;
EXTERN struct t_dipolemom {
        double total, xdipole, ydipole, zdipole;
       }  dipolemom;
EXTERN struct t_vdw1 {
        int  nvdw;
        float rad[MAXVDWCONST], eps[MAXVDWCONST];
        int lpd[MAXVDWCONST], ihtyp[MAXVDWCONST], ihdon[MAXVDWCONST];
        float alpha[MAXVDWCONST],n[MAXVDWCONST],a[MAXVDWCONST],g[MAXVDWCONST];
        char da[MAXVDWCONST][2];
        } vdw1;

EXTERN struct {
        int mm3, mmff, amber, opls;
        } AtomTypes[];

EXTERN struct ElementType { char symbol[3];
                             int atomnum;
                             float weight, covradius, vdwradius;
                              int s,p,d,f, type;
                            } Elements[];

EXTERN struct t_centroid {
            int ncentroid, numsel[10];
            int isel[10][10];
            double x[10], y[10], z[10];
        } centroid;

void InitialTransform(void);
int  make_atom(int , float , float , float,char * );
void make_bond(int , int , int );
void generate_bonds(void);
void deleteatom(int);
void deletebond(int, int);
void set_atomtype(int,int,int,int,int,int);
void set_atomdata(int,int,int,int,int,int);
extern void matrotat(float (*)[4], int, float);
extern void matxform(float (*)[4], int);
void message_alert(char *, char *);
void charge_dipole(void);
int isangle(int,int);
int mm3_mmxtype(int);
int mmff_mmxtype(int);

// ===============================================
void set_atomdata(int ia, int mmxtype, int mm3type, int mmfftype,int ambertype,int oplstype)
{
    int type;
    
        if (mmxtype > 0)
           atom[ia].mmx_type = mmxtype;
        if (mm3type > 0)
           atom[ia].mm3_type = mm3type;
        if (mmfftype > 0)
           atom[ia].mmff_type = mmfftype;
        if (ambertype > 0)
           atom[ia].amber_type = ambertype;
        if (oplstype > 0)
           atom[ia].opls_type = oplstype;
           
        if (field.type == MMX || field.type == MM2)
        {
           type = mmxtype;
        } else if (field.type == MM3)
        {
           type = mm3type;
        }else if (field.type == AMBER)
        {
           type = ambertype;
        } else if (field.type == MMFF94)
        {
            type = mmfftype;
        } else if (field.type == OPLSAA)
        {
            type = oplstype;
        }

        if ( type < 300) 
        {
           atom[ia].tclass = atom_k.tclass[type];
           atom[ia].atomnum = atom_k.number[type];
           atom[ia].atomwt = atom_k.weight[type];
          strcpy(atom[ia].name, atom_k.symbol[type]);
        }

        if ( field.type == MMX && mmxtype == LPTYPE)
          atom[ia].color = 1;
        else if ( type < 300 && mmxtype != LPTYPE )
          atom[ia].color = ncol[atom[ia].atomnum-1];
        else
          atom[ia].color = 7;
        
}
// ===============================================
void set_atomtype(int ia, int mmxtype, int mm3type, int mmfftype,int ambertype,int oplstype)
{
        if (mmxtype > 0)
           atom[ia].mmx_type = mmxtype;
        if (mm3type > 0)
           atom[ia].mm3_type = mm3type;
        if (mmfftype > 0)
           atom[ia].mmff_type = mmfftype;
        if (ambertype > 0)
           atom[ia].amber_type = ambertype;
        if (oplstype > 0)
           atom[ia].opls_type = oplstype;
           
}
// ======================================================
int make_atom(int type, float x, float y, float z,char *name)
{
     int i,iz;
     int mmxtype, mm3type, mmfftype,ambertype,oplstype;

     natom++;
     if (natom >= MAXATOM - 10)
     {
         natom--;
         message_alert("Max atoms exceeded in makeatom","PCMODEL Error");
         return -1;
     }
        iz = strlen(name);
        if (iz > 0) // got an atom name use it 
        {
            for (i=1; i <= atom_k.natomtype; i++)
            {
                if (strcmp(name,atom_k.symbol[i]) == 0) // names match
                {
                    strcpy(atom[natom].name,name);
                    atom[natom].tclass = atom_k.tclass[i];
                    atom[natom].atomwt = atom_k.weight[i];
                    atom[natom].atomnum = atom_k.number[i];
                    atom[natom].type = atom_k.type[i];
                    if (type == 0)
                    {
                        type = atom[natom].type;  // this is an mmff type
                        mmxtype = mmff_mmxtype(type);
                        mm3type = 0;
                        mmfftype = type;
                        ambertype = 0;
                        oplstype = 0;
                        set_atomtype(natom,mmxtype,mm3type,mmfftype,ambertype,oplstype);
                        if (mmfftype == 0) return -1;
                    } else if (field.type == MMX || field.type == MM2)
                    {
                          atom[natom].mmx_type = type;
                          mmxtype = type;
                          mm3type = AtomTypes[type-1].mm3;
                          mmfftype = AtomTypes[type-1].mmff;
                          ambertype = AtomTypes[type-1].amber;
                          oplstype = AtomTypes[type-1].opls;
                          set_atomtype(natom,mmxtype,mm3type,mmfftype,ambertype,oplstype);
                    } else if (field.type == MM3)
                    {
                          atom[natom].mm3_type = type;
                          mmxtype = mm3_mmxtype(type);
                          mm3type = type;
                          mmfftype = AtomTypes[mmxtype-1].mmff;
                          ambertype = AtomTypes[mmxtype-1].amber;
                          oplstype = AtomTypes[mmxtype-1].opls;
                          set_atomtype(natom,mmxtype,mm3type,mmfftype,ambertype,oplstype);
                    } else if (field.type == MMFF94)
                    {
                          atom[natom].mmff_type = type;
                          mmxtype = mmff_mmxtype(type);
                          mm3type = AtomTypes[mmxtype-1].mm3;
                          mmfftype = type;
                          ambertype = AtomTypes[mmxtype-1].amber;
                          oplstype = AtomTypes[mmxtype-1].opls;
                          set_atomtype(natom,mmxtype,mm3type,mmfftype,ambertype,oplstype);
                    }

                    atom[natom].color = ncol[atom[natom].atomnum-1];
                    atom[natom].x = x; atom[natom].y = y; atom[natom].z = z;
                    atom[natom].vdw_radius = Elements[atom[natom].atomnum-1].covradius;
                    atom[natom].substr[0] = (1L << 0);
                    atom[natom].flags = 0;
                    substr.istract[0] = TRUE;
                    return natom;
                } 
            }
           for( i = 0; i < 103; i++ )
           {
              if( strcasecmp(Elements[i].symbol,name) == 0 )
              {
                  strcpy(atom[natom].name,Elements[i].symbol);
                  atom[natom].atomwt = Elements[i].weight;
                  atom[natom].atomnum = Elements[i].atomnum;
                  atom[natom].type = Elements[i].type;    // set generic type
                  atom[natom].tclass = Elements[i].type;    // set generic type
                  atom[natom].mmx_type = Elements[i].type;    // set generic type
                  if (type > 0) 
                  {
                       atom[natom].type = type; // overwrite type if type is passed in
                       if (field.type == MMX || field.type == MM2)
                          atom[natom].mmx_type = type;
                       else if (field.type == MM3)
                          atom[natom].mm3_type = type;
                       else if (field.type == MMFF94)
                          atom[natom].mmff_type = type;
                       else if (field.type == AMBER)
                          atom[natom].amber_type = type;
                       else if (field.type == OPLSAA)
                          atom[natom].opls_type = type;
                  }
                  if (type != 0) atom[natom].type = type;
                  atom[natom].color = ncol[atom[natom].atomnum-1];
                  atom[natom].x = x; atom[natom].y = y; atom[natom].z = z;
                  atom[natom].vdw_radius = Elements[i].covradius;
                  atom[natom].substr[0] = (1L << 0);
                  substr.istract[0] = TRUE;
                  if (type > 299)
                    return -1;
                  else if (atom[natom].mmff_type == 0)
                    return -1;
                  else
                   return natom;
              }
            }
        } else
        {
           message_alert("Input atom does not have valid atomic symbol or atom type","Error");
           return -1;
        }
        return -1;
}
// ====================================================
void make_bond(int ia1, int ia2, int bo)
{
    int loop,loop1;

   if (ia1 < 1 || ia1 > MAXATOM) return;
   if (ia2 < 1 || ia2 > MAXATOM) return;
   /*   find if bond exists        */
   for (loop = 0; loop < MAXIAT; loop++)
   {
     if (atom[ia1].iat[loop] == ia2)
     {
        if (bo == 1)
           atom[ia1].bo[loop] += bo;
        else
           atom[ia1].bo[loop] = bo;
        
        for (loop1 = 0; loop1 < MAXIAT; loop1++)
        {
         if (atom[ia2].iat[loop1] == ia1)
         {
             if ( bo == 1)
             {
                atom[ia2].bo[loop1] += bo; /* bond exists return */
                return;
             } else
             {
                atom[ia2].bo[loop1] = bo; /* bond exists return */
                return;
             }
         }
        }
      }
   }
/*  bond does not exist create it               */     
   for (loop = 0; loop < MAXIAT; loop++) 
   {
      if (atom[ia1].iat[loop] == 0) 
      {
          atom[ia1].iat[loop] = ia2;
          atom[ia1].bo[loop] = bo;
          break;
      }
   }
   for (loop = 0; loop < MAXIAT; loop++) 
   {
      if (atom[ia2].iat[loop] == 0) 
      {
          atom[ia2].iat[loop] = ia1;
          atom[ia2].bo[loop] = bo;
          break;
      }
   }
}
// ===============================================
void deleteatom(int i)
{
   int j,k, ibo;
   atom[i].type = 0;
   atom[i].x = 0.0F;
   atom[i].y = 0.0F;
   atom[i].z = 0.0F;
   atom[i].flags = 0;
   for (j=0; j < MAXSSCLASS; j++)
      atom[i].substr[j] = 0;
   for (j=0; j<MAXIAT; j++)
   {
      if (atom[i].iat[j] != 0 )
      {
         if (atom[atom[i].iat[j]].atomnum == 1 || atom[atom[i].iat[j]].atomnum == 0 )
         {
             atom[atom[i].iat[j]].type = 0;
             atom[atom[i].iat[j]].x = 0.0F;
             atom[atom[i].iat[j]].y = 0.0F;
             atom[atom[i].iat[j]].z = 0.0F;
             atom[atom[i].iat[j]].flags = 0;
         }
         ibo = atom[i].bo[j];
         for (k=1; k <= ibo; k++)
            deletebond(i,atom[i].iat[j]);
         atom[i].iat[j] = 0;
     }
   }
   natom--;
}
// ==================================================
void deletebond(int i, int j) 
{
   int i1,j1;
   for (i1=0; i1 < MAXIAT; i1++) 
   {
      if (atom[i].iat[i1] == j) 
      {
        if (atom[i].bo[i1] == 9)  /* if deleting a coordinated bond - delete it completely */
        {
            atom[i].bo[i1] = 0;
            atom[i].iat[i1] = 0;
        }
        atom[i].bo[i1] -= 1;
        if (atom[i].bo[i1] <= 0 )
            atom[i].iat[i1] = 0;
        break;
      }
   }
   for (j1=0; j1 < MAXIAT; j1++) 
   {
      if (atom[j].iat[j1] == i) 
      {
        if (atom[j].bo[j1] == 9)  /* if deleting a coordinated bond - delete it completely */
        {
            atom[j].bo[j1] = 0;
            atom[j].iat[j1] = 0;
        }
        atom[j].bo[j1] -= 1;
        if (atom[j].bo[j1] <= 0)
            atom[j].iat[j1] = 0;
        break;
      }
   }
}
/* --------------------------- */
void generate_bonds(void)
{
   int i,j;

   bonds.numbonds = 0;
   for (i= 0; i <= natom; i++)
   {
           bonds.ia1[i] = 0;
           bonds.ia2[i] = 0;
           bonds.bondorder[i] = 0;
   }

   for (i = 1; i <= natom; i++)
   {
      for (j = 0; j < MAXIAT; j++) 
      {
         if (atom[i].iat[j] > i && atom[i].iat[j] != 0) 
         {
            bonds.ia1[bonds.numbonds] = i;
            bonds.ia2[bonds.numbonds] = atom[i].iat[j];
            bonds.bondorder[bonds.numbonds] = atom[i].bo[j];
            bonds.numbonds++;
         }
     }
   }
}
