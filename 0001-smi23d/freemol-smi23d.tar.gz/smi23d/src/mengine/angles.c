
#define EXTERN extern

#include "pcwin.h"
#include "pcmod.h"

#include "angles.h"
#include "field.h"
#include "pot.h"

// number of atoms with 5 or greater real bonds
struct t_high_coord {
        int ncoord, i13[400][3];
        } high_coord;

void message_alert(char *, char *);
void get_angles(void);
int isangle(int, int);

void get_angles()
{
    int i,j,k,icount;
    int ia, ib, ic, id, ie;
    int jj, icoord;
    int itemp[5];

    angles.nang = 0;
    high_coord.ncoord = 0;
    for (i=0; i < MAXANG; i++)
    {
        angles.i13[i][0] = 0;
        angles.i13[i][1] = 0;
        angles.i13[i][2] = 0;
        angles.i13[i][3] = 0;
    }     
//
    for (i = 1; i <= natom; i++)
    {
        jj = 0;
        icoord = 0;
        for (j=0; j < MAXIAT; j++)
        {
            if (atom[i].iat[j] != 0 && atom[i].bo[j] != 9)
              jj++;
            if (atom[i].bo[j] == 9)
              icoord++;
        }

        if (jj == 2 && atom[i].type < 300)
        {
            icount = 0;
            for (j=0; j < MAXIAT; j++)
            {
                if (atom[i].iat[j] != 0 && atom[i].bo[j] != 9)
                {
                    icount++;
                    if (icount == 1)
                       ia = atom[i].iat[j];
                    else if (icount == 2)
                    {
                        ib = atom[i].iat[j];
                        break;
                    }
                }
            }
            angles.i13[angles.nang][0] = ia;
            angles.i13[angles.nang][1] = i;
            angles.i13[angles.nang][2] = ib;
            angles.i13[angles.nang][3] = 0;
            angles.nang++;            
        } else if (jj == 3 && atom[i].type < 300)
        {
            if (icoord == 0)
            {
             ia = atom[i].iat[0];
             ib = atom[i].iat[1];
             ic = atom[i].iat[2];
            } else
            {
              icoord = 0;
              for(j=0; j < MAXIAT; j++)
              {
                 if (atom[i].iat[j] !=0 && atom[i].bo[j] != 9)
                 {
                     itemp[icoord] = atom[i].iat[j];
                     icoord++;
                 }
              }
              ia = itemp[0];
              ib = itemp[1];
              ic = itemp[2];
            }
            angles.i13[angles.nang][0] = ia;
            angles.i13[angles.nang][1] = i;
            angles.i13[angles.nang][2] = ib;
            angles.i13[angles.nang][3] = ic;
            angles.nang++;            
            angles.i13[angles.nang][0] = ia;
            angles.i13[angles.nang][1] = i;
            angles.i13[angles.nang][2] = ic;
            angles.i13[angles.nang][3] = ib;
            angles.nang++;            
            angles.i13[angles.nang][0] = ib;
            angles.i13[angles.nang][1] = i;
            angles.i13[angles.nang][2] = ic;
            angles.i13[angles.nang][3] = ia;
            angles.nang++;            
        } else if (jj == 4 && atom[i].type < 300) 
        {
            if (icoord == 0)
            {
              ia = atom[i].iat[0];
              ib = atom[i].iat[1];
              ic = atom[i].iat[2];
              id = atom[i].iat[3];
            } else
            {
                icoord = 0;
                for (j=0; j < MAXIAT; j++)
                {
                    if (atom[i].iat[j] != 0 && atom[i].bo[j] != 9)
                    {
                        itemp[icoord] = atom[i].iat[j];
                        icoord++;
                    }
                }
                ia = itemp[0];
                ib = itemp[1];
                ic = itemp[2];
                id = itemp[3];
            }
            angles.i13[angles.nang][0] = ia;
            angles.i13[angles.nang][1] = i;
            angles.i13[angles.nang][2] = ib;
            angles.i13[angles.nang][3] = 0;
            angles.nang++;            
            angles.i13[angles.nang][0] = ia;
            angles.i13[angles.nang][1] = i;
            angles.i13[angles.nang][2] = ic;
            angles.i13[angles.nang][3] = 0;
            angles.nang++;            
            angles.i13[angles.nang][0] = ia;
            angles.i13[angles.nang][1] = i;
            angles.i13[angles.nang][2] = id;
            angles.i13[angles.nang][3] = 0;
            angles.nang++;            
            angles.i13[angles.nang][0] = ib;
            angles.i13[angles.nang][1] = i;
            angles.i13[angles.nang][2] = ic;
            angles.i13[angles.nang][3] = 0;
            angles.nang++;            
            angles.i13[angles.nang][0] = ib;
            angles.i13[angles.nang][1] = i;
            angles.i13[angles.nang][2] = id;
            angles.i13[angles.nang][3] = 0;
            angles.nang++;            
            angles.i13[angles.nang][0] = ic;
            angles.i13[angles.nang][1] = i;
            angles.i13[angles.nang][2] = id;
            angles.i13[angles.nang][3] = 0;
            angles.nang++;                        
        } else if (jj == 5 && atom[i].type < 300)
        {
            if (icoord == 0)
            {
              ia = atom[i].iat[0];
              ib = atom[i].iat[1];
              ic = atom[i].iat[2];
              id = atom[i].iat[3];
              ie = atom[i].iat[4];
            } else
            {
                icoord = 0;
                for (j=0; j < MAXIAT; j++)
                {
                    if (atom[i].iat[j] != 0 && atom[i].bo[j] != 9)
                    {
                        itemp[icoord] = atom[i].iat[j];
                        icoord++;
                    }
                }
                ia = itemp[0];
                ib = itemp[1];
                ic = itemp[2];
                id = itemp[3];
                ie = itemp[4];
            }
            angles.i13[angles.nang][0] = ia;
            angles.i13[angles.nang][1] = i;
            angles.i13[angles.nang][2] = ib;
            angles.i13[angles.nang][3] = 0;
            angles.nang++;            
            angles.i13[angles.nang][0] = ia;
            angles.i13[angles.nang][1] = i;
            angles.i13[angles.nang][2] = ic;
            angles.i13[angles.nang][3] = 0;
            angles.nang++;            
            angles.i13[angles.nang][0] = ia;
            angles.i13[angles.nang][1] = i;
            angles.i13[angles.nang][2] = id;
            angles.i13[angles.nang][3] = 0;
            angles.nang++;            
            angles.i13[angles.nang][0] = ia;
            angles.i13[angles.nang][1] = i;
            angles.i13[angles.nang][2] = ie;
            angles.i13[angles.nang][3] = 0;
            angles.nang++;            
            angles.i13[angles.nang][0] = ib;
            angles.i13[angles.nang][1] = i;
            angles.i13[angles.nang][2] = ic;
            angles.i13[angles.nang][3] = 0;
            angles.nang++;            
            angles.i13[angles.nang][0] = ib;
            angles.i13[angles.nang][1] = i;
            angles.i13[angles.nang][2] = id;
            angles.i13[angles.nang][3] = 0;
            angles.nang++;            
            angles.i13[angles.nang][0] = ib;
            angles.i13[angles.nang][1] = i;
            angles.i13[angles.nang][2] = ie;
            angles.i13[angles.nang][3] = 0;
            angles.nang++;            
            angles.i13[angles.nang][0] = ic;
            angles.i13[angles.nang][1] = i;
            angles.i13[angles.nang][2] = id;
            angles.i13[angles.nang][3] = 0;
            angles.nang++;                        
            angles.i13[angles.nang][0] = ic;
            angles.i13[angles.nang][1] = i;
            angles.i13[angles.nang][2] = ie;
            angles.i13[angles.nang][3] = 0;
            angles.nang++;                        
            angles.i13[angles.nang][0] = id;
            angles.i13[angles.nang][1] = i;
            angles.i13[angles.nang][2] = ie;
            angles.i13[angles.nang][3] = 0;
            angles.nang++;                        
        } else if (jj == 5)
        {
             if (icoord == 0)
            {
              ia = atom[i].iat[0];
              ib = atom[i].iat[1];
              ic = atom[i].iat[2];
              id = atom[i].iat[3];
              ie = atom[i].iat[4];
              // ia angles
              high_coord.i13[high_coord.ncoord][0] = ia;
              high_coord.i13[high_coord.ncoord][1] = i;
              high_coord.i13[high_coord.ncoord][2] = ib;
              high_coord.ncoord++;
              high_coord.i13[high_coord.ncoord][0] = ia;
              high_coord.i13[high_coord.ncoord][1] = i;
              high_coord.i13[high_coord.ncoord][2] = ic;
              high_coord.ncoord++;
              high_coord.i13[high_coord.ncoord][0] = ia;
              high_coord.i13[high_coord.ncoord][1] = i;
              high_coord.i13[high_coord.ncoord][2] = id;
              high_coord.ncoord++;
              high_coord.i13[high_coord.ncoord][0] = ia;
              high_coord.i13[high_coord.ncoord][1] = i;
              high_coord.i13[high_coord.ncoord][2] = ie;
              high_coord.ncoord++;
              // ib angles
              high_coord.i13[high_coord.ncoord][0] = ib;
              high_coord.i13[high_coord.ncoord][1] = i;
              high_coord.i13[high_coord.ncoord][2] = ic;
              high_coord.ncoord++;
              high_coord.i13[high_coord.ncoord][0] = ib;
              high_coord.i13[high_coord.ncoord][1] = i;
              high_coord.i13[high_coord.ncoord][2] = id;
              high_coord.ncoord++;
              high_coord.i13[high_coord.ncoord][0] = ib;
              high_coord.i13[high_coord.ncoord][1] = i;
              high_coord.i13[high_coord.ncoord][2] = ie;
              high_coord.ncoord++;
              // ic angles
              high_coord.i13[high_coord.ncoord][0] = ic;
              high_coord.i13[high_coord.ncoord][1] = i;
              high_coord.i13[high_coord.ncoord][2] = id;
              high_coord.ncoord++;
              high_coord.i13[high_coord.ncoord][0] = ic;
              high_coord.i13[high_coord.ncoord][1] = i;
              high_coord.i13[high_coord.ncoord][2] = ie;
              high_coord.ncoord++;
              // id angles
              high_coord.i13[high_coord.ncoord][0] = id;
              high_coord.i13[high_coord.ncoord][1] = i;
              high_coord.i13[high_coord.ncoord][2] = ie;
              high_coord.ncoord++;
            } else
            {
                icoord = 0;
                for (j=0; j < MAXIAT; j++)
                {
                    if (atom[i].iat[j] != 0 && atom[i].bo[j] != 9)
                    {
                        itemp[icoord] = atom[i].iat[j];
                        icoord++;
                    }
                }
                ia = itemp[0];
                ib = itemp[1];
                ic = itemp[2];
                id = itemp[3];
                ie = itemp[4];
              // ia angles
              high_coord.i13[high_coord.ncoord][0] = ia;
              high_coord.i13[high_coord.ncoord][1] = i;
              high_coord.i13[high_coord.ncoord][2] = ib;
              high_coord.ncoord++;
              high_coord.i13[high_coord.ncoord][0] = ia;
              high_coord.i13[high_coord.ncoord][1] = i;
              high_coord.i13[high_coord.ncoord][2] = ic;
              high_coord.ncoord++;
              high_coord.i13[high_coord.ncoord][0] = ia;
              high_coord.i13[high_coord.ncoord][1] = i;
              high_coord.i13[high_coord.ncoord][2] = id;
              high_coord.ncoord++;
              high_coord.i13[high_coord.ncoord][0] = ia;
              high_coord.i13[high_coord.ncoord][1] = i;
              high_coord.i13[high_coord.ncoord][2] = ie;
              high_coord.ncoord++;
              // ib angles
              high_coord.i13[high_coord.ncoord][0] = ib;
              high_coord.i13[high_coord.ncoord][1] = i;
              high_coord.i13[high_coord.ncoord][2] = ic;
              high_coord.ncoord++;
              high_coord.i13[high_coord.ncoord][0] = ib;
              high_coord.i13[high_coord.ncoord][1] = i;
              high_coord.i13[high_coord.ncoord][2] = id;
              high_coord.ncoord++;
              high_coord.i13[high_coord.ncoord][0] = ib;
              high_coord.i13[high_coord.ncoord][1] = i;
              high_coord.i13[high_coord.ncoord][2] = ie;
              high_coord.ncoord++;
              // ic angles
              high_coord.i13[high_coord.ncoord][0] = ic;
              high_coord.i13[high_coord.ncoord][1] = i;
              high_coord.i13[high_coord.ncoord][2] = id;
              high_coord.ncoord++;
              high_coord.i13[high_coord.ncoord][0] = ic;
              high_coord.i13[high_coord.ncoord][1] = i;
              high_coord.i13[high_coord.ncoord][2] = ie;
              high_coord.ncoord++;
              // id angles
              high_coord.i13[high_coord.ncoord][0] = id;
              high_coord.i13[high_coord.ncoord][1] = i;
              high_coord.i13[high_coord.ncoord][2] = ie;
              high_coord.ncoord++;
            }
        } else if (jj > 5)
        {
            for (j=0; j < MAXIAT; j++)
            {
                if (atom[i].iat[j] != 0 && atom[i].bo[j] != 9)
                {
                    ia = atom[i].iat[j];
                    for (k=j+1; k < MAXIAT; k++)
                    {
                        if (atom[i].iat[k] != 0 && atom[i].bo[k] != 9)
                        {
                            high_coord.i13[high_coord.ncoord][0] = ia;
                            high_coord.i13[high_coord.ncoord][1] = i;
                            high_coord.i13[high_coord.ncoord][2] = atom[i].iat[k];
                            high_coord.ncoord++;
                        }
                    }
                }
            }
        }

        if (angles.nang > MAXANG)
        {
            message_alert("Too many angles. PCMODEL will now exit","Angle Setup");
            fprintf(pcmoutfile,"Too many angles. PCMODEL will now exit\n");
            exit(0);
        }
    }
    if (high_coord.ncoord > 0)
       pot.use_highcoord = TRUE;
       
    for (i=0; i < angles.nang; i++)
       angles.angin[i] = FALSE;
}

int isangle(int i, int j)
{
    int k,l,katm;
    for (k=0; k < MAXIAT; k++)
    {
        if (atom[i].iat[k] != 0 && atom[i].bo[k] != 9)
        {
            katm = atom[i].iat[k];
            for (l=0; l < MAXIAT; l++)
            {
                if (atom[katm].iat[l] == j)
                  return TRUE;
            }
        }
    }
    return FALSE;
}

