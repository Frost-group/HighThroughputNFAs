#define EXTERN extern

#include "pcwin.h"
#include "pcmod.h"
#include "bonds_ff.h"
#include "rings.h"
#include "pot.h"
#include "field.h"

void numeral(int, char *, int);

       
EXTERN struct  t_bondk1 {
        int use_ring3, use_ring4, use_ring5, ndeloc;
        int nbnd, nbnd3, nbnd4, nbnd5;
        char kb[MAXBONDCONST][7], kb3[MAXBOND3CONST][7],kb4[MAXBOND4CONST][7],kb5[MAXBOND5CONST][7];
        char kbdel[MAXBONDDELOC][7];
        float s[MAXBONDCONST], t[MAXBONDCONST];
        float s3[MAXBOND3CONST], t3[MAXBOND3CONST];
        float s4[MAXBOND4CONST], t4[MAXBOND4CONST];
        float s5[MAXBOND5CONST], t5[MAXBOND5CONST];
        float sdel[MAXBONDDELOC], tdel[MAXBONDDELOC];
        }  bondk1;
                
        
EXTERN struct t_bondpk {
        int     npibond,npibond44i,npibond45i,npibond46i,npibond55i,npibond56i,npibond66i;
        int     npibond44o,npibond45o,npibond46o,npibond55o,npibond56o,npibond66o;
        int     npibond40,npibond50,npibond60;
        int     use_pibond,use_pibond44i,use_pibond45i,use_pibond46i,use_pibond55i,use_pibond56i,use_pibond66i;
        int     use_pibond44o,use_pibond45o,use_pibond46o,use_pibond55o,use_pibond56o,use_pibond66o;
        int     use_pibond40,use_pibond50,use_pibond60;
        char    kb[MAXPIBONDCONST][7],kb44i[20][7],kb45i[20][7],kb46i[20][7],kb55i[20][7],kb56i[20][7],kb66i[20][7];
        char    kb44o[20][7],kb45o[20][7],kb46o[20][7],kb55o[20][7],kb56o[20][7],kb66o[20][7];
        char    kb40[20][7],kb50[20][7],kb60[20][7];
        float   bk[MAXPIBONDCONST], bl[MAXPIBONDCONST], bmom[MAXPIBONDCONST],sslop[MAXPIBONDCONST], tslop[MAXPIBONDCONST], tslop2[MAXPIBONDCONST];
        float   bk44i[20], bl44i[20], bmom44i[20],sslop44i[20], tslop44i[20], tslop244i[20];
        float   bk45i[20], bl45i[20], bmom45i[20],sslop45i[20], tslop45i[20], tslop245i[20];
        float   bk46i[20], bl46i[20], bmom46i[20],sslop46i[20], tslop46i[20], tslop246i[20];
        float   bk55i[20], bl55i[20], bmom55i[20],sslop55i[20], tslop55i[20], tslop255i[20];
        float   bk56i[20], bl56i[20], bmom56i[20],sslop56i[20], tslop56i[20], tslop256i[20];
        float   bk66i[20], bl66i[20], bmom66i[20],sslop66i[20], tslop66i[20], tslop266i[20];
        float   bk44o[20], bl44o[20], bmom44o[20],sslop44o[20], tslop44o[20], tslop244o[20];
        float   bk45o[20], bl45o[20], bmom45o[20],sslop45o[20], tslop45o[20], tslop245o[20];
        float   bk46o[20], bl46o[20], bmom46o[20],sslop46o[20], tslop46o[20], tslop246o[20];
        float   bk55o[20], bl55o[20], bmom55o[20],sslop55o[20], tslop55o[20], tslop255o[20];
        float   bk56o[20], bl56o[20], bmom56o[20],sslop56o[20], tslop56o[20], tslop256o[20];
        float   bk66o[20], bl66o[20], bmom66o[20],sslop66o[20], tslop66o[20], tslop266o[20];
        float   bk40[20], bl40[20], bmom40[20],sslop40[20], tslop40[20], tslop240[20];
        float   bk50[20], bl50[20], bmom50[20],sslop50[20], tslop50[20], tslop250[20];
        float   bk60[20], bl60[20], bmom60[20],sslop60[20], tslop60[20], tslop260[20];
        } bondpk;
        
EXTERN struct  t_dipole_k {
        int ndipole,ndipole3,ndipole4,ndipole5;
        char   kb[MAXBONDCONST][7], kb3[MAXBOND3CONST][7], kb4[MAXBOND4CONST][7], kb5[MAXBOND5CONST][7];
        float bmom[MAXBONDCONST],bmom3[MAXBOND3CONST],bmom4[MAXBOND4CONST],bmom5[MAXBOND5CONST];
         } dipole_k;
         
EXTERN int Missing_constants;
EXTERN FILE *errfile;

void kdipole()
{
    int i, j, ia, ib, ita, itb, it;
    int ierr, use_dipole;
    long int mask;
    char pa[4],pb[4],pt[7];

    mask = 1L << 0;
    use_dipole = FALSE;
    
    for (i=0; i < bonds_ff.nbnd; i++)
    {
        bonds_ff.bmom[i] = 0.0;
        ia = bonds_ff.i12[i][0];
        ib = bonds_ff.i12[i][1];
        bonds_ff.idpl[i][0] = -1;
        bonds_ff.idpl[i][1] = -1;
        ita = atom[ia].type;
        itb = atom[ib].type;
        numeral(ita,pa,3);
        numeral(itb,pb,3);
        if(ita < itb )
        {
            it = ita*100+itb;
            strcpy(pt,pa);
            strcat(pt,pb);
        } else
        {
            it = itb*100+ita;
            strcpy(pt,pb);
            strcat(pt,pa);
        }

        ierr = FALSE;
//  Do we need to check for transition state atoms
        if (bondpk.use_pibond == TRUE)
        {
            if ( (atom[ia].flags & mask) && (atom[ib].flags & mask) )
            {
                for (j=0; j < bondpk.npibond; j++)
                {
                    if (strcmp(pt,bondpk.kb[j]) == 0)
                    {
                        if (ita <= itb )
                        {
                            bonds_ff.idpl[i][0] = ia;
                            bonds_ff.idpl[i][1] = ib;
                        } else
                        {
                            bonds_ff.idpl[i][0] = ib;
                            bonds_ff.idpl[i][1] = ia;
                        }
                        bonds_ff.bmom[i] = bondpk.bmom[j];
                        ierr = TRUE;
                        use_dipole = TRUE;
                        break;
                    }
                }
            }
        }
        if (ierr == TRUE)
          goto L_10;
//   check for metals
//   check 5 membered rings
        if (rings.nring5 > 0 && bondk1.use_ring5 == TRUE)
        {
         for (j=0; j < dipole_k.ndipole5; j++)
         {
          if (strcmp(dipole_k.kb5[j],pt) == 0)
          {
             if (ita <= itb )
             {
                 bonds_ff.idpl[i][0] = ia;
                 bonds_ff.idpl[i][1] = ib;
              } else
              {
                 bonds_ff.idpl[i][0] = ib;
                 bonds_ff.idpl[i][1] = ia;
              }
              bonds_ff.bmom[i] = dipole_k.bmom5[j];
              ierr = TRUE;
              use_dipole = TRUE;
              break;
          }
         }
       }
      if (ierr == TRUE)
          goto L_10;
//   check 4 membered rings
        if (rings.nring4 > 0 && bondk1.use_ring4 == TRUE)
        {
         for (j=0; j < dipole_k.ndipole4; j++)
         {
          if (strcmp(dipole_k.kb4[j],pt) == 0)
          {
             if (ita <= itb )
             {
                 bonds_ff.idpl[i][0] = ia;
                 bonds_ff.idpl[i][1] = ib;
              } else
              {
                 bonds_ff.idpl[i][0] = ib;
                 bonds_ff.idpl[i][1] = ia;
              }
              bonds_ff.bmom[i] = dipole_k.bmom4[j];
              ierr = TRUE;
              use_dipole = TRUE;
              break;
          }
         }
       }
      if (ierr == TRUE)
          goto L_10;
//   check 3 membered rings
        if (rings.nring3 > 0 && bondk1.use_ring3 == TRUE)
        {
         for (j=0; j < dipole_k.ndipole3; j++)
         {
          if (strcmp(dipole_k.kb3[j],pt) == 0)
          {
             if (ita <= itb )
             {
                 bonds_ff.idpl[i][0] = ia;
                 bonds_ff.idpl[i][1] = ib;
              } else
              {
                 bonds_ff.idpl[i][0] = ib;
                 bonds_ff.idpl[i][1] = ia;
              }
              bonds_ff.bmom[i] = dipole_k.bmom3[j];
              ierr = TRUE;
              use_dipole = TRUE;
              break;
          }
         }
       }
      if (ierr == TRUE)
          goto L_10;

 // regular constants
         for (j=0; j < dipole_k.ndipole; j++)
         {
          if (strcmp(dipole_k.kb[j],pt) ==0)
          {
             if (ita <= itb )
             {
                 bonds_ff.idpl[i][0] = ia;
                 bonds_ff.idpl[i][1] = ib;
              } else
              {
                 bonds_ff.idpl[i][0] = ib;
                 bonds_ff.idpl[i][1] = ia;
              }
              bonds_ff.bmom[i] = dipole_k.bmom[j];
              ierr = TRUE;
              use_dipole = TRUE;
              break;
          }
        }
L_10:
        continue;
    }
//    if (use_dipole == FALSE)
//      pot.use_dipole = FALSE;

}

