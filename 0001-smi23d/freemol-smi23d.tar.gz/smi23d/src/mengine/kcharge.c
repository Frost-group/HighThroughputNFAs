#define EXTERN extern

#include "pcwin.h"
#include "pcmod.h"
#include "bonds_ff.h"
#include "field.h"
#include "atom_k.h"
#include "utility.h"
#include "pdb.h"

#define MAXOPLS  600

void numeral(int, char *, int);
void compute_fcharge(void);
void assign_amber_chrg(int);
void assign_gast_charge();
void compute_opls(void);
int find_rsize(int,int);
void search_rings(int);
void message_alert(char *,char *);
void find_residues(void);
void bbchk(void);
void pireset(void);
int get_oplsconst(int,int,char *);
void ksortr(int, int *,int *,int *);
void get_rsize(int,int,int, int *);
void ksort_ring(int,int,int *);
void get_firstlevel(int,int *,int *,int *,int *);
void get_secondlevel(int,int,int *,int *,int *,int *);
void get_residue_type(int,int*);

EXTERN struct ElementType { 
                        char symbol[3];
                        int   atomnum;
                        float weight, covradius, vdwradius;
                        int s,p,d,f, type;
                   } Elements[] ;

EXTERN struct BioType {
        char  name_3[4], name_1[2];
        int   type, natom;
       }  BioGroups[];

typedef struct Gastype {
        int    type;
        float a,b,c,d;
        }  Gastype;
        
EXTERN Gastype Gastchrg[];   

EXTERN struct t_bondpk {
        int     npibond,npibond44i,npibond45i,npibond46i,npibond55i,npibond56i,npibond66i;
        int     npibond44o,npibond45o,npibond46o,npibond55o,npibond56o,npibond66o;
        int     npibond40,npibond50,npibond60;
        int     use_pibond,use_pibond44i,use_pibond45i,use_pibond46i,use_pibond55i,use_pibond56i,use_pibond66i;
        int     use_pibond44o,use_pibond45o,use_pibond46o,use_pibond55o,use_pibond56o,use_pibond66o;
        int     use_pibond40,use_pibond50,use_pibond60;
        char    kb[MAXPIBONDCONST][7],kb44i[20][7],kb45i[20][7],kb46i[20][7],kb55i[20][7],kb56i[20][7],kb66i[20][7];
        char    kb44o[20][7],kb45o[20][7],kb46o[20][7],kb55o[20][7],kb56o[20][7],kb66o[20][7];
        char    kb40[20][7],kb50[20][7],kb60[20][7];
        float   bk[MAXPIBONDCONST], bl[MAXPIBONDCONST], bmom[MAXPIBONDCONST],sslop[MAXPIBONDCONST], tslop[MAXPIBONDCONST], tslop2[MAXPIBONDCONST];
        float   bk44i[20], bl44i[20], bmom44i[20],sslop44i[20], tslop44i[20], tslop244i[20];
        float   bk45i[20], bl45i[20], bmom45i[20],sslop45i[20], tslop45i[20], tslop245i[20];
        float   bk46i[20], bl46i[20], bmom46i[20],sslop46i[20], tslop46i[20], tslop246i[20];
        float   bk55i[20], bl55i[20], bmom55i[20],sslop55i[20], tslop55i[20], tslop255i[20];
        float   bk56i[20], bl56i[20], bmom56i[20],sslop56i[20], tslop56i[20], tslop256i[20];
        float   bk66i[20], bl66i[20], bmom66i[20],sslop66i[20], tslop66i[20], tslop266i[20];
        float   bk44o[20], bl44o[20], bmom44o[20],sslop44o[20], tslop44o[20], tslop244o[20];
        float   bk45o[20], bl45o[20], bmom45o[20],sslop45o[20], tslop45o[20], tslop245o[20];
        float   bk46o[20], bl46o[20], bmom46o[20],sslop46o[20], tslop46o[20], tslop246o[20];
        float   bk55o[20], bl55o[20], bmom55o[20],sslop55o[20], tslop55o[20], tslop255o[20];
        float   bk56o[20], bl56o[20], bmom56o[20],sslop56o[20], tslop56o[20], tslop256o[20];
        float   bk66o[20], bl66o[20], bmom66o[20],sslop66o[20], tslop66o[20], tslop266o[20];
        float   bk40[20], bl40[20], bmom40[20],sslop40[20], tslop40[20], tslop240[20];
        float   bk50[20], bl50[20], bmom50[20],sslop50[20], tslop50[20], tslop250[20];
        float   bk60[20], bl60[20], bmom60[20],sslop60[20], tslop60[20], tslop260[20];
        } bondpk;
        
EXTERN struct t_charge_k {
         int ncharge, nbndchrg, nbndchrgdel;
         int type[MAXATOMTYPE], btype[MAXBONDCONST], btypedel[MAXBONDCONST];
         float charge[MAXATOMTYPE], bcharge[MAXBONDCONST], formchrg[MAXATOMTYPE], bchargedel[MAXBONDCONST];
         float typechrg[MAXATOMTYPE];
         } charge_k;
         
EXTERN struct t_amberchrg_k {
         int ncharge, type[MAXATOMTYPE], res_type[MAXATOMTYPE];
         char symbol[MAXATOMTYPE][4];
         float chrg[MAXATOMTYPE];
         } amberchrg_k;
         
EXTERN struct t_oplschrg_k {
         int ncharge, type[MAXOPLS];
         char chrgstring[MAXOPLS][25];
         float chrg[MAXOPLS];
         } oplschrg_k;

EXTERN struct  t_dipole_k {
        int ndipole,ndipole3,ndipole4,ndipole5;
        char   kb[MAXBONDCONST][7], kb3[MAXBOND3CONST][7], kb4[MAXBOND4CONST][7], kb5[MAXBOND5CONST][7];
        float bmom[MAXBONDCONST],bmom3[MAXBOND3CONST],bmom4[MAXBOND4CONST],bmom5[MAXBOND5CONST];
         } dipole_k;

EXTERN struct t_residues {
        int  nchain, ichainstart[10];
        int  ngroup, iresnum[200], irestype[200], istartatom[200];
        }       residues;
EXTERN struct t_ringdata {
        int nring3, nring4, nring5, nring6;
        int tot3, tot4, tot5, tot6;
        int **iring3,**iring4,**iring5,**iring6;
       }  ringdata;


void kcharge()
{
   int i, j, ia, ib, it, iit, kit, jji;
   long int mask;
   char pa[4],pb[4],pt[7];
   float bmomj;
   
   mask = 1L << 0;
   
   for (i=1; i <= natom; i++)
   {
      atom[i].sigma_charge = 0.0;
      if (field.type == MMX && (atom[i].type < 300))
        atom[i].charge = 0.0;
      else if (field.type != MMX && atom[i].type < 300)
        atom[i].charge = 0.0;
   }

   if (field.type == MMFF94)
   {
       compute_fcharge();
       for(i=0; i < bonds_ff.nbnd; i++)
       {
           ia = bonds_ff.i12[i][0];
           ib = bonds_ff.i12[i][1];
           iit = atom[ia].type;
           kit = atom[ib].type;
           if (iit < kit)
             it = iit*100+kit;
           else
             it = kit*100+iit;
           if (bonds_ff.index[i] == 1)
           {
              for(j=0; j < charge_k.nbndchrgdel; j++)
              {
                 if (it == charge_k.btypedel[j])
                 {
                   if (iit < kit)
                   {
                     atom[ia].charge -= charge_k.bchargedel[j];
                     atom[ib].charge += charge_k.bchargedel[j];
                   }else
                   {
                     atom[ib].charge -= charge_k.bchargedel[j];
                     atom[ia].charge += charge_k.bchargedel[j];
                   }
                   break;
                 }
              }
           } else
           {
              for(j=0; j < charge_k.nbndchrg; j++)
              {
                 if (it == charge_k.btype[j])
                 {
                   if (iit < kit)
                   {
                     atom[ia].charge -= charge_k.bcharge[j];
                     atom[ib].charge += charge_k.bcharge[j];
                   }else
                   {
                     atom[ib].charge -= charge_k.bcharge[j];
                     atom[ia].charge += charge_k.bcharge[j];
                   }
                   break;
                 }
             }
           }
       }
       // add in formal charges
       for (i=1; i <= natom; i++)
       {
           if (atom[i].atomnum == 15)
               atom[i].formal_charge = 0.0;
           if (atom[i].atomnum == 16 && atom[i].type != 72)
               atom[i].formal_charge = 0.0;             
       }              
       for (i=1; i <= natom; i++)
       {
           atom[i].charge += (1.0 - atom_k.ligands[atom[i].type]*charge_k.formchrg[atom[i].type])*atom[i].formal_charge ;
           for(j=0; j < MAXIAT; j++)
           {
               if (atom[i].iat[j] != 0)
               {
                  if (atom[atom[i].iat[j]].formal_charge < 0.0)
                           atom[i].charge += charge_k.formchrg[atom[atom[i].iat[j]].type]*atom[atom[i].iat[j]].formal_charge;
               }
           }
       }
   }
}
/* -------------------------------------------------------- */
void compute_fcharge()
{
    int i, j, jjbo;
    int jatm, k, jji, attached[4];
    int *used;
    float charge;
    
    used = ivector(1,natom+1);
    for (i=1; i <= natom; i++)
       used[i] = FALSE;
       
    for (i=1; i <= natom; i++)
    {
        atom[i].formal_charge = charge_k.typechrg[atom[i].type];
    }
//  find variable charges: types 32, 72, 76, 81
    for (i=1; i <= natom; i++)
    {
        if (used[i] == FALSE)
        {
            if (atom[i].formal_charge != 0.0)
            {
               if (atom[i].type == 32)
               {
                   jatm = atom[i].iat[0];
                   jji = 0;
                   jjbo = 0;
                   for (k=0; k < MAXIAT; k++)
                   {
                       if (atom[jatm].iat[k] != 0 && atom[jatm].bo[k] != 9)
                       {
                           if (atom[atom[jatm].iat[k]].type == 32)
                           {
                               if (atom[jatm].bo[k] == 1)
                               {
                                   jjbo++;
                                   attached[jji] = atom[jatm].iat[k];
                                   jji++;
                               } else
                               {
                                   attached[jji] = atom[jatm].iat[k];
                                   jji++;
                               }
                           }
                       }
                   }
                   charge = -(double)jjbo/jji;
                   if (jji == 1)  // only 1 type 32
                     atom[i].formal_charge = 0.0;
                   else if (jji == 2)
                   {
                       if (atom[jatm].atomnum == 15)  // p-o  treat as single negative charge;
                          charge = -1.00/jji;
                       if (atom[jatm].type == 73)
                       {
                           charge = -0.500;
                           atom[attached[0]].formal_charge = charge;
                           atom[attached[1]].formal_charge = charge;
                           used[attached[0]] = TRUE;                           
                           used[attached[1]] = TRUE;
                       } else if (atom[jatm].atomnum != 7)
                       {
                           atom[attached[0]].formal_charge = charge;
                           atom[attached[1]].formal_charge = charge;
                           used[attached[0]] = TRUE;                           
                           used[attached[1]] = TRUE;
                       }else
                       {
                           atom[attached[0]].formal_charge = 0.0;
                           atom[attached[1]].formal_charge = 0.0;
                           used[attached[0]] = TRUE;                           
                           used[attached[1]] = TRUE;
                       }                         
                   } else if (jji == 3)
                   {
                        atom[attached[0]].formal_charge = charge;
                        atom[attached[1]].formal_charge = charge;
                        atom[attached[2]].formal_charge = charge;
                        used[attached[0]] = TRUE;                           
                        used[attached[1]] = TRUE;                           
                        used[attached[2]] = TRUE;                           
                   } else if (jji == 4)
                   {
                        atom[attached[0]].formal_charge = charge;
                        atom[attached[1]].formal_charge = charge;
                        atom[attached[2]].formal_charge = charge;
                        atom[attached[3]].formal_charge = charge;
                        used[attached[0]] = TRUE;                           
                        used[attached[1]] = TRUE;                           
                        used[attached[2]] = TRUE;                           
                        used[attached[3]] = TRUE;                           
                   }
               }else if (atom[i].type == 72)
               {
                   jatm = atom[i].iat[0];
                   jji = 0;
                   jjbo = 0;
                   for (k=0; k < MAXIAT; k++)
                   {
                       if (atom[jatm].iat[k] != 0 && atom[jatm].bo[k] != 9)
                       {
                           if (atom[atom[jatm].iat[k]].type == 72)
                           {
                               if (atom[jatm].bo[k] == 1)
                               {
                                   jjbo++;
                                   attached[jji] = atom[jatm].iat[k];
                                   jji++;
                               } else
                               {
                                   attached[jji] = atom[jatm].iat[k];
                                   jji++;
                               }
                           }
                       }
                   }
                   if (jji == 1)
                   {
                       if (atom[jatm].atomnum == 15)
                          atom[i].formal_charge = 0.0;
                       else
                          atom[i].formal_charge = -1.00;
                   }else
                   {
                       atom[attached[0]].formal_charge = -0.5;
                       atom[attached[1]].formal_charge = -0.5;
                       used[attached[0]] = TRUE;
                       used[attached[1]] = TRUE;
                   }
               } else if (atom[i].type == 81)
               {
                   jji = 0;
                   for (k=0; k < MAXIAT ; k++)
                   {
                       if (atom[i].iat[k] != 0 && atom[atom[i].iat[k]].type == 80)
                       {
                           jatm = atom[i].iat[k];
                           jji = 0;
                           for (j=0; j < MAXIAT; j++)
                           {
                               if (atom[jatm].iat[j] != 0 && atom[jatm].bo[j] != 9)
                               {
                                   if (atom[atom[jatm].iat[j]].atomnum == 7)
                                   {
                                       attached[jji] = atom[jatm].iat[j];
                                       jji++;
                                   }
                               }
                           }
                       }
                   }
                   if (jji == 0)
                   {
                     charge = 1.00;
                     atom[i].formal_charge = charge;
                     used[i] = TRUE;
                   } else
                   {
                      charge = 1.00/jji;
                      for (j=0; j < jji; j++)
                      {
                          atom[attached[j]].formal_charge = charge;
                          used[attached[j]] = TRUE;
                      }
                   }
               }
            }
        }
    }
    free_ivector(used,1, natom+1);    
}
