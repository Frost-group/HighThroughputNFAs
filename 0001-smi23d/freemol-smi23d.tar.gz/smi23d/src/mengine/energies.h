EXTERN struct  t_energies {
        double total, estr, ebend, estrbnd, e14, evdw, etor, eu, eopb,
               eangang, estrtor, ehbond, efix, eimprop, eimptors, eurey, esolv; } energies;

EXTERN struct t_virial {
        double virx, viry, virz;
         } virial;
