EXTERN struct t_units {
        double bndunit, cbnd, qbnd;
        double angunit, cang, qang, pang, sang, aaunit;
        double stbnunit, ureyunit, torsunit, storunit, v14scale;
        double aterm, bterm, cterm, dielec, chgscale, chg13scale;
        } units;

