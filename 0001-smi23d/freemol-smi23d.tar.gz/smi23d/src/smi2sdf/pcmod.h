#ifndef True
#define True 1
#define False 0
#endif 

#include "pcmsiz.h"


#define radian 57.29577951308

#define         MMX             1
#define         MM2             2
#define         MM3             3
#define         MM4             4
#define         AMBER           5
#define         CHARMM          6
#define         MMFF94          7
#define         OPLS            8
#define         OPLSAA          9
#define         UNKNOWN         10

//  flags definitions
#define PI_MASK                 0
#define HBOND_MASK              1
#define AROMATIC_MASK           2
//  metal flags
#define METCOORD_MASK           3
#define SATMET_MASK             4
#define GT18e_MASK              5
#define LOWSPIN_MASK            6
#define SQPLAN_MASK             7

// type rules
#define NO_RETYPE               8
//  invisible
#define VIS_MASK                9
//  minimize 
#define MIN_MASK                10
// cpk surface
#define CPK_SURF                11
//  dotsurf
#define DOT_SURF                12
// Nterm, CNterm, Oterm, COterm, DUMMY
#define NTERM                   13
#define CNTERM                  14
#define OTERM                   15
#define COTERM                  16
#define DUMMY                   17
#define P5                      18
#define P3                      19
// Ring Size
#define RING3                   20
#define RING4                   21
#define RING5                   22
#define RING6                   23

void update(void);
void inesc(char *);

/*  PCMODEL specific definitions */
#ifndef ATOMTYPE
typedef struct {
                        double x,y,z;
                        int type;
                        int tclass;
                        int mmx_type;
                        int mm3_type;
                        int amber_type;
                        int mmff_type;
                        int charm_type;
                        int opls_type;
                        int atomnum;
                        int serno;
                        int molecule;
                        int residue;
                        int biotype;
                        double atomwt;
                        float energy;
                        int use;
                        int color;
                        int chrg_color;
                        int iat[MAXIAT];
                        int bo[MAXIAT];
                        char name[3];
                        double charge;
                        float formal_charge;
                        float sigma_charge;
                        float radius;
                        float vdw_radius;
                        long int flags;
                        long int substr[MAXSSCLASS];
                        } ATOMTYPE;
#endif

EXTERN ATOMTYPE         atom[MAXATOM];
EXTERN int              natom;
EXTERN char             Struct_Title[100];
EXTERN FILE             *logfile;

