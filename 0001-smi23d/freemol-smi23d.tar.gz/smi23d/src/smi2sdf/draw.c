#define EXTERN extern
#include "pcwin.h"
#include "pcmod.h"
#include "field.h"
#include "atom_k.h"
#include "units.h"

//#include "hlight.h"

EXTERN struct {
        int mm3, mmff, amber, opls;
        } AtomTypes[];
EXTERN struct {
        int nbond,ia[MAXBND],ib[MAXBND],ibo[MAXBND],istereo[MAXBND];
        } bonds;
EXTERN struct ElementType { char symbol[3];
                             int atomnum;
                             float weight, extweight, covradius, vdwradius;
                              int s,p,d,f, type;
                            } Elements[];

int  make_atom(int , float , float , float,char * );
int  make_typed_atom(int , int, float , float , float,char * );
void make_bond(int , int , int );
void deleteatom(int);
void deletebond(int, int);
void set_atomdata(int,int,int,int,int,int);
void message_alert(char *, char *);
int isangle(int,int);
void get_mmxtype(char *,int *);

// ===============================================
void set_atomdata(int ia, int mmxtype, int mm3type, int mmfftype,int ambertype,int oplstype)
{
    int type;
    
        if (mmxtype > 0)
           atom[ia].mmx_type = mmxtype;
        if (mm3type > 0)
           atom[ia].mm3_type = mm3type;
        if (mmfftype > 0)
           atom[ia].mmff_type = mmfftype;
        if (ambertype > 0)
           atom[ia].amber_type = ambertype;
        if (oplstype > 0)
           atom[ia].opls_type = oplstype;
        if (field.type == MMX || field.type == MM2)
        {
           type = mmxtype;
        } else if (field.type == MM3)
        {
           type = mm3type;
        }else if (field.type == AMBER)
        {
           type = ambertype;
        } else if (field.type == MMFF94)
        {
            type = mmfftype;
        } else if (field.type == OPLSAA)
        {
            type = oplstype;
        }

        if ( type < 300) 
        {
           atom[ia].tclass = atom_k.tclass[type];
           atom[ia].atomnum = atom_k.number[type];
           atom[ia].atomwt = atom_k.weight[type];
          strcpy(atom[ia].name, atom_k.symbol[type]);
        }        
}
// ===============================================
void set_atomtype(int ia, int mmxtype, int mm3type, int mmfftype,int ambertype,int oplstype)
{
        if (mmxtype > 0)
           atom[ia].mmx_type = mmxtype;
        if (mm3type > 0)
           atom[ia].mm3_type = mm3type;
        if (mmfftype > 0)
           atom[ia].mmff_type = mmfftype;
        if (ambertype > 0)
           atom[ia].amber_type = ambertype;
        if (oplstype > 0)
           atom[ia].opls_type = oplstype;
           
}
// ======================================================
int make_typed_atom(int type, int ffield,float x, float y, float z, char *name)
{
     int mmxtype, mm3type, mmfftype,ambertype,oplstype,newatom;

     if (type >= 300)  // pass metals to general routine
     {
         newatom = make_atom(type,x,y,z,name);
         return newatom;
     }
     natom++;
     if (natom >= MAXATOM - 10)
     {
         natom--;
         message_alert("Max atoms exceeded in makeatom","PCMODEL Error");
         return -1;
     }
     atom[natom].type = type;
     
     if (ffield == MMX || ffield == MM2)
     {
         atom[natom].mmx_type = type;
         mmxtype = type;
         if (mmxtype < 300)
         {
            mm3type = AtomTypes[type-1].mm3;
            mmfftype = AtomTypes[type-1].mmff;
            ambertype = AtomTypes[type-1].amber;
            oplstype = AtomTypes[type-1].opls;
        } else
        {
            mm3type = mmfftype = ambertype = oplstype = mmxtype;
        }
     }else if (ffield == MMFF94)
     {
         atom[natom].mmff_type = type;
//         mmxtype = mmff_mmxtype(type);
         mmfftype = type;
         if (mmxtype < 300)
         {
            mm3type = AtomTypes[mmxtype-1].mm3;
            ambertype = AtomTypes[mmxtype-1].amber;
            oplstype = AtomTypes[mmxtype-1].opls;
        } else
        {
            mm3type = ambertype = oplstype = mmxtype;
        }
     }
     if (field.type == MMX || field.type == MM2)
        type = mmxtype;
        
     atom[natom].tclass = atom_k.tclass[type];
     atom[natom].atomnum = atom_k.number[type];
     atom[natom].atomwt = atom_k.weight[type];
     strcpy(atom[natom].name, atom_k.symbol[type]);
        
     atom[natom].x = x; atom[natom].y = y; atom[natom].z = z;
     set_atomtype(natom,mmxtype,mm3type,mmfftype,ambertype,oplstype);
     return natom;
}
// ======================================================
int make_atom(int type, float x, float y, float z,char *name)
{
     int i,iz;
     int mmxtype, mm3type, mmfftype,ambertype,oplstype;
     
     natom++;
     if (natom >= MAXATOM - 10)
     {
         natom--;
         message_alert("Max atoms exceeded in makeatom","PCMODEL Error");
         return -1;
     }
        iz = strlen(name);
        for (i=0; i < strlen(name); i++)
        {
            if (name[i] == '+' || name[i] == '-')
            {
                name[i] = '\0';
                break;
            }
        }
        if (iz > 0 && name[0] != ' ') // got an atom name use it 
        {
            for (i=1; i <= MAXATOMTYPE; i++)
            {
                if (strcmp(name,atom_k.symbol[i]) == 0) // names match
                {
                    strcpy(atom[natom].name,name);
                    atom[natom].atomwt = atom_k.weight[i];
                    atom[natom].atomnum = atom_k.number[i];
                    atom[natom].type = atom_k.type[i];
                    if (type == 0)
                    {
                        type = atom[natom].type;  // this is an mmx type
                        if (type < 300)
                        {
                            mmxtype = type;
                            mm3type = AtomTypes[type-1].mm3;
                            mmfftype = AtomTypes[type-1].mmff;
                            ambertype = AtomTypes[type-1].amber;
                            oplstype = AtomTypes[type-1].opls;
                        } else
                        {
                            mmxtype = mm3type = mmfftype = ambertype = oplstype = type;
                        }
                        set_atomtype(natom,mmxtype,mm3type,mmfftype,ambertype,oplstype);
                    }  
                    else if (field.type == MMX || field.type == MM2)
                    {
                          atom[natom].mmx_type = type;
                          mmxtype = type;
                          if (type < 300)
                          {
                              mm3type = AtomTypes[type-1].mm3;
                              mmfftype = AtomTypes[type-1].mmff;
                              ambertype = AtomTypes[type-1].amber;
                              oplstype = AtomTypes[type-1].opls;
                          } else
                            mmxtype = mm3type = mmfftype = ambertype = oplstype = type;
                          
                          set_atomtype(natom,mmxtype,mm3type,mmfftype,ambertype,oplstype);
                    } else if (field.type == MMFF94)
                    {
                          atom[natom].mmff_type = type;
//                          mmxtype = mmff_mmxtype(type);
                          mm3type = AtomTypes[mmxtype-1].mm3;
                          mmfftype = type;
                          ambertype = AtomTypes[mmxtype-1].amber;
                          oplstype = AtomTypes[mmxtype-1].opls;
                          set_atomtype(natom,mmxtype,mm3type,mmfftype,ambertype,oplstype);
                    }
                    atom[natom].x = x; atom[natom].y = y; atom[natom].z = z;
                    atom[natom].vdw_radius = Elements[atom[natom].atomnum-1].covradius;
                    return natom;
                } 
            }
           for( i = 0; i < 103; i++ )
           {
              if( strcasecmp(Elements[i].symbol,name) == 0 )
              {
                  strcpy(atom[natom].name,Elements[i].symbol);
                  atom[natom].atomwt = Elements[i].weight;
                  atom[natom].atomnum = Elements[i].atomnum;
                  atom[natom].type = Elements[i].type;    // set generic type
                  atom[natom].mmx_type = Elements[i].type;    // set generic type
                  if (type > 0) 
                  {
                       atom[natom].type = type; // overwrite type if type is passed in
                       if (field.type == MMX || field.type == MM2)
                          atom[natom].mmx_type = type;
                       else if (field.type == MM3)
                          atom[natom].mm3_type = type;
                       else if (field.type == MMFF94)
                          atom[natom].mmff_type = type;
                       else if (field.type == AMBER)
                          atom[natom].amber_type = type;
                       else if (field.type == OPLSAA)
                          atom[natom].opls_type = type;
                  }
                  atom[natom].x = x; atom[natom].y = y; atom[natom].z = z;
                  atom[natom].vdw_radius = Elements[i].covradius;
                  return natom;
              }
            }
//  got a name but it is not recognized set default values
            strcpy(atom[natom].name,name);
            atom[natom].atomwt = 1.0;
            atom[natom].atomnum = 1;
            if (atom[natom].mmx_type == 20)
            {
                atom[natom].atomwt = 0.0;
                atom[natom].atomnum = 0;
            }
            atom[natom].vdw_radius = 2.0;
            atom[natom].color = 7;
            atom[natom].x = x; atom[natom].y = y; atom[natom].z = z;
            if (type > 0) 
            {
                atom[natom].type = type;
                if (field.type == MMX || field.type == MM2)
                    atom[natom].mmx_type = type;
                else if (field.type == MM3)
                    atom[natom].mm3_type = type;
                else if (field.type == MMFF94)
                    atom[natom].mmff_type = type;
                else if (field.type == AMBER)
                    atom[natom].amber_type = type;
                else if (field.type == OPLSAA)
                    atom[natom].opls_type = type;
             } else
            {
               atom[natom].mmx_type = 60;  // set type to Dummy atom
               atom[natom].mm3_type = 299;
            }
            return natom;
        } else if (type > 0)
        {
            atom[natom].type = type;
            if (type >= 300)
            {
                mmxtype = type;
                mm3type = type;
                mmfftype = type;
                ambertype = type;
                oplstype = type;
                set_atomtype(natom,mmxtype,mm3type,mmfftype,ambertype,oplstype);
            
            } else if (field.type == MMX || field.type == MM2)
            {
                atom[natom].mmx_type = type;
                mmxtype = type;
                mm3type = AtomTypes[type-1].mm3;
                mmfftype = AtomTypes[type-1].mmff;
                ambertype = AtomTypes[type-1].amber;
                oplstype = AtomTypes[type-1].opls;
                set_atomtype(natom,mmxtype,mm3type,mmfftype,ambertype,oplstype);
            }else if (field.type == MMFF94)
            {
                atom[natom].mmff_type = type;
//                mmxtype = mmff_mmxtype(type);
                mm3type = AtomTypes[mmxtype-1].mm3;
                mmfftype = type;
                ambertype = AtomTypes[mmxtype-1].amber;
                oplstype = AtomTypes[mmxtype-1].opls;
                set_atomtype(natom,mmxtype,mm3type,mmfftype,ambertype,oplstype);
            }
            atom[natom].tclass = atom_k.tclass[type];
            atom[natom].atomnum = atom_k.number[type];
            atom[natom].atomwt = atom_k.weight[type];
            strcpy(atom[natom].name, atom_k.symbol[type]);
            atom[natom].chrg_color = 7;
        
            atom[natom].x = x; atom[natom].y = y; atom[natom].z = z;
            return natom;
        } else
        {
           printf("Atom does not have valid atom name %s or type %d\n",name,type);
           exit(0);
//           message_alert("Input atom does not have valid atomic symbol or atom type","Error");
//           return -1;
        }
}
// ====================================================
void make_bond(int ia1, int ia2, int bo)
{
    int loop,loop1;

   if (ia1 < 1 || ia1 > MAXATOM) return;
   if (ia2 < 1 || ia2 > MAXATOM) return;
   /*   find if bond exists        */
   bonds.ia[bonds.nbond] = ia1;
   bonds.ib[bonds.nbond] = ia2;
   bonds.ibo[bonds.nbond] = bo;
   bonds.nbond++;
   
   for (loop = 0; loop < MAXIAT; loop++)
   {
     if (atom[ia1].iat[loop] == ia2)
     {
        if (bo == 1)
           atom[ia1].bo[loop] += bo;
        else
           atom[ia1].bo[loop] = bo;
        
        for (loop1 = 0; loop1 < MAXIAT; loop1++)
        {
         if (atom[ia2].iat[loop1] == ia1)
         {
             if ( bo == 1)
             {
                atom[ia2].bo[loop1] += bo; /* bond exists return */
                return;
             } else
             {
                atom[ia2].bo[loop1] = bo; /* bond exists return */
                return;
             }
         }
        }
      }
   }
/*  bond does not exist create it               */     
   for (loop = 0; loop < MAXIAT; loop++) 
   {
      if (atom[ia1].iat[loop] == 0) 
      {
          atom[ia1].iat[loop] = ia2;
          atom[ia1].bo[loop] = bo;
          break;
      }
   }
   for (loop = 0; loop < MAXIAT; loop++) 
   {
      if (atom[ia2].iat[loop] == 0) 
      {
          atom[ia2].iat[loop] = ia1;
          atom[ia2].bo[loop] = bo;
          break;
      }
   }
}
// ===============================================
void deleteatom(int i)
{
   int j,k, ibo;
   atom[i].type = 0;
   atom[i].mmx_type = 0;
   atom[i].mm3_type = 0;
   atom[i].mmff_type = 0;
   atom[i].amber_type = 0;
   atom[i].opls_type = 0;
   atom[i].atomnum = 0;
   atom[i].x = 0.0F;
   atom[i].y = 0.0F;
   atom[i].z = 0.0F;
   atom[i].flags = 0;
   for (j=0; j < MAXSSCLASS; j++)
      atom[i].substr[j] = 0;
   for (j=0; j<MAXIAT; j++)
   {
      if (atom[i].iat[j] != 0 )
      {
         if (atom[atom[i].iat[j]].atomnum == 1 || atom[atom[i].iat[j]].atomnum == 0 )
         {
             atom[atom[i].iat[j]].type = 0;
             atom[atom[i].iat[j]].x = 0.0F;
             atom[atom[i].iat[j]].y = 0.0F;
             atom[atom[i].iat[j]].z = 0.0F;
             atom[atom[i].iat[j]].flags = 0;
         }
         ibo = atom[i].bo[j];
         for (k=1; k <= ibo; k++)
            deletebond(i,atom[i].iat[j]);
         atom[i].iat[j] = 0;
     }
   }
   natom--;
}
// ==================================================
void deletebond(int i, int j) 
{
   int i1,j1;
   for (i1=0; i1 < MAXIAT; i1++) 
   {
      if (atom[i].iat[i1] == j) 
      {
        if (atom[i].bo[i1] == 9)  /* if deleting a coordinated bond - delete it completely */
        {
            atom[i].bo[i1] = 0;
            atom[i].iat[i1] = 0;
        }
        atom[i].bo[i1] -= 1;
        if (atom[i].bo[i1] <= 0 )
            atom[i].iat[i1] = 0;
        break;
      }
   }
   for (j1=0; j1 < MAXIAT; j1++) 
   {
      if (atom[j].iat[j1] == i) 
      {
        if (atom[j].bo[j1] == 9)  /* if deleting a coordinated bond - delete it completely */
        {
            atom[j].bo[j1] = 0;
            atom[j].iat[j1] = 0;
        }
        atom[j].bo[j1] -= 1;
        if (atom[j].bo[j1] <= 0)
            atom[j].iat[j1] = 0;
        break;
      }
   }
}
/* -----------------------------------------------------*/                  
void get_mmxtype(char *atname,int *mmxtype)
{
    int i, iz;
    char tmpname[5], errstring[50];

    iz = strlen(atname);
    for (i=0; i < iz; i++)
    {
        if ( isalpha(atname[i]) || atname[i] == '+' || atname[i] == '-')
        {
            tmpname[i] = atname[i];
        } else if (isdigit(atname[i]))
        {
            tmpname[i] = '\0';
            break;
        }
    }
    if (i == iz)
       tmpname[i] = '\0';

//  check for 2 character names
    iz = strlen(tmpname);
    if (iz > 2)
       tmpname[2] = '\0';
    *mmxtype = 0;
    tmpname[0] = toupper(tmpname[0]);
//
    for (i=1; i <= MAXATOMTYPE; i++)
    {
        if (strcmp(atom_k.symbol[i], tmpname) == 0)
        {
            *mmxtype = i;
            break;
        }
    }
    if (*mmxtype == 0)
    {
       for (i=0; i < strlen(tmpname); i++)
       {
           if (tmpname[i] == '+' || tmpname[i] == '-')
           {
               tmpname[i] = '\0';
               break;
           }
       }
       for( i = 0; i < 103; i++ )
       {
          if( strcasecmp(Elements[i].symbol,tmpname) == 0 )
          {
              *mmxtype = Elements[i].type;    // set generic type
          }
       }
    }
        
    if (*mmxtype == 0)
    {
        tmpname[1] = '\0';
        for (i=1; i <= atom_k.natomtype; i++)
        {
           if (strcmp(atom_k.symbol[i], tmpname) == 0)
           {
               *mmxtype = i;
               break;
           }
        }
    }
    if (*mmxtype == 0)
    {
        sprintf(errstring,"Error setting atom type for atom %s",atname);
        message_alert(errstring,"Smiles Setup");
    }
        
}

