#define EXTERN

#include "pcwin.h"
#include "pcmod.h"
#include "gmmx.h"
#include "utility.h"
#include "bonds_ff.h"
#include "units.h"
#include "field.h"
#include "pdb.h"
#include "pot.h"
#include "atom_k.h"

#include <unistd.h>
#include <string.h>
#include <time.h>

struct t_smiles {
        int success;
        char smi_string[256];
        }  smiles;

EXTERN struct {
        int  nchiral, icenter[MAXCHIRAL],chirality[MAXCHIRAL], iest[MAXCHIRAL][4];
        } chiral;        
EXTERN struct {
        int nbond,ia[MAXBND],ib[MAXBND],ibo[MAXBND],istereo[MAXBND];
        } bonds;       
EXTERN struct t_files {
        int nfiles, append, batch, icurrent, ibatno;
        }       files;       
EXTERN struct  t_bondk1 {
        int use_ring3, use_ring4, use_ring5;
        int nbnd, nbnd3, nbnd4, nbnd5, ndeloc;
        char kb[MAXBONDCONST][7], kb3[MAXBOND3CONST][7],kb4[MAXBOND4CONST][7],kb5[MAXBOND5CONST][7];
        char kbdel[MAXBONDDELOC][7];
        float s[MAXBONDCONST], t[MAXBONDCONST];
        float s3[MAXBOND3CONST], t3[MAXBOND3CONST];
        float s4[MAXBOND4CONST], t4[MAXBOND4CONST];
        float s5[MAXBOND5CONST], t5[MAXBOND5CONST];
        float sdel[MAXBONDDELOC], tdel[MAXBONDDELOC];
        }  bondk1;
EXTERN struct t_angk1 {
        int use_ang3, use_ang4, use_ang5;
        int nang, nang3, nang4, nang5;
        int ndel, ndel3, ndel4;
        char  ktype[MAXANGCONST][10],ktype3[MAXANG3CONST][10],ktype4[MAXANG4CONST][10],ktype5[MAXANG5CONST][10];
        char  kdel[MAXANGDEL][10],kdel3[MAXANG3DEL][10],kdel4[MAXANG4DEL][10];
        float con[MAXANGCONST], ang[MAXANGCONST][3];
        float con3[MAXANG3CONST], ang3[MAXANG3CONST][3];        
        float con4[MAXANG4CONST], ang4[MAXANG4CONST][3];        
        float con5[MAXANG5CONST], ang5[MAXANG5CONST][3];
        float condel[MAXANGDEL],  angdel[MAXANGDEL][3];      
        float condel3[MAXANG3DEL], angdel3[MAXANG3DEL][3];      
        float condel4[MAXANG4DEL], angdel4[MAXANG4DEL][3];      
         } angk1;

typedef struct {
        int natom;
        int *itype;
        int **iat,**ibo;
        double *x,*y,*z;
        float *charge;
        char name[3];
       } TMPMOLE;
        
TMPMOLE tmpmolecule[10];

float xtmp[MAXATOM],ytmp[MAXATOM],ztmp[MAXATOM];
 
#define St_Start  1
#define St_End    2
#define St_Error  3

#define SINGLE    1
#define DOUBLE    2
#define TRIPLE    3
#define AROMATIC  4

#define NOSTERO   0
#define UP        1
#define DOWN     -1
#define CIS       2
#define TRANS     3

#define ERROR           0
#define NEW_MOLECULE    1
#define START_ATOM      2
#define END_ATOM        3
#define START_BRANCH    4
#define END_BRANCH      5
#define SINGLE_BOND     6
#define DOUBLE_BOND     7
#define TRIPLE_BOND     8
#define AROMATIC_BOND   9
#define NUMBER          10
#define ATOM            11
#define SLASH           12
#define FSLASH          13
#define BSLASH          14

#define MAXBRANCH       200

int special_cases(char *);
void do_iterate(void);
int check_coord(void);
int check_smiles(char *,int *);
void read_smiles(int,int);
void get_smiles_token(int *,int *,char *,char *);
void message_alert(char *,char *);
void get_mmxtype(char *,int *);
int  make_atom(int , float , float , float,char *);
void make_bond(int , int , int );
void quick_type(void);
float get_bond(int,int);
float get_angl(int,int,int);
int isbond(int,int);
int isangle(int, int);
int get_bondorder(int,int);
void numeral(int,char *,int);
void set_atomtypes(int);
void set_angles(int);
int find_index(int,int,int,int);
void do_fused();
void parse_smiles(char *);   
double dihdrl(int,int,int,int);
void write_smiles(void);
void new_smiles(void);
void refine(void);
void hadd(void);
void deleteatom(int);
void reseq(void);
int FetchRecord(FILE *, char *);
void read_parameterfile(char *);
void initialize(void);
void initialize_pcmodel(void);
void initialize_gmmx(void);
void write_sdf(void);
void build_coord(void);
int process_atom(char *);
void find_rings(void);
int is_ring62(int, int);

//
EXTERN FILE *wfile;

int strnum;
int Build;
int lastatom;

int invalidCharsFound(char *line) {
  int invalid = 0;
  int i = 0;
  if (line == NULL) invalid = 1;
  else {
    int len = strlen(line);
    for (i = 0; i < len; i++) {
      if (line[i] == '\002' ||
	  line[i] == '\001' ||
	  line[i] == '\003' ||
	  line[i] == '\004' ||
	  line[i] == '\005') invalid = 1;
    }
  }
  return(invalid);
}

void usage(void) {
  printf("\nUsage: smi2sdf [-op] INPUTFILE\n\n" 
	 "-o\tOutput file name\n"
	 "-p\tParameter file name\n"
	 "-e\tLog file name\n\n");
}

int main(int argc, char *argv[])
{
    int i,ncount,nc, nstruct, nret,j, ibotptr,newatom,icount;
    int ninorganic,nsdf;
    int itype;
    char line[2000];
    char line1[2000];
    float xmin,xmax,xtmp,ytmp,ztmp,diff;
    FILE *infile,*inorg;

    int show_time = 0;
    char *filename = NULL;
    char *paramfile = NULL;
    char *outfile = NULL;
    char *logfilename = NULL;
    char *inorg_file = NULL;

    if (argc < 2) {
      usage();
      exit(-1);
    }

    int c;
    while ((c = getopt(argc, argv, "e:o:p:t")) != -1) {
      switch(c) {
      case 't':
	show_time = 1;
	break;
      case 'o':
	outfile = strdup(optarg);
	break;
      case 'p':
	paramfile = strdup(optarg);
	break;
      case 'e':
	logfilename = strdup(optarg);
	break;
      case '?':
	if (isprint (optopt))
	  fprintf (stderr, "Unknown option `-%c'.\n", optopt);
	else
	  fprintf (stderr,
		   "Unknown option character `\\x%x'.\n",
		   optopt);
	return 1;
      default:
	abort ();	
      }
    }

    // there should only be 1 non-option argument, which is
    // the smi file to process. If not, bail
    if (optind == argc) {
      printf("ERROR Must specify an input SMILES file. Exiting\n");
      exit(-1);
    }
    filename = (char*) malloc(sizeof(char*) * (strlen(argv[optind])+1));
    if (!filename) {
      fprintf(stderr, "FATAL: Out of memory. Exiting\n");
      exit(-1);
    }
    filename = strncpy(filename, argv[optind], strlen(argv[optind]));
    filename[strlen(argv[optind])] = '\0';

    // check whether we got anything, otherwise put in defaults
    if (outfile == NULL) outfile = strdup("output.sdf");
    if (paramfile == NULL) paramfile = strdup("mmxconst.prm");
    if (logfilename == NULL) logfilename= strdup("error.log");

    logfile = fopen(logfilename,"w");

    // count number of lines
    ncount = 0;
    infile = fopen(filename,"r");
    if (infile == NULL)  {
      printf("Error opening SMILES file\n");
      exit(0);
    }
    while (FetchRecord(infile,line)) {
      if (strlen(line) > 1) ncount++;
    }
    fclose(infile);
    printf("Found %d structures in %s\n",ncount,filename);
    fprintf(logfile,"Found %d structures in %s\n",ncount,filename);

    initialize_pcmodel();
    initialize_gmmx();

    // read parameter file
    read_parameterfile(paramfile);

    // make the inorganic file name from our input file name
    // we'll assume that our input file has a .smi prefix
    inorg_file = (char*) malloc(sizeof(char) * (strlen(filename)+7));
    if (!inorg_file) {
      fprintf(stderr, "FATAL: out of memory. Exiting\n");
      exit(-1);
    }
    inorg_file = strcpy(inorg_file, filename);
    inorg_file[ strlen(inorg_file)-4 ] = '\0';
    inorg_file = strcat(inorg_file, "_inorg.smi");
    inorg_file[strlen(inorg_file)] = '\0';


    printf("\n\nInput file  = %s\nOutput file = %s\nParam file  = %s\nLog file    = %s\n"
	   "Inorganic file = %s"
	   "\n\n", 
	   filename, outfile, paramfile, logfilename, inorg_file);

    clock_t time_start = clock();

    // convert
    if (ncount > 0)  {
      infile = fopen(filename,"r");
      if (infile == NULL)  {
	printf("Error opening Smiles file\n");
	exit(0);
      }
      wfile = fopen(outfile,"w");
      if (wfile == NULL) {
	printf("Error opening Output file\n");
	exit(0);
      }
      inorg = fopen(inorg_file,"w");
      if (inorg == NULL) {
	printf("Error opening Inorganic file\n");
	exit(0);
      }

      // start of loop
      ninorganic = 0;
      nsdf = 0;
      for (icount=0; icount < ncount; icount++)  {
	strnum = icount;
	FetchRecord(infile,line);

	if (invalidCharsFound(line)) {
	  printf("Invalid chars in the SMILES (line %d)\n", icount+1);
	  fprintf(logfile, "Invalid chars in the SMILES (line %d)\n", icount+1);
	  goto L_10;
	}

	// check smiles - look for single atoms and inorganic structures
	nstruct = 0;
	nret = check_smiles(line,&nstruct);
	if (nret == FALSE && strlen(line) > 0) {
	  printf("Adding structure %d to inorganic: %s\n",icount+1,line);
	  ninorganic++;
	  fprintf(inorg,"%s\n",line);
	  goto L_10;
	} else if (nstruct > 9) {
	  printf("Too many separate structures, skipping number %d\n",icount+1);
	  fprintf(logfile, "Too many separate structures, skipping number %d\n",icount+1);
	  goto L_10;
	}

	// count number of separate structures
	if (nstruct == 0) {
	  initialize();
	  parse_smiles(line);
	  quick_type();
	  if (natom > 1)
	    build_coord();
	  write_sdf();
	  nsdf++;
	} else {
	  nc = 0;
	  nstruct = 0;
	  for (i=0; i < strlen(line) + 1; i++) {
	    if (line[i] != '.' && line[i] != '\0') {
	      line1[nc] = line[i];
	      nc++;
	    } else  {
	      line1[nc] = '\0';
	      nc = 0;
	      initialize();
	      parse_smiles(line1);
	      quick_type();
	      if (natom > 1) build_coord();
	      // save current molecule
	      tmpmolecule[nstruct].natom = natom;
	      tmpmolecule[nstruct].itype = ivector(0,natom+1);
	      tmpmolecule[nstruct].x = dvector(0,natom+1);
	      tmpmolecule[nstruct].y = dvector(0,natom+1);
	      tmpmolecule[nstruct].z = dvector(0,natom+1);
	      tmpmolecule[nstruct].charge = vector(0,natom+1);
	      tmpmolecule[nstruct].iat = imatrix(0,natom+1,0,4);
	      tmpmolecule[nstruct].ibo = imatrix(0,natom+1,0,4);
	      for (j=1; j <= natom; j++) {
		tmpmolecule[nstruct].itype[j] = atom[j].type;
		tmpmolecule[nstruct].x[j] = atom[j].x;
		tmpmolecule[nstruct].y[j] = atom[j].y;
		tmpmolecule[nstruct].z[j] = atom[j].z;
		tmpmolecule[nstruct].charge[j] = atom[j].charge;
		tmpmolecule[nstruct].iat[j][0] = atom[j].iat[0];
		tmpmolecule[nstruct].iat[j][1] = atom[j].iat[1];
		tmpmolecule[nstruct].iat[j][2] = atom[j].iat[2];
		tmpmolecule[nstruct].iat[j][3] = atom[j].iat[3];
		tmpmolecule[nstruct].ibo[j][0] = atom[j].bo[0];
		tmpmolecule[nstruct].ibo[j][1] = atom[j].bo[1];
		tmpmolecule[nstruct].ibo[j][2] = atom[j].bo[2];
		tmpmolecule[nstruct].ibo[j][3] = atom[j].bo[3];
	      }
	      nstruct++;
	    }
	  }
	  

	  strcpy(line1,Struct_Title);
	  initialize();
	  strcpy(Struct_Title,line1);

	if (icount % 1 == 0) {
	  printf("\rProcessing molecule %d [%s]",icount+1, Struct_Title);
	  fflush(stdout);
	}

	  for (i=0; i < nstruct; i++) {
	    xmax = -100.00;
	    for (j=1; j <= natom; j++) {
	      if (atom[j].x > xmax) xmax = atom[j].x;
	    }
	    ibotptr = natom;
	    xmin = 100.0;
	    for (j=1; j <= tmpmolecule[i].natom; j++) {
	      if (tmpmolecule[i].x[j] < xmin) xmin = tmpmolecule[i].x[j];
	    }
	    diff = fabs(xmax-xmin);
	    for (j=1; j <= tmpmolecule[i].natom; j++)  {
	      itype = tmpmolecule[i].itype[j];
	      xtmp = tmpmolecule[i].x[j];
	      ytmp = tmpmolecule[i].y[j];
	      ztmp = tmpmolecule[i].z[j];
                        
	      newatom = make_atom(itype,xtmp+diff+2.0,ytmp,ztmp,"");
	      if(tmpmolecule[i].iat[j][0] != 0 && newatom < tmpmolecule[i].iat[j][0]+ibotptr)
		make_bond(newatom,tmpmolecule[i].iat[j][0]+ibotptr,tmpmolecule[i].ibo[j][0]);
	      if(tmpmolecule[i].iat[j][1] != 0 && newatom < tmpmolecule[i].iat[j][1]+ibotptr)
		make_bond(newatom,tmpmolecule[i].iat[j][1]+ibotptr,tmpmolecule[i].ibo[j][1]);
	      if(tmpmolecule[i].iat[j][2] != 0 && newatom < tmpmolecule[i].iat[j][2]+ibotptr)
		make_bond(newatom,tmpmolecule[i].iat[j][2]+ibotptr,tmpmolecule[i].ibo[j][2]);
	      if(tmpmolecule[i].iat[j][3] != 0 && newatom < tmpmolecule[i].iat[j][3]+ibotptr)
		make_bond(newatom,tmpmolecule[i].iat[j][3]+ibotptr,tmpmolecule[i].ibo[j][3]);
	      atom[newatom].charge = tmpmolecule[i].charge[j];
	    }
	  }
	  write_sdf();
	  nsdf++;
	  // done parsing build molecules and release space
	  for (j=0; j < nstruct; j++) {
	    nc = tmpmolecule[j].natom;
	    free_ivector(tmpmolecule[j].itype, 0,nc+1);
	    free_dvector(tmpmolecule[j].x, 0,nc+1);
	    free_dvector(tmpmolecule[j].y, 0,nc+1);
	    free_dvector(tmpmolecule[j].z, 0,nc+1);
	    free_imatrix(tmpmolecule[j].iat, 0,nc+1,0,4);
	    free_imatrix(tmpmolecule[j].ibo, 0,nc+1,0,4);
	  }
                   
	}
	// break string into substrings
	// parse each string
	// build coords
	// copy coords
	// build next structure
	// put together all 
      L_10:
	continue;
      }
      fprintf(logfile,"Total Smiles Strings: %d\n",ncount);
      fprintf(logfile,"Total SDF structures created: %d\n",nsdf);
      fprintf(logfile,"Total Inorganic structures: %d\n",ninorganic);
        
      fclose(infile);
      fclose(wfile);
      fclose(logfile);
      fclose(inorg);

      free(filename);
      free(inorg_file);
      free(paramfile);
      free(logfilename);
      free(outfile);

    }
    printf("\n");

    clock_t time_end = clock();
    double time_elapsed = ((double) (time_end - time_start)) / CLOCKS_PER_SEC;
    if (show_time) printf("\nElapsed CPU time = %3.2f s\n", time_elapsed);

    return TRUE;
}
/* =======================================================  */
//void read_smiles(int isel,int isubred)
//{
//    char line[256];
//    int icount;
//    FILE *infile;
    
//    infile = fopen_path(Openbox.path,Openbox.fname,"r");

/*    if (isel != 1)
    {
        for (icount = 1; icount < isel; icount++)
           FetchRecord(infile,line);
    }
           
    // read line
    FetchRecord(infile,line);
    parse_smiles(line);
    fclose(infile);
// generate 3d may need some other place for this
    quick_type();
              
    if (natom > 0)     
          build_coord();
} */
// ===============================================
void get_smiles_token(int *i,int *retval,char *line,char *astring)
{    
    if (line[*i] == '-')
    {
       *retval = SINGLE_BOND;
       *i += 1;
    } else if (line[*i] == '=')
    {
       *retval = DOUBLE_BOND;
       *i += 1;
    } else if (line[*i] == '\/') 
    {
       *retval = FSLASH;
       *i += 1;
    } else if (line[*i] == '\\') 
    {
       *retval = BSLASH;
       *i += 1;
    } else if (line[*i] == '#')
    {
       *retval = TRIPLE_BOND;
       *i += 1;
    } else if (line[*i] == ':')
    {
       *retval = AROMATIC_BOND;
       *i += 1;
    } else if (line[*i] == '.')
    {
       *retval = NEW_MOLECULE;
       *i += 1;
    } else if (line[*i] == ' ')  // done
    {
       *retval = ERROR;
       *i += 1;
    } else if (line[*i] == '[')
    {
       *retval = START_ATOM;
       *i += 1;
    } else if (line[*i] == ']')
    {
       *retval = END_ATOM;
       *i += 1;
    } else if (line[*i] == '(')
    {
       *retval = START_BRANCH;
       *i += 1;
    } else if (line[*i] == ')')
    {
       *retval = END_BRANCH;
       *i += 1;
    } else if (isdigit(line[*i]))
    {
       *retval = NUMBER;
       astring[0] = line[*i];
       astring[1] = '\0';
       *i += 1;
    } else if (line[*i] == '%')
    {
       *retval = NUMBER;
       astring[0] = line[*i];
       astring[1] = line[*i+1];
       astring[2] = line[*i+2];
       astring[3] = '\0';
       *i += 3;
    }else if (isalpha(line[*i]))
    {
        *retval = ATOM;
        astring[0] = line[*i];
        if (line[*i] == 'c' || line[*i] == 'n' || line[*i] == 'o' || line[*i] == 's' )
        {
            *i += 1;
            astring[1] = '\0';            
        } else if (line[*i] == 'C' && line[*i+1] == 'l')
        {
            *i += 1;
            astring[1] = line[*i];
            astring[2] = '\0';
            *i += 1;
        } else if (line[*i] == 'B' && line[*i+1] == 'r')
        {
            *i += 1;
            astring[1] = line[*i];
            astring[2] = '\0';
            *i += 1;
        } else
        {
            *i += 1;
            astring[1] = '\0';
        }
    } else
       *retval = ERROR;
}
// =================================================
int bondtype;
// ================================================
void parse_smiles(char *line)
{
    char astring[30],tmp[2];
    int i,j,ilength,branch_pt[MAXBRANCH],branch_bond[MAXBRANCH],ibranch,icount;
    int rno, ring_atoms[255], ring_bonds[255];
    int ierr;
    int token, state,itype,newatom;
        int iat1,iat2,ndouble,odd,ibt[6],ibonds[6];
    int k,jji,jjk,jji_bo,jjk_bo;
    long int pi_mask;
    int USE_AROMATIC;
    static int oldtype;
    static int SLASHTYPE;
        
    USE_AROMATIC = FALSE;
    pi_mask = (1L << PI_MASK);
    ilength = strlen(line);
    state = St_Start;
    bondtype = SINGLE;
    oldtype = SINGLE;
    lastatom = 0;
    ibranch = 0;
    SLASHTYPE = 0;
    for (i=0; i < 255; i++)
      {
       ring_atoms[i] = -1;
       ring_bonds[i] = SINGLE;
      }
       
    i=0;
    while (state != St_End && state != St_Error)
    {
        get_smiles_token(&i,&token,line,astring);
        if (token == ERROR)
           state = St_Error;
        else if (token == NEW_MOLECULE) // new molecule
        {
           state = St_End;
           lastatom = 0;      
        } else if (token == START_ATOM) // start atom def
        {
            strcpy(astring,"");
            icount = 0;
            for (j=i; j < ilength; j++)
            {
                if (line[j] != ']')
                {
                    astring[icount] = line[j];
                    icount++;
                } else
                    break;
            }
            i += icount;
            astring[icount] = '\0';
            // astring is now atomtype + information about charge or atomic number
            // convert atom symbol to type
            ierr = process_atom(astring);
        }else if (token == END_ATOM) // end atom def
        {
        }else if (token == START_BRANCH) // start branch
        {
           branch_pt[ibranch] = lastatom;
		   branch_bond[ibranch] = bondtype;
           ibranch++;
           if (ibranch > MAXBRANCH)
           {
               sprintf(astring,"Too many branches: %d\0",strnum);
               fprintf(logfile,"Too many branches: %d %s\0",strnum, Struct_Title);
               message_alert(astring,"Error");
               return;
           }
           
        } else if (token == END_BRANCH) // end branch
        {
            ibranch--;
            if (ibranch < 0)
            {
                fprintf(logfile,"Error parsing branches: %d\0",strnum);
                message_alert("Error parsing branches. Abort!!","Error");
                return;
            }
            lastatom = branch_pt[ibranch];
			bondtype = branch_bond[ibranch];
        } else if (token == SINGLE_BOND) // start single bond def
           bondtype = SINGLE;
        else if (token == DOUBLE_BOND) // start double bond def
           bondtype = DOUBLE;
        else if (token == TRIPLE_BOND) // start triple bond def
           bondtype = TRIPLE;
        else if (token == AROMATIC_BOND) // start aromatic bond def
           bondtype = AROMATIC;
        else if (token == FSLASH)
        {
            if (SLASHTYPE == 1)  // got matching slash of same type
            {
                bonds.istereo[bonds.nbond-1] = CIS;
                SLASHTYPE = 0;
            } else if (SLASHTYPE == -1) // got matching slash of different type
            {
                bonds.istereo[bonds.nbond-1] = TRANS;
                SLASHTYPE = 0;
            } else // first slash encountered
            {
                SLASHTYPE = 1;
            }
        } else if (token == BSLASH)
        {
            if (SLASHTYPE == -1)  // got matching slash of same type
            {
                bonds.istereo[bonds.nbond-1] = CIS;
                SLASHTYPE = 0;
            } else if (SLASHTYPE == 1) // got matching slash of different type
            {
                bonds.istereo[bonds.nbond-1] = TRANS;
                SLASHTYPE = 0;
            } else // first slash encountered
            {
                SLASHTYPE = -1;
            }
        } else if (token == NUMBER) // start or end of ring
        {
            if (astring[0] == '%')
            {
                rno = (10*(astring[1]-'0')) + (astring[2]-'0');
            } else
                sscanf(astring,"%d",&rno);
            if (ring_atoms[rno] == -1)
              {
               ring_atoms[rno] = lastatom;
               ring_bonds[rno] = bondtype;
               if (bondtype == DOUBLE) bondtype = SINGLE;
              }
            else
            {
                if (ring_bonds[rno] == AROMATIC)
                   make_bond(ring_atoms[rno],lastatom,1);
                else
                   make_bond(ring_atoms[rno],lastatom,ring_bonds[rno]);
                bondtype = SINGLE;
                ring_atoms[rno] = -1;
                ring_bonds[rno] = SINGLE;
            }
        }else if (token == ATOM)   // atomic symbol
        {
            // convert atom symbol to type
            if (bondtype == AROMATIC && !(astring[0] == 'c' || astring[0] == 'n' || astring[0] == 'o' || astring[0] == 's'))
            {
               bondtype = SINGLE;
            }
            get_mmxtype(astring,&itype);
            if (itype == 0)
            {
                fprintf(logfile,"Error processing structure: %d\0",strnum);
                printf("Error processing structure: %d\n",strnum);
                return;
            }
            // make atom
            itype = 0;
            newatom = make_atom(itype,0.0,0.0,0.0,astring);
            if (newatom == -1)
                 break;
            atom[newatom].use = FALSE;
            if (lastatom != 0) //  make bond
            {
                if (bondtype == AROMATIC)
                    make_bond(lastatom,natom,1);  // make all aromatic bonds single 
                else
                    make_bond(lastatom,natom,bondtype);
            }
            bondtype = SINGLE;
            if (astring[0] == 'c' || astring[0] == 'n' || astring[0] == 'o' || astring[0] == 's')
            {
               USE_AROMATIC = TRUE;
               bondtype = AROMATIC;
               atom[newatom].flags |= pi_mask;
            }
            lastatom = natom;
        }
          
    }
// pick off title information from end of line
    icount = 0;
    strcpy(Struct_Title,"");
    if (i < ilength)
    {
        if ( (ilength-i) > 80) ilength = i + 79;
        for (j=i; j < ilength; j++)
        {
            if (line[j] == '\n')
               break;
            else if (line[j] != ' ')
            {
               Struct_Title[icount] = line[j];
               icount++;
            }
        }
    }
    Struct_Title[icount] = '\0';
    // look for pi atoms and check bond orders
        if (USE_AROMATIC == TRUE)
        {       
                find_rings();
                // loop through all 6 membered rings and check bond orders
                for (i=1; i < natom; i++)
                {
                        for (j=i+1; j <= natom; j++)
                        {
                                if ( (atom[i].flags & (1L << PI_MASK)) && (atom[j].flags & (1L << PI_MASK)) )
                                {
                                        if (get_bondorder(i,j) == 2)
                                                deletebond(i,j);
                                }
                        }
                }
                for (i=0; i < gmmxring.nrings; i++)
                {
                        if (gmmxring.nring_atoms[i] == 6)
                        {
                                ndouble = 0;
                                for (j=0; j < 6; j++)  // count number of double bonds about each ring atom - handle on exocyclic double bonds
                                {
                                        iat1 = gmmxring.ring_atoms[i][j];
                                        ibonds[j] = 0;
                                        for (k=0; k < MAXIAT; k++)
                                        {
                                                if (atom[iat1].iat[k] != 0 && atom[iat1].bo[k] == 2)
                                                        ibonds[j]++;
                                        }
                                }
                                for (j=0; j < 5; j++)
                                {
                                        iat1 = gmmxring.ring_atoms[i][j];
                                        iat2 = gmmxring.ring_atoms[i][j+1];
                                        if (get_bondorder(iat1,iat2) == 2)
                                        {
                                                ibt[j] = 2;
                                                ndouble++;
                                        } else
                                                ibt[j] = 1;
                                }
                                iat1 = gmmxring.ring_atoms[i][0];
                                iat2 = gmmxring.ring_atoms[i][5];
                                if (get_bondorder(iat1,iat2) == 2)
                                {
                                        ibt[5] = 2;
                                        ndouble++;
                                }
                                if (ndouble > 0)  // have a double bond in ring
                                {
                                        for (j=0; j < 6; j++)
                                        {
                                                if (ibt[j] == 2)
                                                {
                                                        if (j%2 == 0) 
                                                                odd = FALSE;
                                                        else
                                                                odd = TRUE;
                                                        break;
                                                }
                                        }
                                        if (odd == TRUE)  // set bonds 1,3,5
                                        {
                                                iat1 = gmmxring.ring_atoms[i][1];
                                                iat2 = gmmxring.ring_atoms[i][2];
                                                if (get_bondorder(iat1,iat2) == 1 && ibonds[1] == 0 && ibonds[2] == 0)
                                                  {
                                                        make_bond(iat1,iat2,1);
                                                        atom[iat1].use = TRUE;
                                                        atom[iat2].use = TRUE;
                                                  }
                                                iat1 = gmmxring.ring_atoms[i][3];
                                                iat2 = gmmxring.ring_atoms[i][4];
                                                if (get_bondorder(iat1,iat2) == 1 && ibonds[3] == 0 && ibonds[4] == 0)
                                                  {
                                                        make_bond(iat1,iat2,1);
                                                        atom[iat1].use = TRUE;
                                                        atom[iat2].use = TRUE;
                                                  }
                                                iat1 = gmmxring.ring_atoms[i][5];
                                                iat2 = gmmxring.ring_atoms[i][0];
                                                if (get_bondorder(iat1,iat2) == 1 && ibonds[5] == 0 && ibonds[0] == 0)
                                                  {
                                                        make_bond(iat1,iat2,1);
                                                        atom[iat1].use = TRUE;
                                                        atom[iat2].use = TRUE;
                                                  }
                                        } else if (odd == FALSE) // set bonds 0,2,4
                                        {
                                                iat1 = gmmxring.ring_atoms[i][0];
                                                iat2 = gmmxring.ring_atoms[i][1];
                                                if (get_bondorder(iat1,iat2) == 1 && ibonds[0] == 0 && ibonds[1] == 0)
                                                  {
                                                        make_bond(iat1,iat2,1);
                                                        atom[iat1].use = TRUE;
                                                        atom[iat2].use = TRUE;
                                                  }

                                                iat1 = gmmxring.ring_atoms[i][2];
                                                iat2 = gmmxring.ring_atoms[i][3];
                                                if (get_bondorder(iat1,iat2) == 1 && ibonds[2] == 0 && ibonds[3] == 0)
                                                  {
                                                        make_bond(iat1,iat2,1);
                                                        atom[iat1].use = TRUE;
                                                        atom[iat2].use = TRUE;
                                                  }

                                                iat1 = gmmxring.ring_atoms[i][4];
                                                iat2 = gmmxring.ring_atoms[i][5];
                                                if (get_bondorder(iat1,iat2) == 1 && ibonds[4] == 0 && ibonds[5] == 0)
                                                  {
                                                        make_bond(iat1,iat2,1);
                                                        atom[iat1].use = TRUE;
                                                        atom[iat2].use = TRUE;
                                                  }
                                        }
                                } else
                                {
                                        for (j=0; j < 5; j++)
                                        {
                                                iat1 = gmmxring.ring_atoms[i][j];
                                                iat2 = gmmxring.ring_atoms[i][j+1];
                                                if ( (atom[iat1].flags & (1L << PI_MASK)) && (atom[iat2].flags & (1L << PI_MASK)) && isbond(iat1,iat2) )
                                                {
                                                        jji = jjk = 0;
                                                        for (k=0; k < MAXIAT; k++)
                                                        {
                                                                if (atom[iat1].bo[k] == 2)
                                                                        jji++;
                                                                if (atom[iat2].bo[k] == 2)
                                                                        jjk++;
                                                        }
                                                        if (jji == 0 && jjk == 0 )                                                      
                                                          {
                                                            make_bond(iat1,iat2,1);
                                                            atom[iat1].use = TRUE;
                                                            atom[iat2].use = TRUE;
                                                          }
                                                }
                                        }
                                        // get last ring bond
                                        iat1 = gmmxring.ring_atoms[i][0];
                                        iat2 = gmmxring.ring_atoms[i][5];
                                        if ( (atom[iat1].flags & (1L << PI_MASK)) && (atom[iat2].flags & (1L << PI_MASK)) && isbond(iat1,iat2) )
                                        {
                                            jji = jjk = 0;
                                            for (k=0; k < MAXIAT; k++)
                                            {
                                                 if (atom[iat1].bo[k] == 2)
                                                    jji++;
                                                 if (atom[iat2].bo[k] == 2)
                                                    jjk++;
                                            }
                                            if (jji == 0 && jjk == 0 )                                                      
                                            {
                                                make_bond(iat1,iat2,1);
                                                atom[iat1].use = TRUE;
                                                atom[iat2].use = TRUE;
                                            }
                                        }
                                        
                                }
                        }
                }
                for (i=0; i < gmmxring.nrings; i++)
                {
                    if (gmmxring.nring_atoms[i] == 5) // must have hetero atom
                      {
                        for (j=0; j < 5; j++)
                        {
                               iat1 = gmmxring.ring_atoms[i][j];
                               if (atom[gmmxring.ring_atoms[i][j]].atomnum != 6)
                               {
                                        if (j == 0)
                                        {
                                          iat1 = gmmxring.ring_atoms[i][4];                                            
                                          iat2 = gmmxring.ring_atoms[i][1];
                                          if (isbond(iat1,gmmxring.ring_atoms[i][0]) && atom[iat1].use == FALSE && atom[gmmxring.ring_atoms[i][0]].use == FALSE)
                                                   make_bond(iat1,gmmxring.ring_atoms[i][0],1);
                                          if (isbond(iat2,gmmxring.ring_atoms[i][2]) && atom[iat1].use == FALSE && atom[gmmxring.ring_atoms[i][0]].use == FALSE)
                                                   make_bond(iat2,gmmxring.ring_atoms[i][2],1);
                                        } else if (j == 4)
                                        {
                                                        iat1 = gmmxring.ring_atoms[i][3];
                                                        iat2 = gmmxring.ring_atoms[i][0];
                                                        if (isbond(iat1,gmmxring.ring_atoms[i][2]) && atom[iat1].use == FALSE && atom[gmmxring.ring_atoms[i][0]].use == FALSE)
                                                                make_bond(iat1,gmmxring.ring_atoms[i][2],1);
                                                        if (isbond(iat2,gmmxring.ring_atoms[i][1]) && atom[iat1].use == FALSE && atom[gmmxring.ring_atoms[i][0]].use == FALSE)
                                                                make_bond(iat2,gmmxring.ring_atoms[i][1],1);
                                        } else
                                        {
                                                        iat1 = gmmxring.ring_atoms[i][j-1];
                                                        iat2 = gmmxring.ring_atoms[i][j+1];
                                                        if (isbond(iat1,gmmxring.ring_atoms[i][(j-2)%5]) && atom[iat1].use == FALSE && atom[gmmxring.ring_atoms[i][0]].use == FALSE)
                                                                make_bond(iat1,gmmxring.ring_atoms[i][(j-2)%5],1);
                                                        if (isbond(iat2,gmmxring.ring_atoms[i][(j+2)%5]) && atom[iat1].use == FALSE && atom[gmmxring.ring_atoms[i][0]].use == FALSE)
                                                                make_bond(iat2,gmmxring.ring_atoms[i][(j+2)%5],1);
                                        }
                                        break;
                                 }
                             }
                         }
                  }
        }
//  need to check for any remain pi bonds 
}
/* ================================================= */
// build coord using spe code
void build_coord()
{
  do_iterate();
}
/* ================================ */
float get_angl(int ia, int ib,int ic)
{
    int i, ita,itb,itc;
    //char pa[4],pb[4],pc[3], pt[10];
    // TJO 5/24/2008
    char pa[4],pb[4],pc[4], pt[10];

    ita = atom[ia].type;
    itb = atom[ib].type;
    itc = atom[ic].type;
    
    numeral(ita,pa,3);
    numeral(itb,pb,3);
    numeral(itc,pc,3);
    
    if (ita <= itc)
    {
        strcpy(pt,pa);
        strcat(pt,pb);
        strcat(pt,pc);
    } else
    {
        strcpy(pt,pc);
        strcat(pt,pb);
        strcat(pt,pa);
    }
// three membered rings
    if (isbond(ia,ic)) // three membered ring
    {
        for (i=0; i < angk1.nang3; i++)
        {
            if (strcmp(angk1.ktype3[i],pt) == 0)
            {
                return (angk1.ang3[i][0]);
            }
        }
    }
// need four membered ring test
// regular param
    for (i=0; i < angk1.nang; i++)
    {
        if ( (strcmp(angk1.ktype[i],pt) == 0))
        {
            return (angk1.ang[i][0]);
        }
    }
    return 109.5;  // default to tetrahedral
}
// ====================================================
float get_bond(int ia, int ib)
{
    int i, ita,itb;
    char pa[4],pb[4], pt[7];

    ita = atom[ia].type;
    itb = atom[ib].type;
    if (ita == 2 && itb == 2) return 1.41;
    if ( (ita == 2 && itb == 3) || (ita == 3 && itb == 2) ) return 1.41;
    numeral(ita,pa,3);
    numeral(itb,pb,3);
    if (ita <= itb)
    {
        strcpy(pt,pa);
        strcat(pt,pb);
    } else
    {
        strcpy(pt,pb);
        strcat(pt,pa);
    }
    for (i=0; i < bondk1.nbnd; i++)
    {
        if ( (strcmp(bondk1.kb[i],pt) == 0))
        {
            return (bondk1.t[i]);
        }
    }
    return 1.53;  // default to c-c single
}
// =================================       
int isangle(int i, int j)
{
    int k,l,katm;
    for (k=0; k < MAXIAT; k++)
    {
        if (atom[i].iat[k] != 0 && atom[i].bo[k] != 9)
        {
            katm = atom[i].iat[k];
            for (l=0; l < MAXIAT; l++)
            {
                if (atom[katm].iat[l] == j)
                  return TRUE;
            }
        }
    }
    return FALSE;
}
// ===================================
int special_cases(char *string)
{
    int newatom,center;
    
    if (strcasecmp(string,"NH4+") == 0)
    {
        newatom = make_atom(41,0.,0.,0.,"N");
        center = newatom;
        lastatom = newatom;
        newatom = make_atom(24,0.0,0.93,-.21,"H");
        make_bond(center,newatom,1);
        newatom = make_atom(24,-.85,-.35,.35,"H");
        make_bond(center,newatom,1);
        newatom = make_atom(24,.69,-.15,.65,"H");
        make_bond(center,newatom,1);
        newatom = make_atom(24,.22,-.51,-.81,"H");
        make_bond(center,newatom,1);
        return TRUE;
    } else if (strcasecmp(string,"SiH4") == 0)
    {
        Build = TRUE;
        newatom = make_atom(19,0.,0.,0.,"Si");
        center = newatom;
        lastatom = newatom;
        newatom = make_atom(5,0.0,0.93,-.21,"H");
        make_bond(center,newatom,1);
        newatom = make_atom(5,-.85,-.35,.35,"H");
        make_bond(center,newatom,1);
        newatom = make_atom(5,.69,-.15,.65,"H");
        make_bond(center,newatom,1);
        newatom = make_atom(5,.22,-.51,-.81,"H");
        make_bond(center,newatom,1);
        return TRUE;
    } else if (string[0] == 'C' && string[1] == '@') // sterochemistry
    {
        newatom = make_atom(1,0.00,0.00,0.00,"C");
        if (lastatom != 0)
          make_bond(lastatom,newatom,1);
        lastatom = newatom;
        return TRUE;
    } else if (strcasecmp(string,"GeH4") == 0)
    {
        Build = TRUE;
        newatom = make_atom(19,0.,0.,0.,"Ge");
        center = newatom;
        lastatom = newatom;
        newatom = make_atom(5,0.0,0.93,-.21,"H");
        make_bond(center,newatom,1);
        newatom = make_atom(5,-.85,-.35,.35,"H");
        make_bond(center,newatom,1);
        newatom = make_atom(5,.69,-.15,.65,"H");
        make_bond(center,newatom,1);
        newatom = make_atom(5,.22,-.51,-.81,"H");
        make_bond(center,newatom,1);
        return TRUE;
    } else if (strcasecmp(string,"SeH2") == 0)
    {
        Build = TRUE;
        newatom = make_atom(39,0.,0.,0.,"Se");
        center = newatom;
        lastatom = newatom;
        newatom = make_atom(5,1.10,0.0,0.0,"H");
        make_bond(center,newatom,1);
        newatom = make_atom(5,1.10,0.0,0.0,"H");
        make_bond(center,newatom,1);
        return TRUE;
    } else if (strcasecmp(string,"NH2+") == 0)
    {
        newatom = make_atom(41,0.,0.,0.,"N");
        center = newatom;
        if (lastatom != 0)
        {
          make_bond(lastatom,newatom,bondtype);
          if (bondtype == DOUBLE)
            bondtype = SINGLE;
        }
        lastatom = newatom;
        newatom = make_atom(24,1.10,0.0,0.0,"H");
        make_bond(center,newatom,1);
        newatom = make_atom(24,1.10,0.0,0.0,"H");
        make_bond(center,newatom,1);
        return TRUE;
    } else if (strcasecmp(string,"TeH2") == 0)
    {
        Build = TRUE;
        newatom = make_atom(0,0.,0.,0.,"Te");
        center = newatom;
        lastatom = newatom;
        newatom = make_atom(5,1.10,0.0,0.0,"H");
        make_bond(center,newatom,1);
        newatom = make_atom(5,1.10,0.0,0.0,"H");
        make_bond(center,newatom,1);
        return TRUE;
    } else if (strcasecmp(string,"SnH2") == 0)
    {
        Build = TRUE;
        newatom = make_atom(0,0.,0.,0.,"Sn");
        center = newatom;
        lastatom = newatom;
        newatom = make_atom(5,1.10,0.0,0.0,"H");
        make_bond(center,newatom,1);
        newatom = make_atom(5,1.10,0.0,0.0,"H");
        make_bond(center,newatom,1);
        return TRUE;
    } else if (strcasecmp(string,"PbH2") == 0)
    {
        Build = TRUE;
        newatom = make_atom(0,0.,0.,0.,"Pb");
        center = newatom;
        lastatom = newatom;
        newatom = make_atom(5,1.10,0.0,0.0,"H");
        make_bond(center,newatom,1);
        newatom = make_atom(5,1.10,0.0,0.0,"H");
        make_bond(center,newatom,1);
        return TRUE;
    } else if (strcasecmp(string,"PoH2") == 0)
    {
        Build = TRUE;
        newatom = make_atom(39,0.,0.,0.,"Po");
        center = newatom;
        lastatom = newatom;
        newatom = make_atom(5,1.10,0.0,0.0,"H");
        make_bond(center,newatom,1);
        newatom = make_atom(5,1.10,0.0,0.0,"H");
        make_bond(center,newatom,1);
        return TRUE;
    } else if (strcasecmp(string,"nH") == 0)
    {
        newatom = make_atom(8,0.,0.,0.,"N");
        center = newatom;
        if (lastatom != 0)
          make_bond(lastatom,newatom,1);
        lastatom = newatom;
        newatom = make_atom(23,1.10,0.0,0.0,"H");
        make_bond(center,newatom,1);
        return TRUE;
    } else if (strcasecmp(string,"CH") == 0)
    {
        newatom = make_atom(1,0.,0.,0.,"C");
        center = newatom;
        if (lastatom != 0)
          make_bond(lastatom,newatom,1);
        lastatom = newatom;
        newatom = make_atom(5,1.10,0.0,0.0,"H");
        make_bond(center,newatom,1);
        return TRUE;
    } else if (strcasecmp(string,"NH+") == 0)
    {
        newatom = make_atom(41,0.,0.,0.,"N");
        center = newatom;
        if (lastatom != 0)
          make_bond(lastatom,newatom,bondtype);
        if (bondtype == DOUBLE)
          bondtype = SINGLE;
        lastatom = newatom;
        newatom = make_atom(24,1.10,0.0,0.0,"H");
        make_bond(center,newatom,1);
        return TRUE;
    } else if (strcasecmp(string,"OH-") == 0)
    {
        Build = TRUE;
        newatom = make_atom(42,0.,0.,0.,"O");
        center = newatom;
        newatom = make_atom(21,1.10,0.0,0.0,"H");
        make_bond(center,newatom,1);
        return TRUE;
    } else if (strcasecmp(string,"TlH") == 0)
    {
        Build = TRUE;
        newatom = make_atom(0,0.,0.,0.,"Tl");
        center = newatom;
        lastatom = newatom;
        newatom = make_atom(5,1.30,0.0,0.0,"H");
        make_bond(center,newatom,1);
        return TRUE;
    } else if (strcasecmp(string,"AtH") == 0)
    {
        newatom = make_atom(0,0.,0.,0.,"At");
        center = newatom;
        lastatom = newatom;
        newatom = make_atom(5,1.30,0.0,0.0,"H");
        make_bond(center,newatom,1);
        return TRUE;
    } else if (strcasecmp(string,"CH3-") == 0)
    {
        newatom = make_atom(48,0.,0.,0.,"C");
        center = newatom;
        newatom = make_atom(5,-.38, 0.81,-0.6,"H");
        make_bond(center,newatom,1);
        newatom = make_atom(5,-.24, 0.15,1.07,"H");
        make_bond(center,newatom,1);
        newatom = make_atom(5,1.07,-0.15,-.12,"H");
        make_bond(center,newatom,1);
        return TRUE;
    } else if (strcasecmp(string,"NH3+") == 0)
    {
        newatom = make_atom(41,0.,0.,0.,"N");
        center = newatom;
        if (lastatom != 0)
          make_bond(lastatom,newatom,bondtype);
        if (bondtype == DOUBLE)
          bondtype = SINGLE;
        lastatom = newatom;
        newatom = make_atom(24,-.38, 0.81,-0.6,"H");
        make_bond(center,newatom,1);
        newatom = make_atom(24,-.24, 0.15,1.07,"H");
        make_bond(center,newatom,1);
        newatom = make_atom(24,1.07,-0.15,-.12,"H");
        make_bond(center,newatom,1);
        return TRUE;
    } else if (strcasecmp(string,"InH3") == 0)
    {
        newatom = make_atom(0,0.,0.,0.,"In");
        center = newatom;
        newatom = make_atom(5,-.38, 0.81,-0.6,"H");
        make_bond(center,newatom,1);
        newatom = make_atom(5,-.24, 0.15,1.07,"H");
        make_bond(center,newatom,1);
        newatom = make_atom(5,1.07,-0.15,-.12,"H");
        make_bond(center,newatom,1);
        return TRUE;
    } else if (strcasecmp(string,"AsH3") == 0)
    {
        newatom = make_atom(0,0.,0.,0.,"As");
        center = newatom;
        lastatom = newatom;
        newatom = make_atom(5,-.38, 0.81,-0.6,"H");
        make_bond(center,newatom,1);
        newatom = make_atom(5,-.24, 0.15,1.07,"H");
        make_bond(center,newatom,1);
        newatom = make_atom(5,1.07,-0.15,-.12,"H");
        make_bond(center,newatom,1);
        return TRUE;
    } else if (strcasecmp(string,"GaH3") == 0)
    {
        newatom = make_atom(0,0.,0.,0.,"Ga");
        center = newatom;
        lastatom = newatom;
        newatom = make_atom(5,-.38, 0.81,-0.6,"H");
        make_bond(center,newatom,1);
        newatom = make_atom(5,-.24, 0.15,1.07,"H");
        make_bond(center,newatom,1);
        newatom = make_atom(5,1.07,-0.15,-.12,"H");
        make_bond(center,newatom,1);
        return TRUE;
    }
    return FALSE;
}
// =========================================
int check_smiles(char *line,int *nstruct)
{
    int i,nc,iz;
    int inAtom;

    iz = strlen(line);
    if (iz <= 0)
      return FALSE;

    nc = 0;
    inAtom = FALSE;
    for (i=0; i < iz; i++)
    {
        if (line[i] == '[')
          inAtom = TRUE;
        else if (line[i] == ']')
          inAtom = FALSE;
        else if ((line[i] == 'c' || line[i] == 'C') && inAtom == FALSE)
          nc++;
        if (line[i] == '.')
          *nstruct += 1;
    }
    if (nc > 0)
      return TRUE;
    else
      return FALSE;
}
// =============================
int check_coord()
{
    int i,j,jj;

    for (i=1; i <= natom; i++)
    {
        jj = 0;
        for (j=0; j < MAXIAT; j++)
        {
            if (atom[i].iat[j] != 0)
              jj++;
        }
        if (jj > 5)
          return FALSE;
    }
    return TRUE;
}
// =========================================
int process_atom(char *string)
{
  int i,iz,ichiral;
  int itype,newatom;
  int numsecond,firstcharge,firststereo;
  char firstatom[3],secondatom[3];
  char tmpc,tmp1[2];

  numsecond = 0;
  ichiral = 0;
  firstcharge = 0;
  firststereo = 0;
  strcpy(firstatom,"");
  strcpy(secondatom,"");

  iz = strlen(string);
  if (iz == 0) return FALSE;
// first character is atomic symbol
  i = 0;
L_1:
  tmpc = string[i];
  if (tmpc >= '0' && tmpc <= '9')
  {
     i++;
     goto L_1;
  }
  firstatom[0] = string[i];
  i++;
// second character can be -
//  second character of first atomic symbol
//  second atom - should be upper case
//  chirality symbol
  tmpc = string[i];
  if (tmpc >= 'a' && tmpc <= 'z')
  {
      firstatom[1] = tmpc;
      firstatom[2] = '\0';
      i++;
  } else
    firstatom[1] = '\0';
// check for chirality
  if (tmpc == '@')
  {
      if (string[i+1] == '@')
      {
          ichiral = 1;
          i++;
      } else
          ichiral = -1;
      i++;
  }
// check for second atom symbol
  tmpc = string[i];
  if (tmpc >= 'A' && tmpc <= 'Z')
  {
      secondatom[0] = tmpc;
      numsecond = 1;
      i++;
  } 
  tmpc = string[i];
  if (tmpc >= 'a' && tmpc <= 'z')
  {
    secondatom[1] = tmpc;
    secondatom[2] = '\0';
    i++;
  } else
    secondatom[1] = '\0';

  // done with atoms
  do {
    tmpc = string[i];
    if (tmpc == '+')
    {
      firstcharge = 1;
      if (string[i+1] >= '0' && string[i+1] <= '9')
        {
          tmp1[0] = string[i+1];
          tmp1[1] = '\0';
          sscanf(tmp1,"%d",&firstcharge);
          i++;
        }
      i++;
    } else if (tmpc == '-')
    {
      firstcharge = -1;
      if (string[i+1] >= '0' && string[i+1] <= '9')
        {
          tmp1[0] = string[i+1];
          tmp1[1] = '\0';
          sscanf(tmp1,"%d",&firstcharge);
          i++;
          firstcharge *= -1;
        }
      i++;
    } else if (tmpc >= '1' && tmpc <='9')
    {
        tmp1[0] = tmpc;
        tmp1[1] = '\0';
        sscanf(tmp1,"%d",&numsecond);
        i++;    
    } else if (tmpc == '@')
    {
      if (string[i+1] == '@')
      {
          ichiral = 1;
          i++;
      } else
          ichiral = -1;
      i++;          
    } else  // don't recognize symbol
      i++;
  } while (i < iz);
  // process atoms
  // look up atom type for first atom
  get_mmxtype(firstatom,&itype);
  if (firstcharge != 0)
  {
      if (strcasecmp(firstatom,"c") == 0)
      {
          if (firstcharge == 1) itype = 30;
          if (firstcharge == -1) itype = 48;
      } else if (strcasecmp(firstatom,"n") == 0)
      {
          if (firstcharge == 1) itype = 41;
          if (firstcharge == -1) itype = 77;
      } else if (strcasecmp(firstatom,"o") == 0)
      {
          if (firstcharge == 1) itype = 46;
          if (firstcharge == -1) itype = 42;
      } else if (strcasecmp(firstatom,"s") == 0)
      {
          if (firstcharge == 1) itype = 16;
      }
  }
  if ( (itype < 0 || itype > 500) && (strcmp(firstatom,"") == 0) )
  {
       printf("Error reading atom %s\n",string);
       exit(0);
  }
  newatom = make_atom(itype,0.0,0.0,0.0,firstatom);
  if (lastatom != 0) make_bond(lastatom,newatom,bondtype);
  if (firstcharge != 0)
    atom[newatom].charge = firstcharge;
  lastatom = natom;
  bondtype = SINGLE;
  // if second atom exists look up type
  if (numsecond > 0)
  {
     get_mmxtype(secondatom,&itype);
     for (i=0; i < numsecond; i++)
     {
         newatom = make_atom(itype,0.0,0.0,0.0,secondatom);
         make_bond(lastatom,newatom,1);
     }
  }
  // set chirality
  if (ichiral != 0 && atom[lastatom].atomnum == 6 )  // only do chiral carbon at this time
  {
    chiral.icenter[chiral.nchiral] = lastatom;
    chiral.chirality[chiral.nchiral] = ichiral;
    chiral.nchiral++;
  }
  return TRUE;
}
// =====================================
// ==============================
void initialize_gmmx()
{
    int i, j, k, nheav, nhyd,stmp;
    long int mask;

    mask = (1L << 0);
    gmmxring.nrings = 0;
    for (i=0; i < 4; i++)
    {
        for (j=0; j < 4; j++)
        {
            gmmx_data.rng_size[j] = 0;
            gmmxring.nring_atoms[i] = 0;
            for (i=0; i <  30; i++)
            {
                gmmx_data.ring_atoms[i][j] = 0 ;
            }
            gmmx_data.clo_distance[j] = 0;
            gmmx_data.clo_ang[0][j] = 0;
            gmmx_data.clo_ang[1][j] = 0;
            gmmx_data.ring_resolution[j] = 0.0;
            gmmx_data.clo_bond[0][j] = 0 ;
            gmmx_data.clo_bond[1][j] = 0 ;
            gmmx_data.clo_bond[2][j] = 0 ;
            gmmx_data.clo_bond[3][j] = 0 ;
            gmmx_data.clo_bond[4][j] = 0 ;
            gmmx_data.clo_bond[5][j] = 0 ;
        }
    }
    stmp = rand();
    if(stmp >= 10000)
       stmp = stmp/10;
    if(stmp >= 10000)
       stmp = stmp/10;
    if(stmp >= 10000)
       stmp = stmp/10;
    if(stmp >= 10000)
       stmp = stmp/10;
    if(stmp >= 10000)
       stmp = stmp/10;
    if(stmp >= 10000)
       stmp = stmp/10;
    if(stmp >= 10000)
       stmp = stmp/10;
    if(stmp >= 10000)
       stmp = stmp/10;
//    sprintf(gmmx_data.jobname,"gmx%d",stmp);
    strcpy(gmmx_data.gmmx_comment,"GMMX Conf Search");
        
    gmmx_data.method = 3;
    gmmx_data.iseed = 71277;
    gmmx_data.its = 990;
    gmmx_data.lnant = TRUE;
    gmmx_data.hybrid = TRUE;
    gmmx_data.ecut = TRUE;
    gmmx_data.chig = TRUE;
    gmmx_data.bad15 = TRUE;
    gmmx_data.hbond = TRUE;
    gmmx_data.heat = FALSE;
    
    gmmx_data.comp = 0;
    gmmx_data.qpmr = FALSE;
    gmmx_data.qdist = FALSE;
    gmmx_data.qang = FALSE;
    gmmx_data.qdihed = FALSE;
    gmmx_data.npmr = 0;
    gmmx_data.ndist = 0;
    gmmx_data.nang = 0;
    gmmx_data.ndihed = 0;

    gmmx_data.nrings = 0;
    gmmx_data.nbonds = 0;
    gmmx_data.ewindow = 3.5;
    gmmx_data.ewindow2 = 3.0;
    gmmx_data.boltz = 300.0;
    gmmx_data.ecutoff = 0.100;
    gmmx_data.bad15_cutoff = 3.00;
        
    gmmx_data.nsrms = 0;
    gmmx_data.nsrmsa = 0;
    gmmx_data.comp_method = 0;
    gmmx_data.comp_method2 = 1;
    gmmx_data.ermsa = 0.100;
    gmmx_data.crmsa = 0.250;
    gmmx_data.restart = FALSE;
    gmmx_data.include_file = FALSE;

    nheav = 0;
    nhyd = 0;
    for (i=1; i <= natom; i++)
    {
        if (atom[i].atomnum != 1 && atom[i].atomnum != 2)
            nheav++;
        else
            nhyd++;
    }

    gmmx_data.kstop = 5;
    gmmx_data.kmin = 5*nheav;
    gmmx_data.kdup = 5*nheav/2;
    if (gmmx_data.kdup > 50)
      gmmx_data.kdup = 50;
    gmmx_data.max_search = 5000;
    
    gmmx_data.nrings = 0;
    for (i=0; i < 4; i++)
      gmmx_data.nring_bonds[i] = 0; 
    for (i=0; i < 30; i++)
    {
       gmmxring.nring_atoms[i] = 0;
       for (j=0; j < 30; j++)
         gmmxring.ring_atoms[i][j]=0;
       for (j=0; j < 4; j++)
       for (k=0; k < 3; k++)
        gmmx_data.ring_bond_data[j][i][k] = 0;
    }
    
}
// =================================
int is_ring62(int ia, int ib)
{
    int i, j,k, itmp, jtmp;
    if (ia < ib)
    {
        itmp = ia;
        jtmp = ib;
    }else
    {
        itmp = ib;
        jtmp = ia;
    }
    for (i=0; i < gmmxring.nrings; i++)
    {
                if (gmmxring.nring_atoms[i] == 6)
                {
                        for (j=0; j < 6; j++)
                        {
                                if (itmp == gmmxring.ring_atoms[i][j])
                                {
                                        for (k=0; k < 6; k++)
                                        {
                                                if (jtmp == gmmxring.ring_atoms[i][k])
                                                        return(TRUE);
                                        }
                                }
                        }
                }
        }
    return(FALSE);
}     
