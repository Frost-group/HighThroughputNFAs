#define EXTERN extern

#include "pcwin.h"
#include "pcmod.h"
#include "atom_k.h"
#include "gmmx.h"
#include "utility.h"

#define NOSTERO   0
#define UP        1
#define DOWN     -1
#define CIS       2
#define TRANS     3

EXTERN struct ElementType { char symbol[3];
                             int atomnum;
                             float weight,extweight, covradius, vdwradius;
                              int s,p,d,f, type;
                            } Elements[];
EXTERN struct t_files {
        int nfiles, append, batch, icurrent, ibatno;
        }       files;
EXTERN struct {
        int nbond,ia[MAXBND],ib[MAXBND],ibo[MAXBND],istereo[MAXBND];
        } bonds;       
EXTERN struct {
        int  nchiral, icenter[MAXCHIRAL],chirality[MAXCHIRAL], iest[MAXCHIRAL][4];
        } chiral;        

void do_iterate(void);
double dihdrl(int,int,int,int);
float get_bond(int,int);
float get_angl(int,int,int);
double distance(int,int);
int check_dstereo(void);
int setup_calculation(void);
void end_calculation(void);
void minimize(void);
void setup_output(char *);
void pcmfout(int);
void start_abort(void);
void end_abort(void);
void update_abort(void);
int find_bond(int,int);
//  data
EXTERN int gmmx_abort;
double *xold,*yold,*zold;

// ========================
// set upper and lower bounds distance matrix
// record chiral centers
// start iterative fitting procedure
//   randomize all atoms
//   set distance learning rate, volume learning rate, frequency
//   select distance or volume constraint
//     do distance
//     or do volume
//   repeat for n steps
//   check if anything moved
//   if no movement check chirality
//   
void do_iterate()
{
    int i,j,k,l,iz,moved;
    int ia,ib,ic,id,ibondo;
    int nchiral,ncount;
    double agl,rab,rbc,rac,rcd,rbd;
    double bndmin,bndmax;
    double cosmin,cosmax,cosabc,cosbcd,sinabc,sinbcd;
    double bminx,bmaxx;
    double rndtmp, rndmax;
    float lam_d,lam_v,delta_d,delta_v,nu,rdist;
    int ncycles,numstep,icycle,istep;
    double **dstmat;
//    double dstmat[50][50];

    nchiral = 0;
    if (chiral.nchiral > 0)
    {
        for (i=0; i < chiral.nchiral; i++)
        {
            ia = chiral.icenter[i];
            chiral.iest[i][0] = atom[ia].iat[0];
            chiral.iest[i][1] = atom[ia].iat[1];
            chiral.iest[i][2] = atom[ia].iat[2];
            chiral.iest[i][3] = atom[ia].iat[3];
            for (j=0; j < 4; j++)
            {
                if (chiral.iest[i][j] <= 0)
                  printf("Error with chiral atom %d\n",ia);
            }
        }
        nchiral = chiral.nchiral;
    }
// distances
    dstmat = dmatrix(0,natom+1,0,natom+1);
    for (i=1; i <= natom; i++)
    {
        for (j=1; j <= natom; j++)
        {
            dstmat[i][j] = 0.0;

        }
    }
// set all bonded distances
    for (i=1; i <= natom; i++)
    {
        for (j=0; j < MAXIAT; j++)
        {
            if (atom[i].iat[j] != 0)
            {
                dstmat[i][atom[i].iat[j]] = get_bond(i,atom[i].iat[j]);
                dstmat[atom[i].iat[j]][i] = dstmat[i][atom[i].iat[j]];
            }
        }
    }
// set all 1,3 distances
    for (i=1; i <= natom; i++)
    {
        for (j=0; j < MAXIAT; j++)
        {
            ia = i;
            if (atom[i].iat[j] != 0)
            {
                ib = atom[i].iat[j];
                for (k=0; k < MAXIAT; k++)
                {
                    if (atom[ib].iat[k] != 0 && atom[ib].iat[k] != ia )
                    {
                        ic = atom[ib].iat[k];
                        agl = get_angl(ia,ib,ic);
                        rab = dstmat[ia][ib];
                        rbc = dstmat[ib][ic];
                        rac = sqrt(rab*rab + rbc*rbc - 2.0*rab*rbc*cos(agl/radian));
                        dstmat[ia][ic] = rac;
                        dstmat[ic][ia] = rac;
                    }
                }
            }
        }
    }
// set all 1,4 distances    
    cosmin = 1.0;
    cosmax = -1.0;
    for (i=1; i <= natom; i++)
    {
        for (j=0; j < MAXIAT; j++)
        {
            ia = i;
            if (atom[i].iat[j] != 0)
            {
                ib = atom[i].iat[j];
                for (k=0; k < MAXIAT; k++)
                {
                    if (atom[ib].iat[k] != 0 && atom[ib].iat[k] != ia)
                    {
                        ic = atom[ib].iat[k];
                        ibondo = atom[ib].bo[k];
                        for (l=0; l < MAXIAT; l++)
                        {
                            if (atom[ic].iat[l] != 0 && atom[ic].iat[l] != ia && atom[ic].iat[l] != ib && atom[ic].iat[l] != ic)
                            {
                                id = atom[ic].iat[l];
                                rab = dstmat[ia][ib];
                                rbc = dstmat[ib][ic];
                                rcd = dstmat[ic][id];
                                rac = dstmat[ia][ic];
                                rbd = dstmat[ib][id];
                                cosabc = (rab*rab + rbc*rbc - rac*rac)/(2.0*rab*rbc);
                                sinabc = sqrt(MaxFun(0.0,(1.0 - cosabc*cosabc)));
                                cosbcd = (rbc*rbc + rcd*rcd - rbd*rbd)/(2.0*rbc*rcd);
                                sinbcd = sqrt(MaxFun(0.0,(1.0 - cosbcd*cosbcd)));
                                bndmin = rab*rab + rbc*rbc + rcd*rcd + 2.0*rab*rcd*cosabc*cosbcd
                                            - 2.0*rab*rcd*sinabc*sinbcd*cosmin
                                            - 2.0*rbc*(rab*cosabc+rcd*cosbcd);
                                bndmax = rab*rab + rbc*rbc + rcd*rcd + 2.0*rab*rcd*cosabc*cosbcd
                                            - 2.0*rab*rcd*sinabc*sinbcd*cosmax
                                            - 2.0*rbc*(rab*cosabc+rcd*cosbcd);
                                bndmin = sqrt(MaxFun(0,bndmin));
                                bndmax = sqrt(MaxFun(0,bndmax));
                                if (ibondo >= 2 && dstmat[ia][id] == 0.0)
                                {
                                   iz = find_bond(ib,ic);
                                   if (iz != -1)
                                   {
                                      if (bonds.istereo[iz] == CIS)
                                      {
                                        dstmat[ia][id] = bndmax-0.2;
                                        dstmat[id][ia] = bndmax+0.2;
                                      } else if (bonds.istereo[iz] == TRANS)
                                      {
                                        dstmat[ia][id] = bndmin;
                                        dstmat[id][ia] = bndmin+0.2;
                                      }else
                                      {
                                        dstmat[ia][id] = bndmin;// bond min
                                        dstmat[id][ia] = bndmax; // bond max
                                      }
                                   } else
                                   {
                                      dstmat[ia][id] = bndmin;// bond min
                                      dstmat[id][ia] = bndmax; // bond max
                                   }
                                } else if (dstmat[ia][id] == 0.0)  // distance not set
                                {
                                    if (ia > id)
                                    {
                                        dstmat[ia][id] = bndmin;
                                        dstmat[id][ia] = bndmax;
                                    } else
                                    {
                                        dstmat[ia][id] = bndmax;
                                        dstmat[id][ia] = bndmin;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
// set remaining distances
    for (i=1; i < natom; i++)
    {
        for (j=i+1; j <= natom; j++)
        {
            if (dstmat[i][j] == 0.0)
            {
                // max distance
                dstmat[i][j] = (float)natom*1.5;
                // min distance
                dstmat[j][i] = 2.50;
            }
        }
    }
//  set box size
    bminx = 0.0;
    bmaxx = (float)natom*0.75;
     
// start of iterative fitting procedure
// randomize atoms
   srand(51277);
   ncount = 0;
   while (TRUE)
   {
L_START:
       ncount++;
       if (ncount > 10) goto L_DONE;
       
       rndmax = (double) RAND_MAX;
       for (i=1; i <= natom; i++)
       {
           atom[i].x = ((double) rand()/rndmax)*bmaxx;
           atom[i].y = ((double) rand()/rndmax)*bmaxx;
           atom[i].z = ((double) rand()/rndmax)*bmaxx;
       }
// set parameters
       lam_d = lam_v = 1.0;
       ncycles = 5;
       delta_d = delta_v = 0.9/ncycles;
       numstep = natom;
       nu = 1.0 - 8.0*((float)nchiral/( (float) (natom*(natom+1))/2 + nchiral) );
       if (nu < 0.9) nu = 0.9;
// start
       for (icycle = 0; icycle < ncycles; icycle++)
       {
           for (istep = 0; istep < numstep; istep++)
           {
               rndtmp = (double)rand()/rndmax;
               if (rndtmp < nu) // move atoms
               {
                   moved = FALSE;
                 for (k=1; k < natom; k++)
                 {
                     for (l=k+1; l <= natom; l++)
                     {
                         ia = k;
                         ib = l;
                         if (ia != ib && ia != 0 && ib != 0 && ia <= natom && ib <= natom)
                        {
                            rdist = distance(ia,ib);
                            if (ia > ib) // set atom order
                            {
                                i = ia;
                                ia = ib;
                                ib = i;
                            }
                            if (rdist < dstmat[ib][ia])  // lower bounds
                            {
                                atom[ia].x += lam_d*0.5*((dstmat[ib][ia]-rdist)/(rdist + 1.0e-8))*(atom[ia].x - atom[ib].x);
                                atom[ia].y += lam_d*0.5*((dstmat[ib][ia]-rdist)/(rdist + 1.0e-8))*(atom[ia].y - atom[ib].y);
                                atom[ia].z += lam_d*0.5*((dstmat[ib][ia]-rdist)/(rdist + 1.0e-8))*(atom[ia].z - atom[ib].z);
                                atom[ib].x += lam_d*0.5*((dstmat[ib][ia]-rdist)/(rdist + 1.0e-8))*(atom[ib].x - atom[ia].x);
                                atom[ib].y += lam_d*0.5*((dstmat[ib][ia]-rdist)/(rdist + 1.0e-8))*(atom[ib].y - atom[ia].y);
                                atom[ib].z += lam_d*0.5*((dstmat[ib][ia]-rdist)/(rdist + 1.0e-8))*(atom[ib].z - atom[ia].z);
                                moved = TRUE;
                            } else if (rdist > dstmat[ia][ib])  // upper bounds
                            {
                                atom[ia].x += lam_d*0.5*((dstmat[ia][ib]-rdist)/(rdist + 1.0e-8))*(atom[ia].x - atom[ib].x);
                                atom[ia].y += lam_d*0.5*((dstmat[ia][ib]-rdist)/(rdist + 1.0e-8))*(atom[ia].y - atom[ib].y);
                                atom[ia].z += lam_d*0.5*((dstmat[ia][ib]-rdist)/(rdist + 1.0e-8))*(atom[ia].z - atom[ib].z);
                                atom[ib].x += lam_d*0.5*((dstmat[ia][ib]-rdist)/(rdist + 1.0e-8))*(atom[ib].x - atom[ia].x);
                                atom[ib].y += lam_d*0.5*((dstmat[ia][ib]-rdist)/(rdist + 1.0e-8))*(atom[ib].y - atom[ia].y);
                                atom[ib].z += lam_d*0.5*((dstmat[ia][ib]-rdist)/(rdist + 1.0e-8))*(atom[ib].z - atom[ia].z);
                                moved = TRUE;                
                            }
                        }
                     }
                 }
               } else  // do chiral
               {
                  if (nchiral > 0)
                  {
                       i = ((double)rand()/rndmax*nchiral);
                       if (i >= 0 && i < nchiral)
                       {
                           ia = chiral.iest[i][0];
                           ib = chiral.iest[i][1];
                           ic = chiral.iest[i][2];
                           id = chiral.iest[i][3];
                          agl = dihdrl(ia,ib,ic,id);
                          if ( (agl > 0.0 && chiral.chirality[i] < 0.0) || (agl < 0.0 && chiral.chirality[i] > 0.0))
                          {
                             // swap two atoms
                             agl = atom[ia].x;
                             atom[ia].x = atom[id].x;
                             atom[id].x = agl; 
                             agl = atom[ia].y;
                             atom[ia].y = atom[id].y;
                             atom[id].y = agl; 
                             agl = atom[ia].z;
                             atom[ia].z = atom[id].z;
                             atom[id].z = agl;
                          }
                       }
                  }
               }
           }
           lam_d -= delta_d;
           lam_v -= delta_v;
           if (moved == FALSE) goto DONE;
       }
// check chirality
DONE:
       for (i=0; i < chiral.nchiral; i++)
       {
           ia = chiral.iest[i][0];
           ib = chiral.iest[i][1];
           ic = chiral.iest[i][2];
           id = chiral.iest[i][3];
           agl = dihdrl(ia,ib,ic,id);
           if (agl > 0.0 && chiral.chirality[i] < 0.0)
             goto L_START;
           else if (agl < 0.0 && chiral.chirality[i] > 0.0)
             goto L_START;
       }
   }
// check double bonds   
// done
L_DONE: 
   free_dmatrix(dstmat,0,natom+1,0,natom+1);
}
// =============================================
double distance(int i, int k)
{
     double xcomp, ycomp, zcomp, distflag;

      xcomp = (atom[i].x -atom[k].x)*(atom[i].x - atom[k].x) ;
      ycomp = (atom[i].y -atom[k].y)*(atom[i].y - atom[k].y) ;
      zcomp = (atom[i].z -atom[k].z)*(atom[i].z - atom[k].z) ;
      distflag=sqrt(xcomp+ycomp+zcomp);
      return (distflag);

}
// ================================
int find_bond(int ia,int ib)
{
  int i;
  for (i=0; i < bonds.nbond; i++)
    {
      if (bonds.ia[i] == ia && bonds.ib[i] == ib)
        return i;
      else if (bonds.ia[i] == ib && bonds.ib[i] == ia)
        return i;
    }
  return -1;
}
