#define EXTERN extern
#define false FALSE
#define true TRUE

#include "pcwin.h"
#include "pcmod.h"
#include "atom_k.h"
#include "pot.h"
#include "field.h"
#include "utility.h"
#include "units.h"


FILE * fopen_path ( char * , char * , char * ) ;
void zero_data(void);
void read_datafiles(char *);
void initialize_pcmodel(void);
void fixdisreset(void);
void coordreset(void);
void ddrivereset(void);
void hbondreset(void);
void pireset(void);
void generate_bonds(void);
void set_field(void);
void fixangle_reset(void);
void reset_drawing(void);
void reset_query(void);
void reset_calc_parameters(void);
void initialize(void);
void reset_drawing2(void);
void reset_atom_data(void);

EXTERN struct {
        int  nchiral, icenter[MAXCHIRAL], chirality[MAXCHIRAL], iest[MAXCHIRAL][4];
        } chiral;        
EXTERN struct t_files {
        int nfiles, append, batch, icurrent;
        int ibatno;
        } files;

EXTERN struct t_minim_values {
        int iprint, ndc, nconst;
        float dielc;
        } minim_values;
EXTERN struct {
        int nbond,ia[MAXBND],ib[MAXBND],ibo[MAXBND],istereo[MAXBND];
        } bonds;
        
// ==================================
void initialize_pcmodel()
{
    int i;
    for (i=0; i < 100; i++)
       Struct_Title[i] = ' ';
    strcpy(Struct_Title, "");
    units.dielec = 1.0;
    zero_data();
// initialize atom definitions
    atom_def.natomtype = atom_k.natomtype;
    for (i=1; i < MAXATOMTYPE; i++)
    {
                atom_def.type[i] = atom_k.type[i];
                atom_def.valency[i] = atom_k.valency[i];
                atom_def.number[i] = atom_k.number[i];
                atom_def.ligands[i] = atom_k.ligands[i];
                atom_def.weight[i] = atom_k.weight[i];
                strcpy(atom_def.symbol[i],atom_k.symbol[i]);
     }
//      
}
// ==========================
void initialize(void)
{
    int         i;
    
    for (i=0; i < 100; i++)
       Struct_Title[i] = ' ';
    strcpy(Struct_Title, "");
    natom = 0;
    chiral.nchiral = 0;
    bonds.nbond = 0;
    for (i=0; i < MAXBND; i++)
    {
        bonds.ia[i] = 0;
        bonds.ib[i] = 0;
        bonds.ibo[i] = 0;
        bonds.istereo[i] = 0;
    }
    reset_atom_data();
}
/* ============================================== */
void reset_calc_parameters(void)
{
}
/* =============================================== */
void pireset()
{
        long int i,mask;
        mask = 1L << PI_MASK;
        for (i = 1; i <= natom; i++)
                atom[i].flags &= ~mask;
}
/* ============================================== */       
void reset_atom_data(void)
{
        int i, j;

    for (i = 0; i < MAXATOM; i++) 
    {
        atom[i].use = 0;
        atom[i].x = 0.0F; atom[i].y = 0.0F; atom[i].z = 0.0F;
        atom[i].color = 0;
        atom[i].chrg_color = 7;
        atom[i].charge = 0.0F;
        atom[i].energy = 0.0F;
        atom[i].atomnum = 0;
        atom[i].serno = 0;
        atom[i].molecule = 0;
        atom[i].residue = 0;
        atom[i].formal_charge = 0;
        atom[i].atomwt = 0.0;
        atom[i].type = 0;
        atom[i].mmx_type = 0;
        atom[i].mm3_type = 0;
        atom[i].mmff_type = 0;
        atom[i].tclass = 0;
        *atom[i].name = '\0';
        atom[i].flags = 0;
        for (j = 0; j < MAXIAT; j++) 
        {
           atom[i].bo[j] = 0;
           atom[i].iat[j] = 0;
        }
        for (j=0; j < MAXSS; j++)
          atom[i].substr[j] = 0;
     }
}

