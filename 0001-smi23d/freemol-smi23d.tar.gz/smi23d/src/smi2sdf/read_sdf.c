#define EXTERN extern

#include "pcwin.h"
#include "pcmod.h"
#include "atom_k.h"

EXTERN struct t_files {
        int nfiles, append, batch, icurrent, ibatno;
        }       files;
EXTERN struct ElementType { char symbol[3];
                             int atomnum;
                             float weight, extweight, covradius, vdwradius;
                              int s,p,d,f,type ;
                            } Elements[];

int make_atom(int, float, float, float,char *);
void make_bond(int, int, int);
void read_sdf(int,int);
void write_sdf(void);
void message_alert(char *, char *);
void read_schakal(int,int);
void write_schakal(void);
void mopaco(int,int);
int FetchRecord(FILE *, char *);
EXTERN FILE *wfile;
EXTERN int strnum;

void write_sdf()
{
    int i,j,nbond,junk;
    

    nbond = 0;
    /*     **  calculate the number of bonds in the molecule ** */
    for( j = 1; j <= natom; j++ )
    {
      for( i = 0; i < MAXIAT; i++ )
      {
         if( atom[j].iat[i] != 0 )
         {
            if( atom[j].iat[i] < j )
               nbond = nbond + 1;
         }
       }
     }
    /*     now write the concord file */
    j = strlen(Struct_Title);
    for (i=0; i < j; i++)
    {
        if (Struct_Title[i] == '\n')
        {
            Struct_Title[i] = '\0';
            break;
        }
    }
    fprintf(wfile,"%s\n",Struct_Title);
    fprintf(wfile," SMI23D  v%5.2f   1.00000     0.00000\n",VERSION);       
    fprintf(wfile,"\n");       

    fprintf(wfile,"%3d%3d  0  0  0  0              1 V2000\n",natom,nbond);

    for (i=1; i <= natom; i++)
    {
        junk = 0;
        if (atom[i].mmx_type == 41) junk = 3;
        else if (atom[i].mmx_type == 42) junk = 5;
        else if (atom[i].mmx_type == 66)
        {
            if (atom[i].bo[0] == 1)
               junk = 5;
        }
        if (atom[i].charge >= 3.0) junk = 1;
        else if (atom[i].charge >= 2.0) junk = 2;
        else if (atom[i].charge >= 1.0) junk = 3;

        if (atom[i].charge == -1.0) junk = 5;
        else if (atom[i].charge == -2.0) junk = 6;
        else if (atom[i].charge == -3.0) junk = 7;
        
        fprintf(wfile,"%10.4f%10.4f%10.4f %-3s 0  %d  0  0  0  0 \n",atom[i].x, atom[i].y,
          atom[i].z,Elements[atom[i].atomnum-1].symbol,junk);
    }
    for (i=1; i <= natom; i++)
    {
        for (j=0; j < MAXIAT; j++)
        {
            if (atom[i].iat[j] != 0 && i < atom[i].iat[j])
               fprintf(wfile,"%3d%3d%3d  0\n",i, atom[i].iat[j], atom[i].bo[j]);
        }
    }
    fprintf(wfile,"M  END\n");
    
    fprintf(wfile,">  <name>\n");
    fprintf(wfile,"%s\n",Struct_Title);
    fprintf(wfile,"\n");
    fprintf(wfile,"$$$$\n");

}

